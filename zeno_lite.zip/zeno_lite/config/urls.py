from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("absroll/", include("ABSROLL.urls")),
    path("vehicleid/", include("VEHICLEID.urls")),
    path("dombtrv/", include("DOMBTRV.urls")),
    path("", include("accounts.urls")),
]
