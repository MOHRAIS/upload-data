"""Sinkron csv -> database. Dipakai bersama oleh web dan batch."""
from dataclasses import dataclass

from django.db import transaction
from django.db.models import Count
from django.utils import timezone

from . import core
from .models import CodeMeaning, SyncLog, SyncState, Vehicle

UPDATE_FIELDS = [f for _, f, _ in core.FIELDS if f != "long_vin"] + ["row_hash", "search_text"]
MASS_DELETE_RATIO = 0.5
MASS_DELETE_MIN = 100


@dataclass
class SyncResult:
    status: str          # ok | tidak_berubah | tidak_ada_file | gagal | ditahan | sibuk
    message: str = ""
    file_name: str = ""
    added: int = 0
    changed: int = 0
    removed: int = 0
    excluded: int = 0
    total: int = 0

    @property
    def level(self):
        return {"ok": "success", "tidak_berubah": "info"}.get(self.status, "warning" if self.status != "gagal" else "error")

    @property
    def berubah(self):
        return self.added or self.changed or self.removed


def _aware(dt):
    if dt is None:
        return None
    try:
        return timezone.make_aware(dt)
    except Exception:
        return None


def _prep(rec):
    d = dict(rec)
    for f in core.DT_FIELDS:
        d[f] = _aware(d[f])
    return d


def _chunks(seq, n=500):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def _finish(state, res, oleh, log_it=True):
    changed_msg = (state.status != res.status or state.message != res.message)
    state.status, state.message = res.status, res.message
    state.last_checked = timezone.now()
    state.save()
    if log_it and (res.status == "ok" or changed_msg):
        SyncLog.objects.create(oleh=oleh, status=res.status, file_name=res.file_name,
                               ditambah=res.added, diubah=res.changed, dihapus=res.removed,
                               diabaikan=res.excluded, pesan=res.message[:1000])
    return res


def sync_now(oleh="-", force=False, allow_mass_delete=False):
    """Cek file terbaru di folder sumber; bila ada perubahan -> tambah / ubah / hapus di database."""
    try:
        with core.lock():
            return _sync_locked(oleh, force, allow_mass_delete)
    except core.BusyError as e:
        return SyncResult("sibuk", str(e))


def sync_all(oleh="-", force=False, allow_mass_delete=False):
    """Sinkron csv kendaraan + kamus sellists. Hasil: [SyncResult csv, SyncResult kamus]."""
    try:
        with core.lock():
            return [_sync_locked(oleh, force, allow_mass_delete),
                    _kamus_locked(oleh, force, allow_mass_delete)]
    except core.BusyError as e:
        return [SyncResult("sibuk", str(e))]


def _sync_locked(oleh, force, allow_mass_delete):
    cfg = core.read_config()
    state, _ = SyncState.objects.get_or_create(key="main")
    state.folder = cfg["folder"]

    try:
        sf = core.find_latest(cfg["folder"], cfg["pola"])
    except core.SourceError as e:
        return _finish(state, SyncResult("gagal", str(e)), oleh)
    if sf is None:
        return _finish(state, SyncResult(
            "tidak_ada_file", f"Tidak ada file {cfg['pola']} di {cfg['folder']}. Data di database tidak diubah."), oleh)

    # cek cepat: file yang sama persis dengan sinkron terakhir -> tidak perlu dibaca
    if (not force and state.status in ("ok", "tidak_berubah") and state.file_name == sf.name
            and state.size == sf.size and state.mtime_ns == sf.mtime_ns):
        state.last_checked = timezone.now()
        state.save()
        return SyncResult("tidak_berubah", f"Tidak ada perubahan ({sf.name}).", sf.name)

    try:
        if not core.wait_stable(sf):
            return _finish(state, SyncResult("gagal", f"{sf.name} masih berubah/sedang ditulis. Coba lagi sebentar.", sf.name), oleh)
        pr = core.parse_file(sf.path)
    except core.ParseError as e:
        return _finish(state, SyncResult("gagal", f"{sf.name}: {e}", sf.name), oleh)
    except OSError as e:
        return _finish(state, SyncResult("gagal", f"{sf.name}: tidak bisa dibaca ({e})", sf.name), oleh)

    if not force and state.sha256 == pr.sha256 and state.status in ("ok", "tidak_berubah"):
        state.file_name, state.size, state.mtime_ns = sf.name, sf.size, sf.mtime_ns
        state.last_checked = timezone.now()
        state.save()
        return SyncResult("tidak_berubah", f"Isi file tidak berubah ({sf.name}).", sf.name)

    existing = dict(Vehicle.objects.values_list("long_vin", "row_hash"))
    baru, berubah, hilang = core.compute_diff(existing, pr.by_vin)

    # pengaman: jangan hapus massal karena file salah / kosong
    if existing and not allow_mass_delete:
        mass = len(existing) >= MASS_DELETE_MIN and len(hilang) > len(existing) * MASS_DELETE_RATIO
        if mass or not pr.by_vin:
            return _finish(state, SyncResult(
                "ditahan",
                f"{sf.name} akan menghapus {len(hilang)} dari {len(existing)} data - ditahan demi keamanan. "
                f"Periksa file sumber; bila memang benar, setujui penghapusan.",
                sf.name, excluded=pr.excluded, total=pr.total), oleh)

    with transaction.atomic():
        if baru:
            Vehicle.objects.bulk_create([Vehicle(**_prep(pr.by_vin[v])) for v in baru], batch_size=500)
        for chunk in _chunks(berubah):
            objs = Vehicle.objects.in_bulk(chunk, field_name="long_vin")
            for vin, obj in objs.items():
                for k, v in _prep(pr.by_vin[vin]).items():
                    setattr(obj, k, v)
            Vehicle.objects.bulk_update(list(objs.values()), UPDATE_FIELDS, batch_size=200)
        for chunk in _chunks(hilang):
            Vehicle.objects.filter(long_vin__in=chunk).delete()
        # sabuk pengaman: apa pun yang terjadi, PlantId selain 18.72 tidak boleh ada di database
        salah = Vehicle.objects.exclude(plant_id__in=list(core.PLANT_ID_DIIZINKAN))
        if salah.exists():
            salah.delete()

    pesan = (f"{sf.name}: +{len(baru)} baru, {len(berubah)} diubah, -{len(hilang)} dihapus, "
             f"{pr.excluded} diabaikan (PlantId bukan 18.72)")
    if pr.duplicates:
        pesan += f", {pr.duplicates} VIN dobel"
    if pr.bad:
        pesan += f", {len(pr.bad)} baris rusak dilewati"
    state.file_name, state.size, state.mtime_ns, state.sha256 = sf.name, sf.size, sf.mtime_ns, pr.sha256
    state.rows_total, state.rows_used, state.rows_excluded = pr.total, len(pr.by_vin), pr.excluded
    state.last_synced = timezone.now()
    res = SyncResult("ok", pesan, sf.name, len(baru), len(berubah), len(hilang), pr.excluded, pr.total)
    return _finish(state, res, oleh)


# ------------------------------------------------------------------ kamus (sellists xml)
KAMUS_MASS_MIN = 20


def _kamus_locked(oleh, force, allow_mass_delete):
    cfg = core.read_config()
    state, _ = SyncState.objects.get_or_create(key="kamus")
    state.folder = cfg["kamus_folder"]
    R = lambda status, msg, name="", *a: SyncResult(status, "Kamus kode: " + msg, name, *a)

    try:
        sf = core.find_latest(cfg["kamus_folder"], cfg["kamus_pola"])
    except core.SourceError as e:
        return _finish(state, R("gagal", str(e)), oleh)
    if sf is None:
        return _finish(state, R("tidak_ada_file",
                       f"tidak ada file {cfg['kamus_pola']} di {cfg['kamus_folder']}. Arti kode lama (jika ada) dipertahankan."), oleh)

    if (not force and state.status in ("ok", "tidak_berubah") and state.file_name == sf.name
            and state.size == sf.size and state.mtime_ns == sf.mtime_ns):
        state.last_checked = timezone.now()
        state.save()
        return R("tidak_berubah", f"tidak ada perubahan ({sf.name}).", sf.name)

    try:
        if not core.wait_stable(sf):
            return _finish(state, R("gagal", f"{sf.name} masih berubah/sedang ditulis. Coba lagi sebentar.", sf.name), oleh)
        pr = core.parse_sellists(sf.path)
    except core.ParseError as e:
        return _finish(state, R("gagal", f"{sf.name}: {e}", sf.name), oleh)
    except OSError as e:
        return _finish(state, R("gagal", f"{sf.name}: tidak bisa dibaca ({e})", sf.name), oleh)

    if not force and state.sha256 == pr.sha256 and state.status in ("ok", "tidak_berubah"):
        state.file_name, state.size, state.mtime_ns = sf.name, sf.size, sf.mtime_ns
        state.last_checked = timezone.now()
        state.save()
        return R("tidak_berubah", f"isi file tidak berubah ({sf.name}).", sf.name)

    existing = {(l, c): raw for l, c, raw in CodeMeaning.objects.values_list("list_name", "code", "raw")}
    baru = [k for k in pr.items if k not in existing]
    berubah = [k for k, v in pr.items.items() if k in existing and existing[k] != v["raw"][:400]]
    hilang = [k for k in existing if k not in pr.items]
    if len(existing) >= KAMUS_MASS_MIN and len(hilang) > len(existing) * MASS_DELETE_RATIO and not allow_mass_delete:
        return _finish(state, R("ditahan",
                       f"{sf.name} akan menghapus {len(hilang)} dari {len(existing)} arti kode - ditahan demi keamanan. "
                       f"Periksa file; bila memang benar, setujui.", sf.name), oleh)

    with transaction.atomic():
        if baru:
            CodeMeaning.objects.bulk_create(
                [CodeMeaning(list_name=l, code=c, meaning=pr.items[(l, c)]["meaning"][:300],
                             raw=pr.items[(l, c)]["raw"][:400]) for l, c in baru], batch_size=500)
        for l, c in berubah:
            CodeMeaning.objects.filter(list_name=l, code=c).update(
                meaning=pr.items[(l, c)]["meaning"][:300], raw=pr.items[(l, c)]["raw"][:400])
        for l, c in hilang:
            CodeMeaning.objects.filter(list_name=l, code=c).delete()

    state.file_name, state.size, state.mtime_ns, state.sha256 = sf.name, sf.size, sf.mtime_ns, pr.sha256
    state.rows_total = state.rows_used = len(pr.items)
    state.last_synced = timezone.now()
    daftar = ", ".join(f"{n} {k}" for k, n in sorted(pr.counts.items()))
    return _finish(state, R("ok", f"{sf.name}: +{len(baru)} baru, {len(berubah)} diubah, -{len(hilang)} dihapus ({daftar})",
                            sf.name, len(baru), len(berubah), len(hilang)), oleh)


def kamus_loaded():
    return CodeMeaning.objects.exists()


def explain(list_name, code):
    """Arti sebuah kode. known=False -> kode belum ada di sellists (perlu ditambahkan)."""
    code = (code or "").strip()
    out = {"list": list_name, "label": core.LIST_LABELS.get(list_name, list_name), "code": code,
           "key": core.suggest_key(list_name, code), "known": False, "meaning": "", "raw": "",
           "found_as": "", "loaded": kamus_loaded()}
    if not code:
        return out
    for k in core.lookup_keys(list_name, code):
        obj = CodeMeaning.objects.filter(list_name=list_name, code=k).first()
        if obj:
            out.update(known=True, meaning=obj.meaning, raw=obj.raw, found_as=k)
            break
    out["hint"] = f'<SelListItem value="{out["key"]}" translatevalue="{out["key"]} | (isi arti kode)" />'
    return out


def code_usage():
    """{daftar: {kode: [jumlah, contoh_vin]}} dari data kendaraan di database."""
    use = {"BasicTypeNo": {}, "UpholsteryCode": {}, "ColourCode": {}}
    for vin, col, fab in Vehicle.objects.values_list("long_vin", "colour_code", "fabric_code"):
        for lst, code in (("BasicTypeNo", core.basic_type_of(vin)), ("UpholsteryCode", fab), ("ColourCode", col)):
            if code:
                e = use[lst].setdefault(code, [0, vin])
                e[0] += 1
    return use


def missing_codes():
    """Kode yang dipakai kendaraan tetapi belum ada di sellists. None bila kamus belum dimuat."""
    if not kamus_loaded():
        return None
    known = {}
    for l, c in CodeMeaning.objects.values_list("list_name", "code"):
        known.setdefault(l, set()).add(c)
    out = []
    for lst, codes in code_usage().items():
        for code, (n, sample) in codes.items():
            if not any(k in known.get(lst, set()) for k in core.lookup_keys(lst, code)):
                out.append(dict(list=lst, label=core.LIST_LABELS[lst], code=code,
                                key=core.suggest_key(lst, code), count=n, sample=sample))
    out.sort(key=lambda d: (d["list"], -d["count"], d["code"]))
    return out


# ------------------------------------------------------------------ pencarian
SORTABLE = {"long_vin", "short_vin", "model_code", "type_key", "integration_level", "vehicle_state",
            "pack_month", "updated_at_src", "vin_created_at", "lot_number", "colour_code", "fabric_code"}
FILTERS = {"model_code": "model_code", "type_key": "type_key", "integration_level": "integration_level",
           "vehicle_state": "vehicle_state", "pack_month": "pack_month", "inactive": "inactive"}


def _filtered(params, skip=None):
    """Kata pencarian + semua filter (kecuali `skip`). Belum diurutkan."""
    qs = Vehicle.objects.all()
    for tok in (params.get("q") or "").lower().split():
        qs = qs.filter(search_text__contains=tok)
    for p, f in FILTERS.items():
        if p == skip:
            continue
        v = (params.get(p) or "").strip()
        if v != "":
            qs = qs.filter(**{f: (v == "1") if f == "inactive" else v})
    return qs


def search(params):
    """params: dict sederhana (q, filter, sort, dir). Semua kata di q harus cocok (dimana saja)."""
    sort = params.get("sort") or "updated_at_src"
    if sort not in SORTABLE:
        sort = "updated_at_src"
    desc = (params.get("dir") or "desc") != "asc"
    return _filtered(params).order_by(("-" if desc else "") + sort, "long_vin")


def facets(params):
    """
    Pilihan tiap filter = nilai yang MASIH ADA setelah kata pencarian dan filter LAIN diterapkan
    (filter itu sendiri tidak dihitung, supaya pilihannya bisa diganti). Hasil: {filter: [[nilai, jumlah], ...]}
    """
    out = {}
    for p, f in FILTERS.items():
        rows = _filtered(params, skip=p).order_by().values(f).annotate(n=Count("pk")).order_by(f)
        items = []
        for r in rows:
            val = r[f]
            if f == "inactive":
                val = "1" if val else "0"
            if val is None or val == "":
                continue
            items.append([str(val), r["n"]])
        out[p] = items
    return out


def fmt_dt(dt):
    if not dt:
        return "-"
    return timezone.localtime(dt).strftime("%d.%m.%Y %H:%M:%S")


def detail(vin):
    """Semua kolom + baris BasicTypeNo (dari VIN). Kolom kode punya `ref` (arti kode / belum terdaftar)."""
    v = Vehicle.objects.filter(long_vin=vin).first()
    if not v:
        return None
    out = []
    for csv_name, fname, kind in core.FIELDS:
        val = getattr(v, fname)
        ref = None
        if kind == "dt":
            val = fmt_dt(val)
        elif kind == "bool":
            val = "1" if val else "0"
        elif val in (None, ""):
            val = "-"
        if csv_name == "ColourCode" and val != "-":
            ref = explain("ColourCode", val)
        elif csv_name == "FabricCode" and val != "-":
            ref = explain("UpholsteryCode", val)
        out.append([csv_name, str(val), ref])
        if csv_name == "LongVin":
            bt = core.basic_type_of(v.long_vin)
            out.append(["BasicTypeNo (VIN 4-7)", bt or "-", explain("BasicTypeNo", bt) if bt else None])
    return {"fields": out, "loaded": kamus_loaded()}
