from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.http import Http404, JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from . import core, services
from .models import SyncLog, SyncState, Vehicle


def _oleh(request):
    return getattr(request.user, "npk", "-")


def _flash(request, res):
    messages.add_message(request, {"success": messages.SUCCESS, "info": messages.INFO,
                                   "warning": messages.WARNING, "error": messages.ERROR}[res.level], res.message)


@login_required
def index(request):
    core.ensure_ini()
    # setiap halaman dibuka: cek apakah ada file terbaru di folder sumber
    for res in services.sync_all(_oleh(request)):
        if res.status != "tidak_berubah":
            _flash(request, res)
    state = SyncState.objects.filter(key="main").first()
    return render(request, "vehicleid/index.html", {
        "total": Vehicle.objects.count(),
        "state": state,
        "kstate": SyncState.objects.filter(key="kamus").first(),
        "missing": services.missing_codes(),
        "cfg": core.read_config(),
        "logs": SyncLog.objects.all()[:10],
        "active": "index",
    })


@login_required
def data(request):
    try:
        qs = services.search(request.GET)
        try:
            size = min(max(int(request.GET.get("size", 50)), 10), 200)
            page = max(int(request.GET.get("page", 1)), 1)
        except ValueError:
            size, page = 50, 1
        pg = Paginator(qs, size)
        pobj = pg.get_page(page)
        rows = [dict(vin=v.long_vin, short_vin=v.short_vin, model=v.model_code, type_key=v.type_key,
                     integration_level=v.integration_level, vehicle_state=v.vehicle_state,
                     pack_month=v.pack_month, colour=v.colour_code, fabric=v.fabric_code,
                     lot=v.lot_number, updated=services.fmt_dt(v.updated_at_src))
                for v in pobj]
        return JsonResponse({"total": pg.count, "page": pobj.number, "pages": pg.num_pages,
                             "start": pobj.start_index() if pg.count else 0,
                             "end": pobj.end_index() if pg.count else 0, "rows": rows,
                             "facets": services.facets(request.GET)})
    except (ValueError, TypeError):
        return JsonResponse({"error": "Filter tidak valid"}, status=400)


@login_required
def detail(request, vin):
    d = services.detail(vin)
    if d is None:
        raise Http404
    return JsonResponse({"vin": vin, "fields": d["fields"], "loaded": d["loaded"],
                         "kamus_folder": core.read_config()["kamus_folder"]})


@login_required
@require_POST
def sync(request):
    force = request.POST.get("force") == "1"
    mass = request.POST.get("mass") == "1"
    for res in services.sync_all(_oleh(request), force=force or mass, allow_mass_delete=mass):
        _flash(request, res)
    return redirect("vehicleid:index")
