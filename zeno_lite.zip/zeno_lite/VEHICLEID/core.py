"""
VEHICLEID (Vehicle Identification) - logika inti TANPA Django.
Hanya MEMBACA file csv di folder sumber (tidak pernah mengubah / menghapus file sumber).
"""
import configparser
import csv
import hashlib
import io
import os
import re
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

MODULE_DIR = Path(__file__).resolve().parent
CONFIG_INI = MODULE_DIR / "vehicle.ini"
LOCK_FILE = MODULE_DIR / ".lock"


def _general(module, tarik=False):
    """Hubungan ke general.ini di folder utama (master konfigurasi).
    tarik=False: salin general.ini -> ini modul; tarik=True: tulis ini modul -> general.ini."""
    try:
        import sys
        root = str(MODULE_DIR.parent)
        if root not in sys.path:
            sys.path.insert(0, root)
        import general_sync
        if tarik:
            general_sync.pull(module)
            return True
        general_sync.ensure_general()
        return general_sync.push_module(module)
    except Exception:
        return False

# ATURAN TETAP: hanya PlantId ini yang boleh masuk. Jangan dipindah ke ini/konfigurasi.
PLANT_ID_DIIZINKAN = frozenset({"18.72"})

DEFAULT_INI = """\
; ============================================================
;  VEHICLEID - vehicle.ini
;  folder : folder sumber file csv (nanti boleh UNC, mis. \\\\server\\share\\export)
;  pola   : pola nama file; yang dipakai adalah file TERBARU yang cocok
;  Catatan: hanya PlantId 18.72 yang diambil (aturan tetap di program).
; ============================================================

[sumber]
folder = D:\\data export
pola = *allOrders*.csv

; Kamus arti kode (warna, fabric, basic type) dari file sellists xml
[kamus]
folder = D:\\messages
pola = *sellists*en-EN*.xml
"""

KAMUS_SECTION = """
; Kamus arti kode (warna, fabric, basic type) dari file sellists xml
[kamus]
folder = D:\\messages
pola = *sellists*en-EN*.xml
"""

# (nama kolom csv, nama field model, jenis)
FIELDS = [
    ("Id", "source_id", "int"), ("FileName", "file_name", "str"),
    ("ShortVin", "short_vin", "str"), ("LongVin", "long_vin", "str"),
    ("StateId", "state_id", "int"), ("Inactive", "inactive", "bool"),
    ("FileCreatedAt", "file_created_at", "dt"), ("FileLastModifiedAt", "file_last_modified_at", "dt"),
    ("UpdatedAt", "updated_at_src", "dt"), ("TypeKey", "type_key", "str"),
    ("Model", "model_code", "str"), ("IntegrationLevel", "integration_level", "str"),
    ("PackMonth", "pack_month", "str"), ("VehicleState", "vehicle_state", "str"),
    ("Header", "header", "str"), ("PlantId", "plant_id", "str"),
    ("HybridType", "hybrid_type", "str"), ("ColourCode", "colour_code", "str"),
    ("FabricCode", "fabric_code", "str"), ("LotNumber", "lot_number", "str"),
    ("Index", "idx", "int"), ("SCBReceivedAt", "scb_received_at", "dt"),
    ("SFAReceivedAt", "sfa_received_at", "dt"), ("SFAResponseAt", "sfa_response_at", "dt"),
    ("ComInAt", "com_in_at", "dt"), ("CentralComInAt", "central_com_in_at", "dt"),
    ("CascadeF0At", "cascade_f0_at", "dt"), ("CascadeF1At", "cascade_f1_at", "dt"),
    ("CascadeF2At", "cascade_f2_at", "dt"), ("VINCreatedAt", "vin_created_at", "dt"),
    ("LastBackendRequestAt", "last_backend_request_at", "dt"), ("AIC", "aic", "int"),
    ("Ident", "ident", "str"), ("BBD", "bbd", "str"), ("BBDProvider", "bbd_provider", "str"),
    ("Name", "name", "str"), ("CreatedAt", "created_at_src", "dt"),
]
LABELS = {f: c for c, f, _ in FIELDS}
DT_FIELDS = [f for _, f, k in FIELDS if k == "dt"]
REQUIRED = ("Id", "LongVin", "PlantId")
SEARCH_FIELDS = ["long_vin", "short_vin", "file_name", "type_key", "model_code", "integration_level",
                 "pack_month", "colour_code", "fabric_code", "lot_number", "vehicle_state", "header",
                 "ident", "bbd", "name", "source_id", "state_id"]


class SourceError(Exception):
    """Folder sumber tidak bisa dibaca (drive/UNC putus, dll)."""


class ParseError(Exception):
    """File csv tidak valid / belum selesai ditulis."""


class BusyError(Exception):
    pass


class lock:
    def __enter__(self):
        if LOCK_FILE.exists() and time.time() - LOCK_FILE.stat().st_mtime > 15 * 60:
            LOCK_FILE.unlink(missing_ok=True)
        try:
            fd = os.open(LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
        except FileExistsError:
            raise BusyError("Sinkron Vehicle Identification lain sedang berjalan (web/batch). Coba lagi sebentar.")
        return self

    def __exit__(self, *exc):
        LOCK_FILE.unlink(missing_ok=True)


# ---------------------------------------------------------------- konfigurasi
def ensure_ini():
    if not CONFIG_INI.exists():
        _general("vehicleid")                # general.ini = master: salin dulu ke sini
    if not CONFIG_INI.exists():
        CONFIG_INI.write_text(DEFAULT_INI, encoding="utf-8")
        return
    txt = CONFIG_INI.read_text(encoding="utf-8", errors="replace")
    if "[kamus]" not in txt:                       # ini lama (sebelum ada kamus): tambahkan bagian baru
        CONFIG_INI.write_text(txt.rstrip() + "\n" + KAMUS_SECTION, encoding="utf-8")


def read_config():
    ensure_ini()
    cp = configparser.ConfigParser(interpolation=None)
    cp.read(CONFIG_INI, encoding="utf-8")
    sec = cp["sumber"] if cp.has_section("sumber") else {}
    kam = cp["kamus"] if cp.has_section("kamus") else {}
    return {"folder": sec.get("folder", r"D:\data export").strip(),
            "pola": sec.get("pola", "*allOrders*.csv").strip() or "*.csv",
            "kamus_folder": kam.get("folder", r"D:\messages").strip(),
            "kamus_pola": kam.get("pola", "*sellists*en-EN*.xml").strip() or "*sellists*.xml"}


# ---------------------------------------------------------------- cari file
@dataclass
class SourceFile:
    path: Path
    name: str
    size: int
    mtime_ns: int


def _name_ts(name):
    m = re.search(r"(\d{8,14})\.csv$", name, re.I)
    return int(m.group(1)) if m else 0


def find_latest(folder, pola):
    """File terbaru yang cocok. None bila folder terbaca tapi tidak ada file. SourceError bila folder tak terjangkau."""
    d = Path(folder)
    try:
        if not d.is_dir():
            raise SourceError(f"Folder sumber tidak ditemukan / tidak bisa diakses: {folder}")
        found = []
        for p in d.glob(pola):
            try:
                if p.is_file():
                    st = p.stat()
                    found.append(SourceFile(p, p.name, st.st_size, st.st_mtime_ns))
            except OSError:
                continue
    except OSError as e:
        raise SourceError(f"Folder sumber tidak bisa dibaca: {folder} ({e})")
    if not found:
        return None
    found.sort(key=lambda f: (_name_ts(f.name), f.mtime_ns))
    return found[-1]


def wait_stable(sf, tries=3, delay=1.0):
    """True bila ukuran & waktu file tidak berubah (export sudah selesai ditulis)."""
    last = (sf.size, sf.mtime_ns)
    for _ in range(tries):
        if time.time() - sf.mtime_ns / 1e9 > 3:
            cur = sf.path.stat()
            return (cur.st_size, cur.st_mtime_ns) == last
        time.sleep(delay)
        cur = sf.path.stat()
        now = (cur.st_size, cur.st_mtime_ns)
        if now == last and time.time() - cur.st_mtime > 2:
            return True
        last = now
    return False


# ---------------------------------------------------------------- baca csv
@dataclass
class ParseResult:
    by_vin: dict = field(default_factory=dict)
    total: int = 0                      # semua baris data di file
    excluded: int = 0                   # PlantId bukan 18.72
    excluded_plants: dict = field(default_factory=dict)
    bad: list = field(default_factory=list)
    duplicates: int = 0
    sha256: str = ""


def _parse_dt(s):
    s = s.strip()
    if not s or s.startswith("01.01.0001"):
        return None
    for fmt in ("%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M", "%d.%m.%Y"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    return None


def _to_int(s):
    s = s.strip()
    try:
        return int(s)
    except ValueError:
        return None


def parse_file(path):
    raw = Path(path).read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1252", errors="replace")
    rows = list(csv.reader(io.StringIO(text, newline=""), delimiter=";"))
    rows = [r for r in rows if r and any(c.strip() for c in r)]
    if not rows:
        raise ParseError("File kosong")
    header = [h.strip() for h in rows[0]]
    pos = {h: i for i, h in enumerate(header) if h}
    missing = [c for c in REQUIRED if c not in pos]
    if missing:
        raise ParseError("Format csv tidak dikenal, kolom wajib tidak ada: " + ", ".join(missing))
    ncol = len(header)
    res = ParseResult(sha256=sha)
    data = rows[1:]
    for n, r in enumerate(data):
        lineno = n + 2
        if len(r) < ncol:
            if n == len(data) - 1:
                raise ParseError(f"Baris terakhir (baris {lineno}) terpotong - file kemungkinan belum selesai ditulis")
            res.bad.append(f"baris {lineno}: jumlah kolom {len(r)} (seharusnya {ncol})")
            continue
        res.total += 1
        vals = [c.strip() for c in r[:ncol]]
        get = lambda col: vals[pos[col]] if col in pos else ""
        plant = get("PlantId")
        if plant not in PLANT_ID_DIIZINKAN:           # <- penjaga utama: PlantId selain 18.72 tidak pernah diambil
            res.excluded += 1
            res.excluded_plants[plant or "(kosong)"] = res.excluded_plants.get(plant or "(kosong)", 0) + 1
            continue
        vin = get("LongVin")
        if not vin:
            res.bad.append(f"baris {lineno}: LongVin kosong")
            continue
        rec = {}
        for csv_name, fname, kind in FIELDS:
            v = get(csv_name)
            if kind == "int":
                rec[fname] = _to_int(v)
            elif kind == "bool":
                rec[fname] = v.lower() in ("1", "true", "yes")
            elif kind == "dt":
                rec[fname] = _parse_dt(v)
            else:
                rec[fname] = v
        rec["row_hash"] = hashlib.sha1("\x1f".join(vals).encode("utf-8")).hexdigest()
        rec["search_text"] = " ".join(str(rec[f]) for f in SEARCH_FIELDS if rec[f] not in (None, "")).lower()
        if vin in res.by_vin:                       # VIN dobel: ambil yang UpdatedAt paling baru
            res.duplicates += 1
            old = res.by_vin[vin]
            if (rec["updated_at_src"] or datetime.min) < (old["updated_at_src"] or datetime.min):
                continue
        res.by_vin[vin] = rec
    return res


def compute_diff(existing, by_vin):
    """existing: {vin: row_hash} di database. Kembalikan (baru, berubah, hilang)."""
    baru = [v for v in by_vin if v not in existing]
    berubah = [v for v, r in by_vin.items() if v in existing and existing[v] != r["row_hash"]]
    hilang = [v for v in existing if v not in by_vin]
    return baru, berubah, hilang


# ---------------------------------------------------------------- kamus arti kode (sellists xml)
LIST_LABELS = {
    "BasicTypeNo": "Basic Type No (VIN posisi 4-7)",
    "UpholsteryCode": "Fabric (UpholsteryCode)",
    "ColourCode": "Warna (ColourCode)",
}


@dataclass
class DictParse:
    items: dict = field(default_factory=dict)     # (nama_daftar, kode) -> {"meaning", "raw"}
    counts: dict = field(default_factory=dict)
    sha256: str = ""


def split_meaning(tv):
    """'300 | ALPINE WHITE (AW)' -> 'ALPINE WHITE (AW)'. Bagian sebelum ' | ' hanya label kode."""
    tv = (tv or "").strip()
    head, sep, text = tv.partition(" | ")
    return (text.strip() if sep else tv) or tv


def parse_sellists(path):
    raw = Path(path).read_bytes()
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as e:
        raise ParseError(f"XML tidak valid / belum selesai ditulis: {e}")
    if root.tag != "SelLists":
        raise ParseError("Bukan file sellists (elemen utama harus <SelLists>)")
    res = DictParse(sha256=hashlib.sha256(raw).hexdigest())
    for sl in root.iter("SelList"):
        name = (sl.get("name") or "").strip()
        if not name:
            continue
        for it in sl.iter("SelListItem"):
            code = (it.get("value") or "").strip()
            if not code:
                continue
            tv = (it.get("translatevalue") or "").strip()
            res.items[(name, code)] = {"meaning": split_meaning(tv), "raw": tv}
            res.counts[name] = res.counts.get(name, 0) + 1
    if not res.items:
        raise ParseError("Tidak ada <SelListItem> di file")
    return res


def basic_type_of(vin):
    """Basic Type No = karakter ke-4 sampai ke-7 dari VIN. MHH56FV08TKA14560 -> 56FV"""
    vin = (vin or "").strip().upper()
    return vin[3:7] if len(vin) >= 7 else ""


def lookup_keys(list_name, code):
    """Kode di data vs kode di sellists: warna di csv 4 karakter (0300), di sellists 3 karakter (300)."""
    code = (code or "").strip()
    keys = [code]
    if list_name == "ColourCode" and len(code) > 1 and code.startswith("0"):
        keys.append(code[1:])
        s = code.lstrip("0")
        if s and s not in keys:
            keys.append(s)
    return keys


def suggest_key(list_name, code):
    keys = lookup_keys(list_name, code)
    return keys[1] if len(keys) > 1 else keys[0]
