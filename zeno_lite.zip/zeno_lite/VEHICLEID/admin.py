from django.contrib import admin

from .models import CodeMeaning, SyncLog, SyncState, Vehicle


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ("long_vin", "model_code", "type_key", "state_id", "vehicle_state", "pack_month", "updated_at_src")
    search_fields = ("long_vin", "short_vin", "lot_number")
    list_filter = ("model_code", "state_id", "vehicle_state")
    readonly_fields = [f.name for f in Vehicle._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


admin.site.register(SyncState)
admin.site.register(SyncLog)


@admin.register(CodeMeaning)
class CodeMeaningAdmin(admin.ModelAdmin):
    list_display = ("list_name", "code", "meaning")
    list_filter = ("list_name",)
    search_fields = ("code", "meaning")

    def has_add_permission(self, request):
        return False        # sumber kebenaran = file sellists xml
