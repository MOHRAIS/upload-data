"""
python manage.py vehicleid sync [--force] [--allow-mass-delete] [--quiet]
python manage.py vehicleid cari <kata...> [--limit N]
python manage.py vehicleid status
"""
from django.core.management.base import BaseCommand

from VEHICLEID import core, services
from VEHICLEID.models import SyncState, Vehicle

OLEH = "BATCH"


class Command(BaseCommand):
    help = "Vehicle Identification: sinkron csv ke database, cari VIN"

    def add_arguments(self, parser):
        parser.add_argument("aksi", choices=["sync", "cari", "status"])
        parser.add_argument("kata", nargs="*")
        parser.add_argument("--force", action="store_true", help="baca ulang file walau tidak berubah")
        parser.add_argument("--allow-mass-delete", action="store_true", help="setujui penghapusan massal")
        parser.add_argument("--quiet", action="store_true", help="ringkas (dipakai run.bat)")
        parser.add_argument("--limit", type=int, default=30)

    def handle(self, *a, **o):
        getattr(self, "do_" + o["aksi"])(o)

    def say(self, text, style=None):
        self.stdout.write(getattr(self.style, style)(text) if style else text)

    def do_sync(self, o):
        core.ensure_ini()
        cfg = core.read_config()
        if not o["quiet"]:
            self.say(f"Sumber: {cfg['folder']}  (pola {cfg['pola']})")
        results = services.sync_all(OLEH, force=o["force"] or o["allow_mass_delete"],
                                    allow_mass_delete=o["allow_mass_delete"])
        style = {"success": "SUCCESS", "info": None, "warning": "WARNING", "error": "ERROR"}
        for res in results:
            if o["quiet"] and res.status == "tidak_berubah":
                continue
            self.say(("[Vehicle ID] " if o["quiet"] else "") + res.message, style[res.level])
            if res.status == "ditahan":
                self.say("Untuk menyetujui: manage.bat vehicleid sync --allow-mass-delete", "WARNING")
        if o["quiet"] and all(r.status == "tidak_berubah" for r in results):
            self.say("Data kendaraan & kamus kode: tidak ada perubahan.")
        miss = services.missing_codes()
        if miss:
            self.say(f"PERHATIAN: {len(miss)} kode dipakai kendaraan tetapi BELUM ada di sellists. "
                     f"Lihat daftar: vehicleid status", "WARNING")

    def do_status(self, o):
        st = SyncState.objects.filter(key="main").first()
        cfg = core.read_config()
        self.say(f"Folder sumber : {cfg['folder']}  (pola {cfg['pola']})")
        self.say(f"Data di database: {Vehicle.objects.count()} kendaraan (hanya PlantId 18.72)")
        if st:
            self.say(f"File terakhir : {st.file_name or '-'}")
            self.say(f"Baris di file : {st.rows_total}  | dipakai: {st.rows_used}  | diabaikan (PlantId lain): {st.rows_excluded}")
            self.say(f"Sinkron terakhir: {services.fmt_dt(st.last_synced)}  | status: {st.status}")
            if st.message:
                self.say(f"Pesan: {st.message}")
        else:
            self.say("Belum pernah sinkron. Jalankan: sync")
        ks = SyncState.objects.filter(key="kamus").first()
        self.say(f"Kamus kode     : {cfg['kamus_folder']}  (pola {cfg['kamus_pola']})")
        if ks:
            self.say(f"  file: {ks.file_name or '-'} | {ks.rows_used} arti kode | status: {ks.status}")
            if ks.status in ("gagal", "tidak_ada_file", "ditahan"):
                self.say(f"  {ks.message}", "WARNING")
        miss = services.missing_codes()
        if miss is None:
            self.say("  Kamus belum dimuat, daftar kode yang belum terdaftar belum bisa dicek.", "WARNING")
        elif not miss:
            self.say("  Semua kode kendaraan sudah ada di sellists.", "SUCCESS")
        else:
            self.say(f"  {len(miss)} kode BELUM ada di sellists (tambahkan ke XML):", "WARNING")
            self.say(f"  {'Daftar':16}{'Kode':8}{'Tulis sbg':11}{'Jumlah':8}Contoh VIN")
            for m in miss[:40]:
                self.say(f"  {m['list']:16}{m['code']:8}{m['key']:11}{m['count']:<8}{m['sample']}")
            if len(miss) > 40:
                self.say(f"  ... dan {len(miss) - 40} lainnya")

    def do_cari(self, o):
        q = " ".join(o["kata"]).strip()
        if not q:
            return self.say("Ketik kata yang dicari (VIN, model, type, lot, dst).", "WARNING")
        qs = services.search({"q": q})
        total = qs.count()
        self.say(f"Cari '{q}': {total} hasil" + (f" (ditampilkan {o['limit']} teratas)" if total > o["limit"] else ""), "MIGRATE_HEADING")
        if not total:
            return
        self.say(f"{'VIN':18}{'Model':7}{'TypeKey':9}{'IntegrationLevel':18}{'VState':7}{'Pack':6}{'Lot':12}{'UpdatedAt'}")
        for v in qs[:o["limit"]]:
            self.say(f"{v.long_vin:18}{v.model_code:7}{v.type_key:9}{v.integration_level:18}{v.vehicle_state:7}"
                     f"{v.pack_month:6}{v.lot_number:12}{services.fmt_dt(v.updated_at_src)}")
