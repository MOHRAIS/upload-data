from django.urls import path

from . import views

app_name = "vehicleid"

urlpatterns = [
    path("", views.index, name="index"),
    path("data/", views.data, name="data"),
    path("detail/<str:vin>/", views.detail, name="detail"),
    path("sync/", views.sync, name="sync"),
]
