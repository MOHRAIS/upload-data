from django.db import models

from .core import PLANT_ID_DIIZINKAN


class Vehicle(models.Model):
    """Cermin isi file csv sumber (hanya PlantId 18.72). Jangan diubah manual - disinkronkan dari csv."""
    long_vin = models.CharField("VIN (LongVin)", max_length=30, unique=True)
    source_id = models.BigIntegerField(null=True, blank=True, db_index=True)
    file_name = models.CharField(max_length=100, blank=True)
    short_vin = models.CharField(max_length=20, blank=True, db_index=True)
    state_id = models.BigIntegerField(null=True, blank=True, db_index=True)
    inactive = models.BooleanField(default=False)
    file_created_at = models.DateTimeField(null=True, blank=True)
    file_last_modified_at = models.DateTimeField(null=True, blank=True)
    updated_at_src = models.DateTimeField(null=True, blank=True, db_index=True)
    type_key = models.CharField(max_length=20, blank=True, db_index=True)
    model_code = models.CharField(max_length=20, blank=True, db_index=True)
    integration_level = models.CharField(max_length=40, blank=True)
    pack_month = models.CharField(max_length=10, blank=True, db_index=True)
    vehicle_state = models.CharField(max_length=10, blank=True, db_index=True)
    header = models.CharField(max_length=10, blank=True)
    plant_id = models.CharField(max_length=10, blank=True)
    hybrid_type = models.CharField(max_length=10, blank=True)
    colour_code = models.CharField(max_length=10, blank=True)
    fabric_code = models.CharField(max_length=10, blank=True)
    lot_number = models.CharField(max_length=30, blank=True)
    idx = models.BigIntegerField(null=True, blank=True)
    scb_received_at = models.DateTimeField(null=True, blank=True)
    sfa_received_at = models.DateTimeField(null=True, blank=True)
    sfa_response_at = models.DateTimeField(null=True, blank=True)
    com_in_at = models.DateTimeField(null=True, blank=True)
    central_com_in_at = models.DateTimeField(null=True, blank=True)
    cascade_f0_at = models.DateTimeField(null=True, blank=True)
    cascade_f1_at = models.DateTimeField(null=True, blank=True)
    cascade_f2_at = models.DateTimeField(null=True, blank=True)
    vin_created_at = models.DateTimeField(null=True, blank=True)
    last_backend_request_at = models.DateTimeField(null=True, blank=True)
    aic = models.BigIntegerField(null=True, blank=True)
    ident = models.CharField(max_length=60, blank=True)
    bbd = models.CharField(max_length=60, blank=True)
    bbd_provider = models.CharField(max_length=60, blank=True)
    name = models.CharField(max_length=100, blank=True)
    created_at_src = models.DateTimeField(null=True, blank=True)
    row_hash = models.CharField(max_length=40, editable=False)
    search_text = models.TextField(editable=False, blank=True)
    first_seen = models.DateTimeField(auto_now_add=True)
    synced_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["long_vin"]
        verbose_name = "Kendaraan"
        verbose_name_plural = "Kendaraan"

    def save(self, *args, **kwargs):
        if self.plant_id not in PLANT_ID_DIIZINKAN:
            raise ValueError("PlantId selain 18.72 tidak boleh disimpan.")
        super().save(*args, **kwargs)

    def __str__(self):
        return self.long_vin


class SyncState(models.Model):
    """Keadaan sinkron terakhir (satu baris, key='main')."""
    key = models.CharField(max_length=20, unique=True, default="main")
    folder = models.CharField(max_length=300, blank=True)
    file_name = models.CharField(max_length=200, blank=True)
    size = models.BigIntegerField(default=0)
    mtime_ns = models.BigIntegerField(default=0)
    sha256 = models.CharField(max_length=64, blank=True)
    rows_total = models.IntegerField(default=0)
    rows_used = models.IntegerField(default=0)
    rows_excluded = models.IntegerField(default=0)
    last_checked = models.DateTimeField(null=True, blank=True)
    last_synced = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, blank=True)
    message = models.TextField(blank=True)


class SyncLog(models.Model):
    waktu = models.DateTimeField(auto_now_add=True)
    oleh = models.CharField(max_length=60, blank=True)
    status = models.CharField(max_length=20)
    file_name = models.CharField(max_length=200, blank=True)
    ditambah = models.IntegerField(default=0)
    diubah = models.IntegerField(default=0)
    dihapus = models.IntegerField(default=0)
    diabaikan = models.IntegerField(default=0)
    pesan = models.TextField(blank=True)

    class Meta:
        ordering = ["-waktu", "-id"]


class CodeMeaning(models.Model):
    """Cermin file sellists xml: arti kode (BasicTypeNo, UpholsteryCode = fabric, ColourCode = warna)."""
    list_name = models.CharField(max_length=40, db_index=True)
    code = models.CharField(max_length=30)
    meaning = models.CharField(max_length=300, blank=True)
    raw = models.CharField(max_length=400, blank=True)

    class Meta:
        unique_together = ("list_name", "code")
        ordering = ["list_name", "code"]
        verbose_name = "Arti kode"
        verbose_name_plural = "Arti kode"

    def __str__(self):
        return f"{self.list_name}:{self.code} = {self.meaning}"
