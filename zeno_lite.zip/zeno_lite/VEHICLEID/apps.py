from django.apps import AppConfig


class VehicleidConfig(AppConfig):
    name = "VEHICLEID"
    label = "vehicleid"
    verbose_name = "Vehicle Identification"
    default_auto_field = "django.db.models.BigAutoField"
