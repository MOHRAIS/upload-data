@echo off
title Vehicle Identification
call "%~dp0_prep.bat"
if errorlevel 1 exit /b 1
rem Setiap batch dijalankan, folder sumber dicek dan database disamakan
venv\Scripts\python.exe manage.py vehicleid sync --quiet

:menu
echo.
echo ==============================
echo     VEHICLE IDENTIFICATION
echo ==============================
echo   [1] Cari VIN / kata apa saja
echo   [2] Cek ^& sinkron file terbaru
echo   [3] Status
echo   [0] Keluar
echo.
choice /c 1230 /n /m "Pilih menu: "
if errorlevel 4 goto :eof
if errorlevel 3 (venv\Scripts\python.exe manage.py vehicleid status & goto :menu)
if errorlevel 2 (venv\Scripts\python.exe manage.py vehicleid sync & goto :menu)
if errorlevel 1 goto :cari
goto :menu

:cari
echo.
set "Q="
set /p "Q=Cari (VIN, 7 digit akhir, model, type, lot...): "
if not defined Q goto :menu
venv\Scripts\python.exe manage.py vehicleid cari %Q%
goto :menu
