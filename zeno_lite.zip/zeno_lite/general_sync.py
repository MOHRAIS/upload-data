"""
general.ini  ->  file .ini tiap modul.  Hanya memakai library bawaan Python (tanpa Django).

  general.ini adalah MASTER konfigurasi semua modul. Nama bagian = <modul>.<bagian>:

      [absroll.pengaturan]   ->  ABSROLL\\client.ini     [pengaturan]
      [vehicleid.sumber]     ->  VEHICLEID\\vehicle.ini  [sumber]
      [dombtrv.model]        ->  DOMBTRV\\dombtrv.ini    [model]

Pemakaian:
  python general_sync.py            salin general.ini ke semua modul (dipanggil run.bat / menu.bat / _prep.bat)
  python general_sync.py --quiet    sama, tanpa keterangan bila tidak ada perubahan
  python general_sync.py --pull absroll
                                    kebalikan: tulis isi client.ini ke general.ini (dipakai halaman web Target client)
  python general_sync.py --get aplikasi port 8182
                                    cetak satu nilai dari general.ini (dipakai run.bat); argumen terakhir = nilai bawaan
  python general_sync.py --lan      cetak alamat IP komputer ini di jaringan (untuk HP / komputer lain)
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
GENERAL_INI = ROOT / "general.ini"

# bagian milik aplikasi secara keseluruhan (bukan modul): tidak disalin ke modul mana pun
GLOBAL_SECTIONS = ("aplikasi",)

# modul -> (file ini modul, judul)
MODULES = {
    "absroll": (ROOT / "ABSROLL" / "client.ini", "ABSROLL"),
    "vehicleid": (ROOT / "VEHICLEID" / "vehicle.ini", "VEHICLEID"),
    "dombtrv": (ROOT / "DOMBTRV" / "dombtrv.ini", "DOMBTRV"),
}

DEFAULT_GENERAL = """\
; ============================================================
;  ZENO LITE - general.ini   (PUSAT KONFIGURASI SEMUA MODUL)
;
;  File ini adalah MASTER. Setiap kali run.bat, menu.bat, atau batch modul
;  dijalankan, isinya disalin ke file .ini milik tiap modul:
;
;      [absroll.*]    ->  ABSROLL\\client.ini
;      [vehicleid.*]  ->  VEHICLEID\\vehicle.ini
;      [dombtrv.*]    ->  DOMBTRV\\dombtrv.ini
;
;  Jadi ubah pengaturan DI SINI. Perubahan yang dibuat langsung di file .ini modul
;  akan ditimpa (salinan lamanya disimpan sebagai <nama>.ini.bak).
;  Pengecualian: target client yang diubah lewat halaman web ABSROLL (Target client)
;  otomatis ditulis balik ke sini.
;
;  Nama bagian = <modul>.<bagian>.  Nilai ya/tidak ditulis true / false.
;  Path boleh UNC (\\\\server\\share\\folder).
;  Perubahan baru berlaku setelah run.bat / batch dijalankan lagi.
; ============================================================


; ############################################################
;  APLIKASI (berlaku untuk seluruh aplikasi, dibaca run.bat)
; ############################################################
;  port           : nomor port web (alamat: http://127.0.0.1:<port>)
;  akses_jaringan : false = hanya bisa dibuka dari komputer ini (aman)
;                   true  = bisa dibuka dari HP / komputer lain di jaringan yang sama
;                           lewat http://<IP-komputer-ini>:<port>  (alamatnya ditampilkan run.bat).
;                   Aktifkan hanya di jaringan tepercaya dan ganti password admin lebih dulu.
;                   Windows akan menanyakan izin firewall saat pertama kali.

[aplikasi]
port = 8182
akses_jaringan = false


; ############################################################
;  ABSROLL  ->  ABSROLL\\client.ini
; ############################################################
;  jenis        : ABS+ROLL (client butuh ABS dan Roller)  atau  ABS (hanya ABS)
;  abs_path     : folder tujuan file ABS.*.mdb
;  roll_path    : folder tujuan file Roll.*.mdb (kosongkan untuk jenis ABS)
;  version_path : folder tujuan version.txt (kosong = sama dengan abs_path)
;  Path relatif dihitung dari folder ABSROLL. Ganti path contoh dengan folder client yang asli.

[absroll.pengaturan]
max_backup = 4
keep_processed = 10

[absroll.client1]
nama = Client ABS + Roller
jenis = ABS+ROLL
abs_path = data/client_demo/client1/ABS
roll_path = data/client_demo/client1/Roll
version_path = data/client_demo/client1

[absroll.client2]
nama = Client ABS saja
jenis = ABS
abs_path = data/client_demo/client2/ABS
roll_path =
version_path = data/client_demo/client2


; ############################################################
;  VEHICLE IDENTIFICATION  ->  VEHICLEID\\vehicle.ini
; ############################################################
;  folder : folder sumber file csv (boleh UNC)
;  pola   : pola nama file; yang dipakai adalah file TERBARU yang cocok
;  Catatan: hanya PlantId 18.72 yang diambil (aturan tetap di program).

[vehicleid.sumber]
folder = D:\\data export
pola = *allOrders*.csv

;  Kamus arti kode (warna, fabric, basic type) dari file sellists xml
[vehicleid.kamus]
folder = D:\\messages
pola = *sellists*en-EN*.xml


; ############################################################
;  DOM/BTRV  ->  DOMBTRV\\dombtrv.ini
; ############################################################
;  folder       : folder sumber file xml (boleh UNC)
;  pola         : pola nama file
;  subfolder    : true = ikut scan semua subfolder, false = hanya folder itu saja
;  interval_jam : jadwal scan (jam). Untuk penanda "data sudah lama" dan Task Scheduler.
;  hapus_hilang : true = data file yang sudah tidak ada di folder ikut dihapus dari database,
;                 false = data lama dipertahankan

[dombtrv.sumber]
folder = D:\\Data\\Delete
pola = *.xml
subfolder = false

[dombtrv.jadwal]
interval_jam = 2

[dombtrv.pengaturan]
ini_versi = 2
hapus_hilang = false

;  Update file model xml (Part List) ke server
;  folder_server : folder induk di server (berisi G05, G20, ... masing-masing dengan Archive)
;  nama_file     : nama file di tiap folder model (sama untuk semua model)
;  max_backup    : jumlah versi lama yang disimpan di aplikasi untuk rollback (per model)
[dombtrv.model]
folder_server = D:\\models
nama_file = model.xml
max_backup = 4
"""


# ----------------------------------------------------------------------------
# Baca / tulis ini sederhana (tanpa configparser supaya urutan, huruf besar-kecil, dan komentar terjaga)
# ----------------------------------------------------------------------------
def _read_text(path):
    return Path(path).read_text(encoding="utf-8-sig", errors="replace")


def _key_of(line):
    s = line.strip()
    if not s or s[0] in ";#" or s.startswith("["):
        return None
    if "=" not in s:
        return None
    return s.split("=", 1)[0].strip()


def _header_of(line):
    s = line.strip()
    if s.startswith("[") and s.endswith("]") and len(s) > 2:
        return s[1:-1].strip()
    return None


def parse_sections(text):
    """-> list [(nama_bagian, [(kunci, nilai), ...])] sesuai urutan file (bagian kembar digabung)."""
    out, index = [], {}
    cur = None
    for line in text.splitlines():
        h = _header_of(line)
        if h is not None:
            if h not in index:
                index[h] = []
                out.append((h, index[h]))
            cur = index[h]
            continue
        k = _key_of(line)
        if k is not None and cur is not None:
            cur.append((k, line.split("=", 1)[1].strip()))
    return out


def _module_view(sections, module):
    """Bagian milik satu modul dari general.ini: [(nama tanpa awalan, items)]."""
    pre = module + "."
    return [(n[len(pre):], items) for n, items in sections if n.lower().startswith(pre) and len(n) > len(pre)]


def _same(a, b):
    """Dua daftar bagian dianggap sama bila urutan bagian dan isi (kunci -> nilai) sama."""
    if [n for n, _ in a] != [n for n, _ in b]:
        return False
    return all(dict(x) == dict(y) for (_, x), (_, y) in zip(a, b))


def _render_module(module, sections):
    ini_path, title = MODULES[module]
    lines = [
        "; ============================================================",
        f";  {title} - {ini_path.name}",
        ";  DIBUAT OTOMATIS dari general.ini (folder utama). Ubah pengaturan di general.ini,",
        ";  bukan di sini: perubahan di file ini akan ditimpa saat run.bat / batch dijalankan.",
        "; ============================================================",
        "",
    ]
    for name, items in sections:
        lines.append(f"[{name}]")
        for k, v in items:
            lines.append(f"{k} = {v}".rstrip())
        lines.append("")
    return "\n".join(lines)


def _write(path, text, crlf=True):
    with open(path, "w", encoding="utf-8", newline="\r\n" if crlf else "\n") as f:
        f.write(text if text.endswith("\n") else text + "\n")


# ----------------------------------------------------------------------------
# general.ini  ->  modul
# ----------------------------------------------------------------------------
def ensure_general():
    """Pastikan general.ini ada. Bila belum: pakai bawaan, lalu timpa dengan isi ini modul yang sudah ada."""
    if GENERAL_INI.exists():
        return False
    _write(GENERAL_INI, DEFAULT_GENERAL)
    for module, (ini_path, _) in MODULES.items():
        if ini_path.exists():
            pull(module)
    return True


def push_module(module):
    """Salin bagian modul dari general.ini ke ini modul. Mengembalikan True bila ini modul berubah."""
    ini_path, _ = MODULES[module]
    want = _module_view(parse_sections(_read_text(GENERAL_INI)), module)
    if not want:
        return False
    if ini_path.exists() and _same(want, parse_sections(_read_text(ini_path))):
        return False
    if ini_path.exists():
        try:
            (ini_path.parent / (ini_path.name + ".bak")).write_bytes(ini_path.read_bytes())
        except OSError:
            pass
    ini_path.parent.mkdir(parents=True, exist_ok=True)
    _write(ini_path, _render_module(module, want))
    return True


def push_all(quiet=False):
    created = ensure_general()
    if created and not quiet:
        print("  general.ini belum ada: dibuat dari pengaturan bawaan / ini modul yang sudah ada.")
    changed = []
    for module in MODULES:
        try:
            if push_module(module):
                changed.append(module)
        except OSError as e:
            print(f"  [PERINGATAN] {MODULES[module][0].name} tidak bisa ditulis: {e}")
    known = {m for m in MODULES} | set(GLOBAL_SECTIONS)
    for name, _ in parse_sections(_read_text(GENERAL_INI)):
        if name.split(".")[0].lower() not in known and not quiet:
            print(f"  [PERINGATAN] general.ini: bagian [{name}] tidak dikenali (awalan harus absroll./vehicleid./dombtrv.)")
    if changed:
        for m in changed:
            print(f"  general.ini -> {MODULES[m][0].parent.name}\\{MODULES[m][0].name} diperbarui")
    elif not quiet:
        print("  general.ini: semua modul sudah sama.")
    return changed


# ----------------------------------------------------------------------------
# modul  ->  general.ini   (dipakai bila ini modul diubah lewat aplikasi, mis. Target client)
# ----------------------------------------------------------------------------
def pull(module):
    """Tulis isi ini modul ke general.ini (komentar & bagian modul lain dibiarkan)."""
    ini_path, _ = MODULES[module]
    if not GENERAL_INI.exists():
        _write(GENERAL_INI, DEFAULT_GENERAL)
    new_secs = parse_sections(_read_text(ini_path))
    lines = _read_text(GENERAL_INI).splitlines()

    # pecah menjadi blok: (nama | None untuk pembuka file, [baris]); komentar yang menempel di atas header ikut blok itu
    blocks, cur_name, cur = [], None, []
    for line in lines:
        if _header_of(line) is not None:
            lead = []
            while cur and cur[-1].strip()[:1] in (";", "#"):
                lead.insert(0, cur.pop())
            blocks.append((cur_name, cur))
            cur_name, cur = _header_of(line), lead + [line]
        else:
            cur.append(line)
    blocks.append((cur_name, cur))

    pre = module + "."
    new_by_name = {pre + n: items for n, items in new_secs}
    out, seen, last_idx = [], set(), None
    for name, body in blocks:
        if name is not None and name.lower().startswith(pre):
            if name not in new_by_name:
                continue                                   # bagian sudah dihapus di modul
            seen.add(name)
            body = _update_block(body, new_by_name[name])
        out.append((name, body))
        if name is not None and name.lower().startswith(pre):
            last_idx = len(out) - 1
    add = []
    for name, items in new_secs:
        full = pre + name
        if full not in seen:
            add.append((full, ["", f"[{full}]"] + [f"{k} = {v}".rstrip() for k, v in items]))
    at = len(out) if last_idx is None else last_idx + 1
    out[at:at] = add

    text_lines = []
    for _, body in out:
        text_lines.extend(body)
    _write(GENERAL_INI, "\n".join(text_lines).rstrip("\n") + "\n")


def _update_block(body, items):
    want = dict(items)
    order = [k for k, _ in items]
    done, out = set(), []
    for line in body:
        k = _key_of(line)
        if k is None:
            out.append(line)
        elif k in want:
            out.append(f"{k} = {want[k]}".rstrip())
            done.add(k)
        # kunci yang sudah tidak ada di modul dibuang
    tail = []
    while out and not out[-1].strip():
        tail.append(out.pop())
    out.extend(f"{k} = {want[k]}".rstrip() for k in order if k not in done)
    out.extend(tail)
    return out


def get(section, key, default=""):
    """Nilai satu kunci dari general.ini (bagian dicari tanpa membedakan huruf besar-kecil)."""
    try:
        for name, items in parse_sections(_read_text(GENERAL_INI)):
            if name.lower() == section.lower():
                for k, v in items:
                    if k.lower() == key.lower():
                        return v if v != "" else default
    except OSError:
        pass
    return default


def lan_ip():
    import socket
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sk:
            sk.connect(("10.255.255.255", 1))          # tidak ada paket yang dikirim; hanya memilih antarmuka
            return sk.getsockname()[0]
    except OSError:
        return ""


def main(argv):
    quiet = "--quiet" in argv
    if "--get" in argv:
        i = argv.index("--get")
        a = argv[i + 1:i + 4] + ["", ""]
        print(get(a[0], a[1], a[2]))
        return 0
    if "--lan" in argv:
        print(lan_ip())
        return 0
    if "--pull" in argv:
        i = argv.index("--pull")
        module = argv[i + 1].lower() if i + 1 < len(argv) else ""
        if module not in MODULES:
            print("Modul harus salah satu dari:", ", ".join(MODULES))
            return 1
        pull(module)
        return 0
    push_all(quiet=quiet)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
