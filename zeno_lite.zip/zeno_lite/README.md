# Zeno Lite

Aplikasi web lokal (Django + SQLite + Python) dengan beberapa modul. Setiap modul bisa dipakai
**lewat aplikasi (browser)** maupun **lewat file batch (.bat)**, dan keduanya memakai logika dan database yang sama.

- Berjalan lokal di `http://127.0.0.1:8182`
- Login memakai **NPK + password**
- Satu folder per modul (kode, konfigurasi, batch, dan data modul ada di dalam folder itu)

| Modul | Folder | Fungsi singkat |
|---|---|---|
| ABSROLL | `ABSROLL\` | Distribusi file mdb ABS dan Roller ke client, tracking versi, backup, rollback |
| Vehicle Identification | `VEHICLEID\` | Membaca csv export kendaraan (PlantId 18.72), cari VIN, arti kode warna/fabric/basic type |
| DOM/BTRV | `DOMBTRV\` | Scan file xml AddOnPart, cari dan filter VIN, PartNo, SerialNo; update file model XML (Part List) ke server dengan compare, backup, rollback; Emergency Barcode (nilai DMC dummy + Data Matrix) |

---

## 1. Menjalankan

**Prasyarat:** Python terpasang dan masuk PATH. Internet hanya dibutuhkan saat pertama kali (memasang Django).

1. Klik dua kali **`menu.bat`** lalu pilih `[1]` (atau langsung **`run.bat`**).
2. Edge terbuka otomatis ke `http://127.0.0.1:8182` (jika tidak ada: Chrome, lalu browser default).
3. Login pertama: **NPK `00001`**, **password `admin123`** (segera ganti).

Yang dilakukan `run.bat`:

1. Membuat virtual environment `venv` (sekali).
2. Memasang dependensi dari `requirements.txt` (sekali; penanda: `venv\.deps_ok`).
3. **Menyalin `general.ini` ke file `.ini` tiap modul** (`general_sync.py`).
4. `makemigrations` + `migrate` (membuat/ memperbarui tabel database semua modul).
5. Membuat akun admin awal jika belum ada user.
6. Mengecek file terbaru Vehicle Identification (`vehicleid sync --quiet`).
7. Menjalankan server dan membuka browser.

Menutup jendela batch atau menekan `CTRL+C` menghentikan aplikasi.

### Menu utama (`menu.bat`)
Semua file batch bisa dibuka dari satu tempat di folder utama. Jalankan **`menu.bat`**, pilih nomor, batch yang dipilih baru dijalankan; selesai/keluar dari batch itu Anda kembali ke menu.

| Pilihan | Menjalankan |
|---|---|
| 1 | `run.bat` (aplikasi web) |
| 2 / 3 | `ABSROLL\absroll.bat` (menu) / `ABSROLL\sync.bat` |
| 4 / 5 | `VEHICLEID\vehicleid.bat` (menu) / `VEHICLEID\sync.bat` |
| 6 | `DOMBTRV\dombtrv.bat` |
| 7 / 8 / 9 | `DOMBTRV\model.bat` / `DOMBTRV\emergency.bat` / `DOMBTRV\scan_terjadwal.bat` |
| G | Membuka `general.ini` di Notepad |
| S | Menerapkan `general.ini` ke semua modul sekarang |

Setiap kali menu ditampilkan, `general.ini` otomatis disalin ke modul. Batch di folder modul tetap bisa dijalankan langsung seperti biasa.

### Pengaturan pusat (`general.ini`)
`general.ini` (di folder utama, sejajar `run.bat`) adalah **master konfigurasi semua modul**. Isinya sama dengan `client.ini`, `vehicle.ini`, dan `dombtrv.ini`; nama bagian diberi awalan modul:

| Bagian di `general.ini` | Disalin ke |
|---|---|
| `[absroll.pengaturan]`, `[absroll.client1]`, ... | `ABSROLL\client.ini` |
| `[vehicleid.sumber]`, `[vehicleid.kamus]` | `VEHICLEID\vehicle.ini` |
| `[dombtrv.sumber]`, `[dombtrv.jadwal]`, `[dombtrv.pengaturan]`, `[dombtrv.model]` | `DOMBTRV\dombtrv.ini` |

- Ubah pengaturan **di `general.ini`**. Penyalinan ke modul terjadi saat `run.bat`, `menu.bat`, atau batch modul mana pun dijalankan (server yang sedang berjalan baru memakai nilai baru setelah `run.bat` dijalankan ulang).
- File `.ini` di folder modul sekarang **hasil salinan**: perubahan langsung di sana akan ditimpa; salinan lamanya disimpan sebagai `<nama>.ini.bak`.
- **Target client** yang diubah di halaman web ABSROLL otomatis ditulis balik ke `general.ini`, jadi tidak ada yang hilang.
- Untuk menambah client baru: tambahkan bagian `[absroll.client3]` (isi sama seperti `client1`).
- Bila `general.ini` dihapus, dibuat ulang dari isi `.ini` modul yang ada (atau nilai bawaan).
- Perintah manual: `venv\Scripts\python.exe general_sync.py`.

### Tampilan dan akses dari HP
- Tampilan responsif: di komputer menu ada di sisi kiri; di HP/tablet menu menjadi laci yang dibuka dengan tombol tiga garis. Di komputer tombol yang sama mengecilkan menu menjadi deretan ikon (arahkan kursor ke ikon modul untuk melihat isinya). Pilihan ini dan grup menu yang dibuka diingat di browser. Tampilan hanya mode terang.
- Tabel pencarian (Vehicle Identification dan DOM/BTRV) otomatis menjadi daftar kartu di layar sempit.
- Agar bisa dibuka dari HP, atur di `general.ini`:
  ```ini
  [aplikasi]
  port = 8182
  akses_jaringan = true
  ```
  Jalankan `run.bat`; jendelanya menampilkan alamat untuk HP, mis. `http://192.168.1.20:8182` (HP harus di Wi-Fi/jaringan yang sama). Windows akan menanyakan izin firewall saat pertama kali: izinkan untuk jaringan privat.
- Bawaannya `akses_jaringan = false` (hanya komputer ini). Saat `true`, siapa pun di jaringan yang sama bisa membuka halaman login, jadi **ganti password admin lebih dulu** dan jangan aktifkan di jaringan umum. Mode ini juga mematikan halaman error rinci (`DEBUG`).

### Perintah manage.py
`python manage.py ...` di terminal biasa akan gagal (`No module named 'django'`) karena Django ada di `venv`. Gunakan:

```
manage.bat createsuperuser
manage.bat changepassword 00001
manage.bat vehicleid status
```

atau aktifkan venv dulu: `venv\Scripts\activate`.

### Menambah user
`http://127.0.0.1:8182/admin/` (akun admin), atau `manage.bat createsuperuser`. NPK dipakai sebagai username.

---

## 2. Struktur folder

```
zeno_lite\
├── run.bat                 jalankan aplikasi
├── menu.bat                menu semua file batch (pilih mana yang dijalankan)
├── general.ini             pengaturan pusat semua modul (master)
├── general_sync.py         menyalin general.ini ke .ini tiap modul
├── static\zeno\            app.css + app.js (tampilan dan perilaku antarmuka semua halaman)
├── manage.bat              manage.py yang otomatis memakai venv
├── manage.py
├── requirements.txt
├── README.md
├── config\                 settings, urls Django
├── accounts\               login NPK + dashboard
├── templates\              base.html, shell.html (sidebar + topbar), _nav.html (isi menu), module_base.html
├── ABSROLL\                modul 1  (kode + data + client.ini + version.txt + .bat)
├── VEHICLEID\              modul 2  (kode + vehicle.ini + .bat)
├── DOMBTRV\                modul 3  (kode + dombtrv.ini + .bat)
├── db.sqlite3              database (dibuat otomatis)
└── venv\                   virtual environment (dibuat otomatis)
```

Isi tiap folder modul memakai pola yang sama:

| Berkas | Fungsi |
|---|---|
| `core.py` | Logika inti **tanpa Django** (baca file, bandingkan, kunci, dll) |
| `services.py` | Penghubung core dengan database; dipakai bersama oleh web dan batch |
| `models.py`, `admin.py`, `apps.py`, `migrations\` | Database Django |
| `views.py`, `urls.py`, `templates\` | Halaman web |
| `management\commands\<modul>.py` | Perintah untuk batch (`manage.py <modul> ...`) |
| `*.bat` | File batch |
| `*.ini` | Konfigurasi yang bisa diedit |

Zona waktu aplikasi: `Asia/Jakarta`. Bahasa: Indonesia. Port dan host diatur di `run.bat` (`HOST`, `PORT`).

---

## 3. Aturan penting (berlaku di semua modul)

- **Folder sumber hanya dibaca.** Vehicle Identification dan DOM/BTRV tidak pernah mengubah, memindah, atau menghapus file sumber.
- **File ABSROLL tidak pernah ditimpa.** File lama dipindah ke `data\backup` untuk rollback.
- **Waktu modifikasi (modtime) mdb dipertahankan** saat dikirim ke client: sama dengan yang tercatat di dalam zip.
- **Vehicle Identification hanya mengambil PlantId `18.72`.** Baris lain tidak pernah masuk database (dijaga di 3 tempat; nilainya tertulis tetap di program, bukan di `.ini`).
- **Pengaman penghapusan massal:** jika file sumber baru akan menghapus lebih dari 50% data yang ada (dan data sudah ≥ 100; kamus ≥ 20), proses **ditahan** dan butuh persetujuan lewat tombol/`--allow-mass-delete`.
- **Folder sumber tidak terjangkau** (drive/UNC putus), file belum selesai ditulis, atau format rusak: **database tidak diubah**.
- **Kunci (`.lock`)** mencegah web, batch, dan scheduler mengubah data bersamaan. Kunci dianggap basi setelah 15 menit.
- **Konfigurasi di `general.ini`** (master, folder utama); file `.ini` modul adalah salinannya. Nilai ya/tidak ditulis **`true` / `false`**.
- Path boleh **UNC** (`\\server\share\folder`). Untuk pindah dari `D:\...` ke UNC cukup ubah `.ini`.

---

## 4. Modul ABSROLL

Mengirim file **mdb** ke client, dengan tracking versi, backup, dan rollback.

### Alur
1. Taruh `ABS.zip` / `Roller.zip` di `ABSROLL\data\new` (atau unggah lewat web).
2. Jalankan sinkron (`ABSROLL\sync.bat` atau halaman web).
3. Zip luar diekstrak; zip dalam bernama **`Tipe.Kode.Versi.zip`** diperiksa, contoh `Roll.W58.08.02.00.02.zip` → tipe `Roll`, kode `W58`, versi `08.02.00.02`. Tipe yang dikenal: `ABS` dan `Roll`. Di dalam tiap zip ada satu file `.mdb`.
4. Aplikasi membuat **rencana** dan meminta konfirmasi per item:

| Status | Arti |
|---|---|
| BARU | Tipe.Kode belum ada |
| UPDATE | Versi lebih baru dari yang berjalan |
| VERSI LEBIH LAMA | Konfirmasi tambahan (berarti rollback) |
| VERSI SAMA, ISI BERBEDA | Nomor versi sama tetapi isi mdb beda |
| SUDAH SAMA | Dilewati |

5. Jika satu paket berisi beberapa versi untuk Tipe.Kode yang sama (mis. `Roll.W6` `.16` dan `.17`), **hanya versi terbaru** yang diambil.
6. Yang diterapkan: zip lama → `data\backup`, zip baru → `data\existing`, lalu mdb dan `version.txt` dikirim ke client.
7. File yang selesai diproses dipindah ke `data\processed` (disimpan 10 terakhir).

### Folder data
| Folder | Isi |
|---|---|
| `data\new` | Taruh file baru di sini |
| `data\existing` | Zip versi yang sedang berjalan (1 per Tipe.Kode) |
| `data\backup` | Zip lama untuk rollback, nama `YYYYMMDD-HHMMSS__<nama zip>`; **maks 4 per Tipe.Kode** |
| `data\processed` | Arsip file yang sudah diproses |

### Versi dan client
- Versi tercatat di **database** dan **`ABSROLL\version.txt`** (format `Tipe.Kode=Versi`); keduanya selalu disamakan otomatis.
- Target client ada di **`general.ini`** (bagian `[absroll.*]`, disalin ke `ABSROLL\client.ini`) dan **database**, harus sama (bisa juga diedit di halaman *Target client*, otomatis ditulis ke general.ini dan client.ini).
- Ada 2 jenis client: **ABS+ROLL** dan **ABS** saja.
- Setiap pengiriman juga menulis `version.txt` di PC client, berisi hanya tipe milik client itu dan hanya versi yang **benar-benar terpasang** (jika mdb gagal terkirim, versinya tetap yang lama dan statusnya "gagal").
- Jika mdb sedang dipakai di client, pengiriman gagal dan dicatat; gunakan **Kirim ulang**.

Isi bagian ABSROLL di `general.ini` (di `client.ini` namanya tanpa awalan `absroll.`):
```ini
[absroll.pengaturan]
max_backup = 4
keep_processed = 10

[absroll.client1]
nama = Client ABS + Roller
jenis = ABS+ROLL
abs_path = data/client_demo/client1/ABS
roll_path = data/client_demo/client1/Roll
version_path = data/client_demo/client1

[absroll.client2]
nama = Client ABS saja
jenis = ABS
abs_path = data/client_demo/client2/ABS
roll_path =
version_path = data/client_demo/client2
```
Path contoh mengarah ke `ABSROLL\data\client_demo\...`. **Ganti dengan folder client yang asli.**

### Rollback
Pilih Tipe.Kode dan versi tujuan dari `data\backup`. Versi yang berjalan saat itu otomatis masuk ke backup, sehingga rollback dapat dibatalkan.

### Halaman web (`/absroll/`)
Ringkasan (upload, versi berjalan, status tiap client, riwayat) · Rollback · Target client.

### Batch
| File | Fungsi |
|---|---|
| `ABSROLL\sync.bat` | Langsung sinkron |
| `ABSROLL\absroll.bat` | Menu: sinkron, rollback, kirim ulang, status, verifikasi |

Database: `CurrentVersion`, `ClientTarget`, `Deployment`, `ActionLog`.

---

## 5. Modul Vehicle Identification (`VEHICLEID`)

Membaca file csv export kendaraan, menyimpannya ke database, dan menyediakan pencarian.

### Konfigurasi (`general.ini` → `VEHICLEID\vehicle.ini`)
```ini
[vehicleid.sumber]
folder = D:\data export
pola = *allOrders*.csv

[vehicleid.kamus]
folder = D:\messages
pola = *sellists*en-EN*.xml
```
Jika ada beberapa file yang cocok, yang dipakai adalah **yang terbaru** (angka waktu di nama file, mis. `allOrders_2026111020.csv`, atau waktu modifikasi).

### Sinkron csv
- Format: pemisah `;`, tanggal `dd.mm.yyyy HH:MM:SS` (`01.01.0001` = kosong), dibaca sebagai waktu lokal Jakarta.
- Kunci data: **`LongVin`**. VIN baru → ditambah, berubah → diperbarui, tidak ada lagi di file → dihapus.
- **Hanya PlantId 18.72.** Baris PlantId lain dilewati dan dihitung sebagai "diabaikan".
- Folder dicek setiap: `run.bat` dijalankan, halaman dibuka, batch dijalankan. File yang sama dengan sinkron terakhir tidak dibaca ulang.
- File yang baris terakhirnya terpotong (belum selesai ditulis) ditolak; data lama utuh.

### Pencarian (web)
- Satu kotak pencarian, langsung memfilter; beberapa kata = "dan". Cocok ke VIN (penuh/sebagian), model, type, lot, warna, dll.
- Filter **saling berhubungan** (pilihan hanya yang tersisa, dengan jumlah): Model, TypeKey, IntegrationLevel, VehicleState, PackMonth, Inactive.
- Kolom tabel: VIN, Model, TypeKey, IntegrationLevel, VState, Pack, Warna, Fabric, Lot, UpdatedAt (bisa diurutkan).
- Klik baris → detail semua kolom.

### Arti kode (sellists xml)
- File `sellists_en-EN.xml` di folder `[kamus]` dibaca dan disinkronkan ke database dengan aturan yang sama (tambah/ubah/hapus, pengaman, dll). Hanya dibaca.
- Di **detail kendaraan** (hanya di aplikasi, bukan batch), tiga kode bisa ditekan untuk melihat artinya:

| Kode | Daftar di XML | Catatan pencocokan |
|---|---|---|
| ColourCode | `ColourCode` | Di data 4 karakter (`0300`), di XML 3 karakter (`300`); angka 0 di depan dibuang otomatis |
| FabricCode | `UpholsteryCode` | Sama persis |
| BasicTypeNo | `BasicTypeNo` | Diambil dari **VIN karakter ke-4 sampai ke-7** (`MHH`**`56FV`**`08TKA14560`) |

- Tombol **hijau** = kode sudah ada di XML; **merah** = belum ada. Jika merah dan ditekan, muncul baris XML yang perlu ditambahkan (`<SelListItem value="..." translatevalue="... | arti" />`).
- Kartu **"Kode yang belum ada di sellists"** di halaman utama, dan `vehicleid status` di batch, menampilkan semua kode yang dipakai kendaraan tetapi belum ada di XML. Penambahan kode dilakukan di file XML sendiri; aplikasi otomatis membacanya saat file berubah.

### Batch
| File | Fungsi |
|---|---|
| `VEHICLEID\sync.bat` | Cek dan sinkron file terbaru |
| `VEHICLEID\vehicleid.bat` | Menu: cari, sinkron, status (sinkron otomatis saat dibuka) |

```
manage.bat vehicleid sync [--force] [--allow-mass-delete] [--quiet]
manage.bat vehicleid cari g20 0425 [--limit 50]
manage.bat vehicleid status
```

Database: `Vehicle`, `CodeMeaning`, `SyncState` (`main` = csv, `kamus` = sellists), `SyncLog`.

---

## 6. Modul DOM/BTRV (`DOMBTRV`)

Scan semua file **xml `<AddOnPart>`** di sebuah folder, simpan ke database, lalu cari dan filter.

### Konfigurasi (`general.ini` → `DOMBTRV\dombtrv.ini`)
```ini
[dombtrv.sumber]
folder = D:\Data\Delete
pola = *.xml
subfolder = false

[dombtrv.jadwal]
interval_jam = 2

[dombtrv.pengaturan]
ini_versi = 2
hapus_hilang = false

[dombtrv.model]
folder_server = D:\models
nama_file = model.xml
max_backup = 4
```
| Kunci | Arti |
|---|---|
| `subfolder` | `true` = ikut scan subfolder, `false` = hanya folder itu |
| `interval_jam` | Jadwal scan; dipakai untuk penanda "data sudah lama" dan Task Scheduler |
| `hapus_hilang` | `true` = data file yang sudah hilang dari folder ikut dihapus; `false` = dipertahankan |
| `folder_server` / `nama_file` / `max_backup` | Fitur *Update model XML* (bagian 6b): folder induk di server, nama file model (sama di semua folder), jumlah backup per model |

Nilai `ya/tidak` pada ini versi lama otomatis diubah menjadi `false` **satu kali** (penanda `ini_versi`). Setelah itu Anda bebas mengisi `true`/`false`.

### Isi yang dibaca
- Atribut `<AddOnPart>`: `name` (part), `addOnPartClass`, `timestamp`, `hostname`, `vehicleNo`, `vinLong`.
- `<Descriptor>`: semua disimpan; `PartNo` dan `SerialNo` menjadi kolom tersendiri.
- Model diambil dari nama file `VIN_MODEL_NAMA.xml` (awalan angka seperti `1794670445682_` diabaikan).
- **Jika PartNo dan SerialNo tidak ada, tetapi ada descriptor lain**, nilai descriptor itu dipakai untuk **keduanya**.
- **XML VehicleType:** model diambil dari **nilai descriptor**, bukan dari nama file. Berlaku jika ada descriptor bertipe yang diawali `VehicleType` (mis. `VehicleType`, `VehicleTypeNo`), atau jika nama part diawali `VehicleType` (dipakai descriptor pertama). Jika sebuah descriptor tidak punya `value` tetapi punya `scannedValue`, `scannedValue` dipakai.
- **XML rusak / tidak valid** (rusak, bukan `<AddOnPart>`, berisi DOCTYPE/ENTITY, > 5 MB) **tidak ditampilkan di tabel pencarian**. Jumlahnya tampil di panel scan dan daftarnya (beserta alasan) ada di bagian "Sumber data" yang dilipat.

### Scan
- **Bertahap:** hanya file baru/berubah (ukuran atau waktu modifikasi) yang dibaca ulang. Jika aturan baca berubah (`PARSER_VERSION` di `core.py`, sekarang 3), scan berikutnya membaca ulang semua satu kali.
- **Baca ulang semua file:** tombol *Baca ulang semua file* di aplikasi, atau `manage.bat dombtrv scan --force`. Dipakai bila data di tabel terlihat basi (data diperbarui, tidak digandakan).
- **Tombol "Scan ulang sekarang"** di aplikasi berjalan di latar belakang dengan progres; klik kedua saat berjalan ditolak.
- **Terjadwal:** `DOMBTRV\scan_terjadwal.bat` untuk Windows Task Scheduler, contoh (sekali, di Command Prompt):
  ```
  schtasks /create /tn "ZenoLite DOMBTRV scan" /sc hourly /mo 2 /tr "C:\zeno_lite\DOMBTRV\scan_terjadwal.bat"
  ```
  Hasil dicatat di `DOMBTRV\scan_terjadwal.log`.
- **Batch interaktif tidak men-scan:** hanya membaca database hasil scan terakhir dan selalu menampilkan **waktu scan terakhir** (diberi peringatan jika sudah lewat jadwal).
- File yang baru ditulis < 2 detik dilewati dulu (dibaca di scan berikutnya).
- Pengaman: folder tidak terjangkau / subfolder tidak terbaca → tidak ada data dihapus; penghapusan massal ditahan (jika `hapus_hilang = true`).

### Pencarian (web dan batch)
- Kotak pencarian: VIN, PartNo, SerialNo, hostname, nama part, nama file, nilai descriptor.
- Filter saling berhubungan: Part, Hostname, Model, Kelas, plus rentang tanggal (timestamp di dalam file).
- Klik baris → detail atribut dan semua descriptor.

### Batch
| File | Fungsi |
|---|---|
| `DOMBTRV\dombtrv.bat` | Menu: cari, cari dengan filter, lihat pilihan filter, status |
| `DOMBTRV\scan_terjadwal.bat` | Hanya untuk Task Scheduler |

```
manage.bat dombtrv cari hud --hostname LINE2 --dari 2026-06-01 --sampai 2026-06-30
manage.bat dombtrv pilihan hud
manage.bat dombtrv status
manage.bat dombtrv scan [--quiet] [--force] [--allow-mass-delete]
```

Database: `AddOnPart`, `ScanState`, `ScanLog`.

---

### 6b. Update model XML ke server (DOM/BTRV)

Memperbarui file model (Part List) di server dari aplikasi, dengan perbandingan per baris, backup, dan rollback. Halaman: **DOM/BTRV → Update model XML** (`/dombtrv/model/`).

**Struktur server** (contoh `D:\models`, nanti UNC):
```
D:\models
├── Archive
├── F74\ (di dalamnya Archive)     G02\  G05\  G07\  G20\  G28\  G45\  G60\  G70\  U11\  U25\
```
Nama file di setiap folder sama (`nama_file`, default `model.xml`).

**Model dan versi dibaca dari baris pertama file** (komentar di baris `<?xml ...?>`):

| Baris pertama | Model | Versi | Folder tujuan |
|---|---|---|---|
| `<!-- F74 Part List v007.4 -->` | F74 | v007.4 | `F74` |
| `<!-- Part List G45 v011.3 -->` | G45 | v011.3 | `G45` |
| `<!-- G2X Part List v008.5 -->` | G2X | v008.5 | semua folder server yang cocok `G2` + angka 0–9 (mis. `G20`, `G28`) |

`X` = tepat satu angka 0–9. Hanya folder yang **sudah ada** di server yang dituju. Versi dibandingkan angka demi angka (`v007.10` > `v007.9`).

**Cara pakai:** taruh file di `DOMBTRV\modeldata\new` (boleh di subfolder, nama file boleh sama) **atau** unggah di halaman *Update model XML* → *Cek server & lihat rencana* → pilih → konfirmasi.

**Aturan keputusan** (sumber: upload, salinan aplikasi, dan file di tiap folder server):

| Keadaan | Hasil (rekomendasi) |
|---|---|
| Versi **server lebih tinggi** | Server menang: server → aplikasi ("server selalu benar") |
| Versi **server lebih rendah** (atau file belum ada di server) | Aplikasi/upload menang: dorong ke server |
| **Upload lebih tinggi** dari aplikasi dan server | Upload → aplikasi → server |
| **Versi sama, isi beda** | **KONFLIK**: tidak ada rekomendasi, Anda memilih sumber |
| Isi sama (beda CRLF/spasi di ujung baris saja) | Dianggap sama, tidak ada tindakan |
| Upload **lebih lama** dari yang ada | Tidak direkomendasikan; tetap bisa dipilih (menyimpang dari aturan, minta konfirmasi) dan upload menunggu keputusan |

- Untuk **G2X**: kebenaran = versi tertinggi di antara semua folder yang dituju; folder lain disamakan ke sana.
- Pilihan yang menyimpang dari rekomendasi butuh konfirmasi tambahan (dialog di web; ketik `YA` di batch).
- Folder model yang belum ada di server **tidak dibuat otomatis**: harus dicentang/dikonfirmasi. Untuk G2X tanpa folder yang cocok, hanya dicatat sebagai peringatan.
- Folder server berisi file dengan header model lain (mis. header G20 di folder yang dituju G2X) tidak diubah dan diberi catatan.

**Perbedaan yang ditampilkan:** untuk tiap sumber ada ringkasan seperti "14 baris beda (+6 / -3 / ubah 5) di baris 1, 220-226, 910" atau "hanya baris 1 (komentar versi) yang beda", dan tombol *Lihat perbedaan* (tampilan kiri/kanan per baris, baris beda diwarnai). Di batch: `modeldiff`.

**Yang terjadi saat diterapkan:**
1. Salinan aplikasi lama → `modeldata\backup\<MODEL>\` (nama `YYYYMMDD-HHMMSS__vVERSI__model.xml`, maks `max_backup` per model); sumber terpilih → `modeldata\existing\<MODEL>\`.
2. Setiap folder server yang isinya beda: file lama **dipindah** ke `<folder>\Archive\model_vVERSI_YYYYMMDD-HHMMSS.xml` (tidak ditimpa, tidak dihapus), lalu file baru disalin (waktu modifikasi file dipertahankan; ditulis ke file sementara lalu diganti).
3. Jika penyalinan ke server gagal, file lama dikembalikan; kegagalan satu folder tidak menghentikan folder lain dan dilaporkan. Server tidak disentuh bila langkah aplikasi gagal.
4. Upload yang sudah terpakai dipindah ke `modeldata\processed`.
5. Versi tercatat di database (`ModelCopy`, `ModelServer`, `ModelLog`) dan `modeldata\versions.txt`.

**Rollback:** pilih model dan versi dari backup (web: *Rollback*, batch: `model.bat` menu 2). Versi pilihan **didorong ke server** (rollback sengaja menyimpang dari aturan versi); versi yang sekarang berjalan masuk backup sehingga bisa dibatalkan. Server tidak terjangkau → tidak ada yang diubah. Token pada rencana memastikan tidak ada file yang berubah antara rencana ditampilkan dan dijalankan.

**Batch:** `DOMBTRV\model.bat` (menu: cek & update, rollback, bandingkan dua file, status).
```
manage.bat dombtrv model [--yes]                     # --yes = terapkan rekomendasi tanpa bertanya (konflik tetap dilewati)
manage.bat dombtrv modelstatus
manage.bat dombtrv modelrollback
manage.bat dombtrv modeldiff G05 server:G05 upload [--semua]    # sumber: app | upload | server:<folder> | backup:<no>
```

### 6c. Emergency Barcode (DOM/BTRV)

Membuat **satu nilai DMC dummy** beserta barcode **Data Matrix**-nya dari 11 karakter dan panjang yang Anda pilih, dan mencatat **riwayat** setiap pembuatan. Aturan mengikuti file *BTRV Dummy DMC 2026* (sheet "How to create DMC value" dan "DMC value generator"). Halaman: **DOM/BTRV → Emergency Barcode** (`/dombtrv/emergency/`).

**Cara pakai (web):**
1. Ketik **11 karakter** KAPITAL = **Identifier (2) + Partnumber (7) + Change index (2)**, mis. `22ABC1234XY` (huruf kecil otomatis jadi kapital; hanya A–Z dan 0–9).
2. **Pilih panjang** nilai DMC (kartu pilihan 18 (7) … 63 (9); pilihan terakhir diingat browser).
3. Waktu: bawaan **sekarang**, atau *Atur tanggal & jam sendiri* (seperti kolom MANUAL di Excel).
4. Tekan **Buat barcode** (atau Enter). Yang tampil hanya **satu** barcode dan nilainya, dengan tombol *Salin nilai*, *PNG*, *SVG*, *Cetak*.

Barcode **tidak dibuat otomatis saat mengetik**; hanya saat tombol/Enter ditekan, supaya riwayat hanya berisi barcode yang benar-benar dibuat.

**Riwayat pembuatan:** setiap pembuatan (web **dan** batch) tercatat: *dibuat kapan, oleh siapa (NPK / nama pengguna Windows untuk batch), kode, panjang, nilai DMC, waktu yang tertanam di nilai, jenis part*. Ditampilkan di halaman yang sama (terbaru di atas, bisa dicari berdasarkan kode / nilai / NPK / jenis part, ada halaman). Tombol *Tampilkan* pada baris riwayat menampilkan lagi barcode-nya **tanpa** mencatat riwayat baru. Tabel: `EmergencyLog`.

**Panjang yang tersedia** (legenda: YY tahun 2 digit, Y tahun 1 digit, DDD hari ke-n dalam tahun, HH jam 24 jam, MM menit, SS detik, S digit pertama detik, `!` tanda dummy):

| Panjang (serial) | Isi |
|---|---|
| 18 (7) | `ID PARTNUM CI` + `Y ! HH MM S` |
| 18 (9) | `ID` + `0000000` + `Y !! HH MM SS` |
| 20 (9) | `ID PARTNUM CI` + `Y !! HH MM SS` |
| 23 (12) | `ID PARTNUM CI` + `YY ! DDD HH MM SS` |
| 31 (12) | 23 (12) + 8 nol |
| 57 (9) | 18 (9) + 39 nol |
| 59 (9) | 20 (9) + 39 nol |
| 60 (12) | 23 (12) + 37 nol |
| 63 (9) | 20 (9) + 43 nol |

**Wajib (ditampilkan di web dan batch):** alasan pemakaian nilai dummy harus ditulis di kolom komentar (`MISSING DMC / NOT READABLE DMC / DUPLICATED DMC`); untuk mengisi komentar, nilai DMC harus dimasukkan **dua kali**. Pola lain (mis. 38 karakter untuk setir G0X) → hubungi tim TV-412 BTRV.

**Barcode:** Data Matrix ECC 200 persegi, pengkodean ASCII (pasangan angka dipadatkan), ukuran dipilih otomatis (terkecil yang muat). Dibuat oleh `DOMBTRV\datamatrix.py` (murni Python, **tanpa dependensi baru**).

**Identifier:** nama jenis part (mis. `22` → `ELECTRIC_POWER_STEERING`) dibaca dari `DOMBTRV\emergency\identifiers.csv` (dari sheet *Aux*; `Identifier;Attribute name`, boleh ditambah/diedit). Identifier yang belum ada di tabel tetap dibuatkan nilainya, dengan peringatan.

**Batch:** `DOMBTRV\emergency.bat` (menu: *Buat barcode*, *Riwayat*). Saat membuat: menanyakan kode, tanggal/jam opsional, lalu **panjang (nomor 1–9)**; menampilkan **satu nilai hasil generator**, mencatatnya di riwayat, menyimpan file barcode, dan menawarkan membukanya di browser.
```
manage.bat dombtrv emergency 22ABC1234XY --pola "23 (12)"            # --pola: label, nomor 1-9, atau awalan unik (mis. 23); tanpa --pola = ditanya
manage.bat dombtrv emergency 22ABC1234XY --pola 4 --tanggal 2026-11-15 --jam 08:30:00
manage.bat dombtrv emergency 22ABC1234XY --pola 4 --teks              # gambar barcode sebagai teks di layar
manage.bat dombtrv emergencyriwayat [kata] [--limit 30]               # riwayat pembuatan (kapan, siapa, nilai)
```
`--pola 18` ditolak karena ambigu (18 (7) atau 18 (9)). File barcode (html, siap cetak) disimpan di `DOMBTRV\emergency\hasil\` (`terakhir.html` = terbaru; 30 terakhir disimpan).

**Verifikasi yang sudah dilakukan:** nilai DMC dibandingkan dengan hasil hitung ulang Excel (LibreOffice) untuk 5 kasus × 9 pola = 45 nilai, **semuanya sama** (termasuk hari ke-366, 1 Januari 00:00:00, menit/detik satu digit). Encoder Data Matrix dicocokkan dengan contoh baku ISO/IEC 16022 (`123456`), dengan implementasi lain (ReportLab) untuk Reed-Solomon dan penempatan modul di semua ukuran simbol, dan setiap SVG/PNG dicek sama dengan matriksnya. **Uji scan dengan scanner/handheld yang dipakai di lini produksi tetap perlu dilakukan sebelum dipakai sungguhan.**

---

## 7. Database

SQLite `db.sqlite3` di folder utama (timeout 30 detik karena scan latar belakang menulis sambil halaman membaca).
Tabel dibuat otomatis oleh `run.bat` atau `_prep.bat` setiap modul (`makemigrations` + `migrate`).

| Modul | Tabel |
|---|---|
| accounts | `User` (NPK, nama) |
| ABSROLL | `CurrentVersion`, `ClientTarget`, `Deployment`, `ActionLog` |
| VEHICLEID | `Vehicle`, `CodeMeaning`, `SyncState`, `SyncLog` |
| DOMBTRV | `AddOnPart`, `ScanState`, `ScanLog`, `ModelCopy`, `ModelServer`, `ModelLog`, `EmergencyLog` |

Backup database = salin `db.sqlite3` (saat aplikasi tidak berjalan).

---

## 8. Pemecahan masalah

| Gejala | Penyebab / solusi |
|---|---|
| `No module named 'django'` | Pakai `manage.bat`, atau `venv\Scripts\activate` dulu |
| `no such table ...` | Jalankan `run.bat` sekali setelah update (membuat tabel baru) |
| Batch: "Aplikasi belum pernah disiapkan" | Jalankan `run.bat` di folder utama sekali |
| "...sedang berjalan (web/batch)" | Proses lain memakai kunci. Tunggu; jika yakin tidak ada, hapus file `.lock` di folder modul |
| Vehicle ID/DOM: "Folder sumber tidak ditemukan" | Cek path di `.ini` dan akses drive/UNC; data lama tetap aman |
| Status "ditahan" | File sumber akan menghapus > 50% data. Periksa file; jika benar, tekan *Setujui* atau pakai `--allow-mass-delete` |
| mdb gagal terkirim ke client | Biasanya file sedang dipakai/path tidak terjangkau; perbaiki lalu *Kirim ulang* |
| Update model XML: "Folder server tidak ditemukan" | Cek `folder_server` di `dombtrv.ini` dan akses drive/UNC; tidak ada yang diubah |
| Upload model: "header versi tidak dikenali" | Baris pertama harus berisi komentar `... Part List ... vNNN.N ...` (3 pola di bagian 6b) |
| Port 8182 sudah dipakai | Ubah `PORT` di `run.bat` |
| Perubahan di `general.ini` tidak berlaku | Jalankan `run.bat`/`menu.bat` (atau menu `[S]`) lalu mulai ulang aplikasi; cek bagian bernama `<modul>.<bagian>` |
| Pengaturan di `.ini` modul kembali ke nilai lama | Itu salinan; ubah di `general.ini`. Versi sebelumnya ada di `<nama>.ini.bak` |

---

## 9. Riwayat keputusan dan perubahan

1. **Dasar:** login NPK + dashboard, Django + SQLite; `run.bat` menjalankan server dan membuka Edge/Chrome; port diganti ke **8182**; `manage.bat` ditambahkan.
2. **ABSROLL:** sinkron zip, perbandingan versi, backup maks 4, rollback, tracking di database dan `version.txt`, target client di `client.ini` + database.
3. **Perbaikan ABSROLL:** modtime mdb tidak diubah saat dikirim.
4. **Vehicle Identification:** sinkron csv, hanya PlantId 18.72, pencarian.
5. **Perubahan tampilan:** kolom State diganti **IntegrationLevel**, kolom Inactive dibuang dari tabel, filter dibuat saling berhubungan.
6. **Arti kode:** sellists xml; detail menampilkan arti ColourCode, FabricCode, BasicTypeNo (VIN 4–7); daftar kode yang belum terdaftar.
7. **DOM/BTRV:** scan xml AddOnPart, scan latar belakang + scheduler, batch hanya baca.
8. **Perbaikan DOM/BTRV:** PartNo/SerialNo mengikuti descriptor bila kosong; model XML VehicleType dari descriptor; XML rusak tidak tampil di tabel; `.ini` memakai true/false; `subfolder` dan `hapus_hilang` default **false**.
9. **README.md** ditambahkan (dokumen ini). Perbarui bagian ini setiap ada perubahan.
10. **Perbaikan VehicleType:** descriptor `VehicleTypeNo` dikenali, `scannedValue` dipakai bila `value` kosong, tombol/opsi *baca ulang semua file* ditambahkan, `PARSER_VERSION` menjadi 3.

11. **Update model XML ke server:** upload/folder, model + versi dari baris pertama (3 pola, G2X = G20–G29), aturan versi tertinggi menang (server selalu benar bila lebih tinggi), konflik manual, compare per baris, Archive di server, backup + rollback.
12. **Emergency Barcode:** nilai DMC dummy dari 11 karakter (9 panjang, aturan dari file Excel BTRV Dummy DMC) + barcode Data Matrix (encoder murni Python) di web dan batch; identifier dari `identifiers.csv`.
13. **Perbaikan Emergency Barcode:** panjang dipilih dulu sehingga hanya **satu** barcode/nilai yang tampil (web dan batch); pembuatan eksplisit (tombol/Enter); **riwayat** pembuatan (kapan, siapa, kode, panjang, nilai) di web dan batch (`emergencyriwayat`).

14. **Menu utama + pengaturan pusat:** `menu.bat` (semua batch dipilih dari satu menu di folder utama) dan `general.ini` (master konfigurasi semua modul, disalin ke `.ini` modul oleh `general_sync.py` saat `run.bat`/menu/batch dijalankan; target client dari web ditulis balik).

15. **Tampilan baru:** sidebar yang bisa dibuka/tutup (laci di HP, ikon ringkas di komputer), mode terang saja, login (kartu sederhana di tengah) dan beranda baru, tabel menjadi kartu di layar sempit, satu stylesheet bersama (`static\zeno\app.css`). Pengaturan `[aplikasi]` di `general.ini` (port, `akses_jaringan`) untuk membuka aplikasi dari HP. Menu modul dan ikon ada di `templates\_nav.html` dan `templates\_icons.html`.

### Hal yang belum dilakukan / bisa ditambah nanti
- Form "tambah kode" yang menulis langsung ke sellists xml (saat ini penambahan dilakukan manual di XML).
- Scan terjadwal di dalam aplikasi (saat ini lewat Windows Task Scheduler).
- Pembatasan hak akses per user (saat ini semua user yang login dapat memakai semua modul).
