from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models


class UserManager(BaseUserManager):
    use_in_migrations = True

    def create_user(self, npk, password=None, **extra):
        if not npk:
            raise ValueError("NPK wajib diisi")
        user = self.model(npk=str(npk).strip(), **extra)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, npk, password=None, **extra):
        extra.setdefault("is_staff", True)
        extra.setdefault("is_superuser", True)
        return self.create_user(npk, password, **extra)


class User(AbstractBaseUser, PermissionsMixin):
    npk = models.CharField("NPK", max_length=20, unique=True)
    nama = models.CharField("Nama", max_length=100, blank=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(auto_now_add=True)

    objects = UserManager()

    USERNAME_FIELD = "npk"
    REQUIRED_FIELDS = ["nama"]

    def __str__(self):
        return f"{self.npk} - {self.nama}" if self.nama else self.npk
