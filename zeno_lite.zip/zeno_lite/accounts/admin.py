from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User


@admin.register(User)
class ZenoUserAdmin(UserAdmin):
    list_display = ("npk", "nama", "is_staff", "is_active")
    search_fields = ("npk", "nama")
    ordering = ("npk",)
    fieldsets = (
        (None, {"fields": ("npk", "password")}),
        ("Profil", {"fields": ("nama",)}),
        ("Hak akses", {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")}),
    )
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("npk", "nama", "password1", "password2")}),
    )
