from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.shortcuts import render

from .forms import NPKLoginForm


class ZenoLoginView(LoginView):
    template_name = "accounts/login.html"
    authentication_form = NPKLoginForm
    redirect_authenticated_user = True


def _ringkasan():
    """Angka ringkas tiap modul untuk beranda. Gagal membaca satu modul tidak menggagalkan halaman."""
    out = {"absroll": None, "vehicleid": None, "dombtrv": None}
    try:
        from ABSROLL.models import ClientTarget, CurrentVersion
        out["absroll"] = {"files": CurrentVersion.objects.count(), "clients": ClientTarget.objects.count()}
    except Exception:
        pass
    try:
        from VEHICLEID.models import SyncState, Vehicle
        st = SyncState.objects.filter(key="main").first()
        out["vehicleid"] = {"total": Vehicle.objects.count(), "synced": st.last_synced if st else None}
    except Exception:
        pass
    try:
        from DOMBTRV.models import AddOnPart, ScanState
        st = ScanState.objects.filter(key="scan").first()
        out["dombtrv"] = {"total": AddOnPart.objects.filter(ok=True).count(), "scan": st.finished_at if st else None}
    except Exception:
        pass
    return out


@login_required
def dashboard(request):
    return render(request, "accounts/dashboard.html", {"ringkas": _ringkasan()})
