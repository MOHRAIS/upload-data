from django.core.management.base import BaseCommand

from accounts.models import User

DEFAULT_NPK = "00001"
DEFAULT_PASSWORD = "admin123"


class Command(BaseCommand):
    help = "Membuat akun admin awal jika belum ada user sama sekali."

    def handle(self, *args, **options):
        if User.objects.exists():
            return
        User.objects.create_superuser(DEFAULT_NPK, DEFAULT_PASSWORD, nama="Administrator")
        self.stdout.write(self.style.WARNING(
            f"Akun awal dibuat -> NPK: {DEFAULT_NPK} | Password: {DEFAULT_PASSWORD} (segera ganti!)"
        ))
