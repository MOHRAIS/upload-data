from django import forms
from django.contrib.auth.forms import AuthenticationForm


class NPKLoginForm(AuthenticationForm):
    username = forms.CharField(
        label="NPK",
        widget=forms.TextInput(attrs={"autofocus": True, "placeholder": "Masukkan NPK", "autocomplete": "username", "autocapitalize": "off", "spellcheck": "false"}),
    )
    password = forms.CharField(
        label="Password",
        strip=False,
        widget=forms.PasswordInput(attrs={"placeholder": "Masukkan password", "autocomplete": "current-password"}),
    )
    error_messages = {
        "invalid_login": "NPK atau password salah.",
        "inactive": "Akun ini tidak aktif.",
    }
