@echo off
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
    echo venv belum ada. Jalankan run.bat dulu.
    pause
    exit /b 1
)
venv\Scripts\python.exe manage.py %*
