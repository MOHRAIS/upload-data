@echo off
setlocal
cd /d "%~dp0"
title Zeno Lite - Menu

rem Pilih python: venv kalau sudah ada, kalau belum pakai python sistem
set "PY="
if exist venv\Scripts\python.exe (set "PY=venv\Scripts\python.exe") else (where python >nul 2>nul && set "PY=python")

:menu
cls
rem general.ini = master konfigurasi: disalin ke ini tiap modul setiap menu ditampilkan
if defined PY %PY% general_sync.py --quiet
echo ==========================================
echo           ZENO LITE  -  MENU UTAMA
echo ==========================================
echo   APLIKASI
echo     [1] Jalankan aplikasi (web)         run.bat
echo.
echo   ABSROLL
echo     [2] Menu ABSROLL                    absroll.bat
echo     [3] Sinkron file baru               sync.bat
echo.
echo   VEHICLE IDENTIFICATION
echo     [4] Menu Vehicle Identification     vehicleid.bat
echo     [5] Cek ^& sinkron file terbaru      sync.bat
echo.
echo   DOM/BTRV
echo     [6] Menu DOM/BTRV                   dombtrv.bat
echo     [7] Update model XML ke server      model.bat
echo     [8] Emergency Barcode               emergency.bat
echo     [9] Scan sekarang                   scan_terjadwal.bat
echo.
echo   PENGATURAN
echo     [G] Buka general.ini (edit pengaturan semua modul)
echo     [S] Terapkan general.ini ke semua modul sekarang
echo.
echo     [0] Keluar
echo.
choice /c 123456789GS0 /n /m "Pilih: "
goto :opt%errorlevel%

:opt1
call "%~dp0run.bat"
goto :back
:opt2
call "%~dp0ABSROLL\absroll.bat"
goto :back
:opt3
call "%~dp0ABSROLL\sync.bat"
goto :back
:opt4
call "%~dp0VEHICLEID\vehicleid.bat"
goto :back
:opt5
call "%~dp0VEHICLEID\sync.bat"
goto :back
:opt6
call "%~dp0DOMBTRV\dombtrv.bat"
goto :back
:opt7
call "%~dp0DOMBTRV\model.bat"
goto :back
:opt8
call "%~dp0DOMBTRV\emergency.bat"
goto :back
:opt9
call "%~dp0DOMBTRV\scan_terjadwal.bat"
echo.
echo Selesai. Hasil scan ada di DOMBTRV\scan_terjadwal.log
pause
goto :back
:opt10
start "" notepad "%~dp0general.ini"
echo.
echo general.ini dibuka di Notepad. Simpan, lalu pilih [S] (atau jalankan batch apa pun) agar berlaku.
pause
goto :back
:opt11
echo.
if not defined PY (echo [ERROR] Python belum ada. Jalankan run.bat dulu.) else (%PY% general_sync.py)
echo.
pause
goto :back
:opt12
goto :eof

:back
cd /d "%~dp0"
title Zeno Lite - Menu
goto :menu
