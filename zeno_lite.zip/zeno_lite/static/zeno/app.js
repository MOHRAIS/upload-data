/* Zeno Lite - perilaku antarmuka: sidebar, tema, menu pengguna, tabel. Tanpa library. */
(function () {
  "use strict";
  var root = document.documentElement;
  var store = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };
  var mqDesktop = window.matchMedia("(min-width: 1024px)");

  /* ---- sidebar: desktop = lebar/ringkas, mobile = laci ---- */
  function toggleSidebar() {
    if (mqDesktop.matches) {
      var next = root.getAttribute("data-sb") === "rail" ? "full" : "rail";
      root.setAttribute("data-sb", next);
      store.set("zeno.sb", next);
    } else {
      setDrawer(!root.classList.contains("sb-open"));
    }
  }
  function setDrawer(open) {
    root.classList.toggle("sb-open", open);
    var b = document.getElementById("sbToggle");
    if (b) b.setAttribute("aria-expanded", open ? "true" : "false");
  }
  var tg = document.getElementById("sbToggle");
  if (tg) tg.addEventListener("click", toggleSidebar);
  var bd = document.getElementById("backdrop");
  if (bd) bd.addEventListener("click", function () { setDrawer(false); });
  var sbClose = document.getElementById("sbClose");
  if (sbClose) sbClose.addEventListener("click", function () { setDrawer(false); });
  mqDesktop.addEventListener("change", function () { setDrawer(false); });

  /* ---- grup menu yang bisa dibuka/tutup ---- */
  document.querySelectorAll(".nav-group").forEach(function (g) {
    var id = g.getAttribute("data-group");
    var btn = g.querySelector(".nav-parent");
    var saved = store.get("zeno.grp." + id);
    if (saved === "1") g.classList.add("open");
    else if (saved === "0" && !g.querySelector(".nav-sub .on")) g.classList.remove("open");
    if (btn) {
      btn.setAttribute("aria-expanded", g.classList.contains("open") ? "true" : "false");
      btn.addEventListener("click", function () {
        var open = !g.classList.contains("open");
        g.classList.toggle("open", open);
        btn.setAttribute("aria-expanded", open ? "true" : "false");
        store.set("zeno.grp." + id, open ? "1" : "0");
      });
    }
  });

  /* ---- menu pengguna ---- */
  var um = document.getElementById("userMenu");
  if (um) {
    var ub = um.querySelector(".user-btn");
    ub.addEventListener("click", function (e) {
      e.stopPropagation();
      var open = !um.classList.contains("open");
      um.classList.toggle("open", open);
      ub.setAttribute("aria-expanded", open ? "true" : "false");
    });
    document.addEventListener("click", function (e) { if (!um.contains(e.target)) um.classList.remove("open"); });
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") { setDrawer(false); if (um) um.classList.remove("open"); }
  });

  /* ---- tabel: bungkus agar bisa digeser di layar sempit ---- */
  document.querySelectorAll("table").forEach(function (t) {
    if (t.closest(".scroll, .tbl-scroll")) return;
    var w = document.createElement("div");
    w.className = "tbl-scroll";
    t.parentNode.insertBefore(w, t);
    w.appendChild(t);
  });

  /* ---- login: tampilkan / sembunyikan password ---- */
  var pw = document.getElementById("pwToggle");
  if (pw) pw.addEventListener("click", function () {
    var inp = document.getElementById("id_password");
    var show = inp.type === "password";
    inp.type = show ? "text" : "password";
    pw.setAttribute("aria-label", show ? "Sembunyikan password" : "Tampilkan password");
    pw.classList.toggle("on", show);
  });

  /* ---- pesan sukses hilang sendiri ---- */
  document.querySelectorAll(".msg.success[data-auto]").forEach(function (m) {
    setTimeout(function () { m.style.display = "none"; }, 7000);
  });
})();
