@echo off
cd /d "%~dp0.."
if not exist venv\Scripts\python.exe (
    echo [ERROR] Aplikasi belum pernah disiapkan. Jalankan run.bat di folder utama sekali dulu.
    pause
    exit /b 1
)
rem general.ini = master konfigurasi: salin ke ini modul
venv\Scripts\python.exe general_sync.py --quiet
venv\Scripts\python.exe manage.py makemigrations accounts absroll vehicleid dombtrv >nul
venv\Scripts\python.exe manage.py migrate >nul
exit /b 0
