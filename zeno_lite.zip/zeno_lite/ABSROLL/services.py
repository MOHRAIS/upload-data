"""Lapisan penghubung: core (file) <-> database Django. Dipakai oleh web dan batch."""
from dataclasses import dataclass, field

from django.utils import timezone

from . import core
from .models import ActionLog, ClientTarget, CurrentVersion, Deployment


@dataclass
class Report:
    judul: str = ""
    rows: list = field(default_factory=list)      # (level, teks): ok | warn | err | info
    deploy: list = field(default_factory=list)    # dict: target, key, versi, ok, message

    def add(self, level, text):
        self.rows.append((level, text))

    @property
    def ada_gagal(self):
        return any(l == "err" for l, _ in self.rows) or any(not d["ok"] for d in self.deploy)


def log(aksi, key="", dari="", ke="", oleh="-", status="ok", pesan=""):
    ActionLog.objects.create(aksi=aksi, key=key, dari_versi=dari, ke_versi=ke,
                             oleh=oleh, status=status, pesan=pesan)


# ---------------------------------------------------------------- sinkron data
def sync_versions_to_db(existing):
    for key, e in existing.items():
        CurrentVersion.objects.update_or_create(key=key, defaults=dict(
            tipe=e.tipe, kode=e.kode, versi=e.versi, filename=e.filename,
            mdb_name=e.mdb_name, sha256=e.sha256))
    CurrentVersion.objects.exclude(key__in=list(existing)).delete()


def sync_targets_to_db(targets=None):
    targets = targets if targets is not None else core.read_targets()
    for t in targets:
        ClientTarget.objects.update_or_create(tid=t.id, defaults=dict(
            nama=t.nama, jenis=t.jenis_norm, abs_path=t.abs_path.strip(),
            roll_path=t.roll_path.strip(), version_path=t.version_path.strip()))
    ClientTarget.objects.exclude(tid__in=[t.id for t in targets]).delete()


def refresh_state():
    """Samakan version.txt, database (versi) dan database (target) dengan keadaan sebenarnya."""
    existing = core.list_existing()
    core.write_master_version(existing)
    sync_versions_to_db(existing)
    sync_targets_to_db()
    return existing


def consistency():
    """Daftar ketidaksesuaian antara folder existing, database, version.txt, dan client.ini."""
    issues = []
    folder = {k: e.versi for k, e in core.list_existing().items()}
    db = dict(CurrentVersion.objects.values_list("key", "versi"))
    txt = core.read_version_file(core.VERSION_FILE)
    for nama, other in (("database", db), ("version.txt", txt)):
        for k in sorted(set(folder) | set(other)):
            if folder.get(k) != other.get(k):
                issues.append(f"{k}: folder={folder.get(k, '-')} | {nama}={other.get(k, '-')}")
    ini = {t.id: t.as_tuple() for t in core.read_targets()}
    dbt = {t.tid: (t.nama, t.jenis, t.abs_path, t.roll_path, t.version_path)
           for t in ClientTarget.objects.all()}
    for tid in sorted(set(ini) | set(dbt)):
        if ini.get(tid) != dbt.get(tid):
            issues.append(f"Target {tid}: client.ini dan database berbeda")
    return issues


def auto_heal(oleh="-"):
    """Bila ada ketidaksesuaian, samakan otomatis (folder & client.ini = sumber kebenaran)."""
    if core.LOCK_FILE.exists():
        return []
    if not ClientTarget.objects.exists() and not CurrentVersion.objects.exists():
        refresh_state()                      # pemakaian pertama: isi database dari client.ini & folder
        log("INIT", oleh=oleh, pesan="database ABSROLL diinisialisasi")
        return []
    issues = consistency()
    if issues:
        refresh_state()
        log("SAMAKAN", oleh=oleh, pesan="; ".join(issues)[:1000])
    return issues


# ------------------------------------------------------------------- kirim
def deploy(existing, keys=None, oleh="-"):
    """Kirim mdb + version.txt ke semua target. Panggil di dalam lock."""
    out = []
    for t in core.read_targets():
        res = core.deploy_to_target(t, existing, keys)
        ok = sum(1 for r in res if r.ok)
        gagal = [r for r in res if not r.ok]
        for r in res:
            out.append(dict(target=t.nama, key=r.key, versi=r.versi, ok=r.ok, message=r.message))
            if r.key == "version.txt":
                continue
            dep, _ = Deployment.objects.get_or_create(target=t.id, key=r.key)
            dep.status = "ok" if r.ok else "gagal"
            dep.pesan = r.message
            if r.ok:
                dep.versi_terkirim = r.versi
                dep.waktu_sukses = timezone.now()
            dep.save()
        log("KIRIM", oleh=oleh, status="ok" if not gagal else "gagal",
            pesan=f"{t.nama}: {ok} berhasil, {len(gagal)} gagal"
                  + ("".join(f" | {g.key}: {g.message}" for g in gagal))[:800])
    return out


def deploy_all(oleh="-"):
    with core.lock():
        existing = refresh_state()
        rep = Report("Kirim ulang ke semua client")
        rep.deploy = deploy(existing, None, oleh)
        rep.add("info", f"{len(existing)} file dikirim ke {len(core.read_targets())} target.")
    return rep


def target_matrix():
    """Status tiap target: versi berjalan vs versi terakhir yang berhasil dikirim."""
    existing = core.list_existing()
    deps = {(d.target, d.key): d for d in Deployment.objects.all()}
    out = []
    for t in core.read_targets():
        rows = []
        for key, ef in sorted(existing.items()):
            if ef.tipe not in t.types:
                continue
            d = deps.get((t.id, key))
            if d is None:
                state, sent, when, msg = "belum", "-", None, ""
            else:
                sent, when, msg = d.versi_terkirim or "-", d.waktu_sukses, d.pesan
                if d.status != "ok":
                    state = "gagal"
                elif d.versi_terkirim == ef.versi:
                    state = "terbaru"
                else:
                    state = "tertinggal"
            rows.append(dict(key=key, versi=ef.versi, sent=sent, state=state, when=when, msg=msg))
        out.append(dict(t=t, rows=rows, errors=core.validate_target(t)))
    return out


# ------------------------------------------------------------------- sinkron
def run_plan(selected, downgrade_ok, oleh="-"):
    """
    selected     : set token ("Tipe.Kode|sha10") item yang disetujui
    downgrade_ok : set token yang disetujui walau versinya LEBIH LAMA
    Rencana dibangun ulang di dalam lock supaya selalu sesuai kondisi terkini.
    """
    rep = Report("Hasil sinkron file baru")
    with core.lock():
        plan = core.build_plan()
        try:
            for w in plan.warnings:
                rep.add("warn", w)
            changed = set()
            for it in plan.items:
                if it.action == "sama":
                    it.cand.status = "sama"
                    rep.add("info", f"{it.key} {it.versi}: sudah sama, tidak ada perubahan.")
                    continue
                if it.token not in selected:
                    it.cand.status = "ditolak"
                    rep.add("warn", f"{it.key} {it.versi}: tidak diterapkan (tidak dipilih / berkas berubah).")
                    continue
                if it.action == "downgrade" and it.token not in downgrade_ok:
                    it.cand.status = "ditolak"
                    rep.add("warn", f"{it.key} {it.versi}: versi lebih lama, butuh konfirmasi rollback - dilewati.")
                    continue
                try:
                    bk = core.apply_item(it)
                    it.cand.status = "applied"
                    changed.add(it.key)
                    log("SINKRON" if it.action != "downgrade" else "TURUN-VERSI", it.key,
                        it.existing_versi, it.versi, oleh,
                        pesan=f"{it.label}; backup: {bk or '-'}")
                    rep.add("ok", f"{it.key}: {it.existing_versi or '(baru)'} -> {it.versi}"
                                  + (f"  (versi lama disimpan ke backup)" if bk else ""))
                except Exception as e:
                    it.cand.status = "ditolak"
                    log("SINKRON", it.key, it.existing_versi, it.versi, oleh, "gagal", str(e))
                    rep.add("err", f"{it.key}: gagal diterapkan - {e}")
            existing = refresh_state()
            if changed:
                rep.deploy = deploy(existing, changed, oleh)
            for src in core.archive_sources(plan):
                rep.add("info", f"{src} dipindah ke data/processed.")
        finally:
            plan.cleanup()
    return rep


def rollback(key, backup_filename, oleh="-"):
    rep = Report(f"Rollback {key}")
    with core.lock():
        before = core.list_existing().get(key)
        bk = core.do_rollback(key, backup_filename)
        existing = refresh_state()
        dari = before.versi if before else ""
        log("ROLLBACK", key, dari, bk.versi, oleh,
            pesan=f"versi {dari or '-'} dipindah ke backup")
        rep.add("ok", f"{key}: {dari or '-'} -> {bk.versi} (versi sebelumnya masuk ke backup, bisa dikembalikan lagi).")
        rep.deploy = deploy(existing, {key}, oleh)
    return rep
