from django.apps import AppConfig


class AbsrollConfig(AppConfig):
    name = "ABSROLL"
    label = "absroll"
    verbose_name = "ABSROLL"
    default_auto_field = "django.db.models.BigAutoField"
