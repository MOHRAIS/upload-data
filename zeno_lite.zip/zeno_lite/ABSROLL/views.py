from datetime import datetime
from pathlib import Path

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from . import core, services
from .models import ActionLog


def _oleh(request):
    return getattr(request.user, "npk", "-")


def _busy(request, e):
    messages.error(request, str(e))
    return redirect("absroll:index")


@login_required
def index(request):
    core.ensure_dirs()
    core.ensure_ini()
    issues = services.auto_heal(_oleh(request))
    if issues:
        messages.warning(request, "Ditemukan data tidak sinkron (folder / database / version.txt / client.ini) "
                                  "dan sudah disamakan otomatis: " + "; ".join(issues[:5]))
    existing = core.list_existing()
    backups = {}
    for b in core.list_backups():
        backups[b.key] = backups.get(b.key, 0) + 1
    rows = [dict(e=e, backups=backups.get(k, 0), updated=datetime.fromtimestamp(e.path.stat().st_mtime))
            for k, e in sorted(existing.items())]
    pending = [dict(name=f.name, size=f.stat().st_size) for f in core.new_files()]
    return render(request, "absroll/index.html", {
        "rows": rows,
        "pending": pending,
        "matrix": services.target_matrix(),
        "logs": ActionLog.objects.all()[:25],
        "max_backup": core.read_settings()["max_backup"],
        "active": "index",
    })


@login_required
@require_POST
def upload(request):
    core.ensure_dirs()
    saved = 0
    for f in request.FILES.getlist("files"):
        name = Path(f.name).name
        if not name.lower().endswith(".zip"):
            messages.error(request, f"{name}: hanya file .zip yang diterima.")
            continue
        with open(core.NEW_DIR / name, "wb") as out:
            for chunk in f.chunks():
                out.write(chunk)
        saved += 1
    if not saved:
        messages.error(request, "Tidak ada file yang diunggah.")
        return redirect("absroll:index")
    messages.success(request, f"{saved} file disimpan di ABSROLL/data/new. Periksa rencana di bawah lalu konfirmasi.")
    return redirect("absroll:preview")


@login_required
def preview(request):
    if request.method == "POST":
        selected = set(request.POST.getlist("apply"))
        downgrade_ok = set(request.POST.getlist("downgrade_ok"))
        try:
            rep = services.run_plan(selected, downgrade_ok, _oleh(request))
        except core.BusyError as e:
            return _busy(request, e)
        return render(request, "absroll/hasil.html", {"rep": rep, "active": "index"})

    plan = core.build_plan()
    try:
        items = list(plan.items)
        warnings = list(plan.warnings)
        sources = list(plan.sources)
    finally:
        plan.cleanup()
    return render(request, "absroll/preview.html", {
        "items": items, "warnings": warnings, "sources": sources, "active": "index"})


@login_required
def rollback(request):
    if request.method == "POST":
        key = request.POST.get("key", "")
        fn = request.POST.get("backup", "")
        if not key or not fn:
            messages.error(request, "Pilih file yang akan di-rollback.")
            return redirect("absroll:rollback")
        try:
            rep = services.rollback(key, fn, _oleh(request))
        except core.BusyError as e:
            return _busy(request, e)
        except ValueError as e:
            messages.error(request, str(e))
            return redirect("absroll:rollback")
        return render(request, "absroll/hasil.html", {"rep": rep, "active": "rollback"})

    existing = core.list_existing()
    groups = []
    for key in core.backup_keys():
        ex = existing.get(key)
        groups.append(dict(key=key, current=ex.versi if ex else "-", backups=core.list_backups(key)))
    return render(request, "absroll/rollback.html", {"groups": groups, "active": "rollback"})


@login_required
@require_POST
def deploy_all(request):
    try:
        rep = services.deploy_all(_oleh(request))
    except core.BusyError as e:
        return _busy(request, e)
    return render(request, "absroll/hasil.html", {"rep": rep, "active": "index"})


@login_required
@require_POST
def samakan(request):
    try:
        with core.lock():
            issues = services.consistency()
            services.refresh_state()
            services.log("SAMAKAN", oleh=_oleh(request), pesan="manual; " + "; ".join(issues)[:900])
    except core.BusyError as e:
        return _busy(request, e)
    messages.success(request, "Data disamakan: folder, database, version.txt, dan client.ini." if issues
                     else "Semua data sudah sinkron.")
    return redirect("absroll:index")


@login_required
def targets(request):
    current = core.read_targets()
    if request.method == "POST":
        new, errors = [], []
        for t in current:
            nt = core.Target(
                id=t.id,
                nama=request.POST.get(f"{t.id}__nama", t.nama).strip() or t.id,
                jenis=request.POST.get(f"{t.id}__jenis", t.jenis).strip(),
                abs_path=request.POST.get(f"{t.id}__abs_path", "").strip(),
                roll_path=request.POST.get(f"{t.id}__roll_path", "").strip(),
                version_path=request.POST.get(f"{t.id}__version_path", "").strip(),
            )
            for e in core.validate_target(nt):
                errors.append(f"{nt.nama}: {e}")
            new.append(nt)
        if errors:
            for e in errors:
                messages.error(request, e)
            return render(request, "absroll/targets.html", {"targets": new, "active": "targets"})
        try:
            with core.lock():
                core.write_targets(new)
                services.sync_targets_to_db(new)
                services.log("TARGET", oleh=_oleh(request), pesan="client.ini & database diperbarui")
        except core.BusyError as e:
            messages.error(request, str(e))
            return render(request, "absroll/targets.html", {"targets": new, "active": "targets"})
        messages.success(request, "Target client disimpan ke client.ini dan database (sama persis).")
        return redirect("absroll:targets")
    return render(request, "absroll/targets.html", {"targets": current, "active": "targets"})
