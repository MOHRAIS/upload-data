"""
ABSROLL - logika inti (TANPA Django, supaya mudah diuji & dipakai batch maupun web).

Struktur folder modul:
    ABSROLL/
      client.ini          <- target client + pengaturan (disalin dari general.ini, lalu ke database)
      version.txt         <- versi file yang sedang berjalan (disalin ke database)
      data/new/           <- taruh ABS.zip / Roller.zip di sini
      data/existing/      <- zip versi yang sedang berjalan (1 file per Tipe.Kode)
      data/backup/        <- zip lama untuk rollback (maks N per Tipe.Kode)
      data/processed/     <- arsip file yang sudah selesai diproses
"""
import hashlib
import os
import re
import shutil
import tempfile
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

MODULE_DIR = Path(__file__).resolve().parent
DATA_DIR = MODULE_DIR / "data"
NEW_DIR = DATA_DIR / "new"
EXISTING_DIR = DATA_DIR / "existing"
BACKUP_DIR = DATA_DIR / "backup"
PROCESSED_DIR = DATA_DIR / "processed"
WORK_DIR = DATA_DIR / "_work"
LOCK_FILE = DATA_DIR / ".lock"
VERSION_FILE = MODULE_DIR / "version.txt"
CLIENT_INI = MODULE_DIR / "client.ini"


def _general(module, tarik=False):
    """Hubungan ke general.ini di folder utama (master konfigurasi).
    tarik=False: salin general.ini -> ini modul; tarik=True: tulis ini modul -> general.ini."""
    try:
        import sys
        root = str(MODULE_DIR.parent)
        if root not in sys.path:
            sys.path.insert(0, root)
        import general_sync
        if tarik:
            general_sync.pull(module)
            return True
        general_sync.ensure_general()
        return general_sync.push_module(module)
    except Exception:
        return False

DEFAULT_MAX_BACKUP = 4
DEFAULT_KEEP_PROCESSED = 10

# Contoh: Roll.W58.08.02.00.02.zip -> tipe=Roll kode=W58 versi=08.02.00.02
NAME_RE = re.compile(
    r"^(?P<tipe>[A-Za-z]+)\.(?P<kode>[A-Za-z]*\d+)\.(?P<versi>\d+(?:\.\d+)+)\.zip$",
    re.IGNORECASE,
)
BACKUP_RE = re.compile(r"^(?P<ts>\d{8}-\d{6})(?:_(?P<n>\d+))?__(?P<orig>.+)$")
TIPE_DIKENAL = {"abs": "ABS", "roll": "Roll"}


# ----------------------------------------------------------------------------
# Util
# ----------------------------------------------------------------------------
def ensure_dirs():
    for d in (NEW_DIR, EXISTING_DIR, BACKUP_DIR, PROCESSED_DIR, WORK_DIR):
        d.mkdir(parents=True, exist_ok=True)


def vtuple(versi):
    return tuple(int(x) for x in versi.split("."))


def parse_name(filename):
    """Kembalikan dict(tipe, kode, versi, key) atau None bila nama tidak sesuai format."""
    m = NAME_RE.match(filename)
    if not m:
        return None
    tipe = TIPE_DIKENAL.get(m.group("tipe").lower())
    if not tipe:
        return None
    kode = m.group("kode").upper()
    return {"tipe": tipe, "kode": kode, "versi": m.group("versi"), "key": f"{tipe}.{kode}"}


def _now_ts():
    return time.strftime("%Y%m%d-%H%M%S")


def fmt_ts(ts):
    """20261114-153000 -> 2026-11-14 15:30:00"""
    try:
        return time.strftime("%Y-%m-%d %H:%M:%S", time.strptime(ts, "%Y%m%d-%H%M%S"))
    except ValueError:
        return ts


_sha_cache = {}


def mdb_info(zip_path):
    """Kembalikan (nama_mdb, sha256_isi_mdb) dari sebuah zip. Error -> ValueError."""
    zip_path = Path(zip_path)
    st = zip_path.stat()
    ck = (str(zip_path), st.st_mtime_ns, st.st_size)
    if ck in _sha_cache:
        return _sha_cache[ck]
    try:
        with zipfile.ZipFile(zip_path) as zf:
            members = [i for i in zf.infolist() if not i.is_dir() and i.filename.lower().endswith(".mdb")]
            if not members:
                raise ValueError("tidak ada file .mdb di dalam zip")
            info = members[0]
            h = hashlib.sha256()
            with zf.open(info) as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    h.update(chunk)
            res = (Path(info.filename.replace("\\", "/")).name, h.hexdigest())
    except zipfile.BadZipFile:
        raise ValueError("zip rusak / bukan file zip")
    _sha_cache[ck] = res
    return res


def extract_mdb(zip_path, dest_dir, mdb_name):
    """
    Ekstrak mdb ke dest_dir/mdb_name secara aman (tulis ke file sementara lalu replace).
    Waktu modifikasi (modtime) file mdb DIPERTAHANKAN sama seperti yang tercatat di dalam zip.
    """
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    final = dest_dir / mdb_name
    tmp = dest_dir / f".{mdb_name}.zeno.tmp"
    try:
        with zipfile.ZipFile(zip_path) as zf:
            member = next(i for i in zf.infolist()
                          if not i.is_dir() and i.filename.lower().endswith(".mdb"))
            with zf.open(member) as src, open(tmp, "wb") as out:
                shutil.copyfileobj(src, out, 1024 * 1024)
        try:
            ts = time.mktime(tuple(member.date_time) + (0, 0, -1))
            os.utime(tmp, (ts, ts))
        except (OverflowError, OSError, ValueError):
            pass
        os.replace(tmp, final)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
    return final


class BusyError(Exception):
    pass


class lock:
    """Kunci sederhana agar web & batch tidak mengubah file bersamaan."""

    def __enter__(self):
        ensure_dirs()
        if LOCK_FILE.exists() and time.time() - LOCK_FILE.stat().st_mtime > 15 * 60:
            LOCK_FILE.unlink(missing_ok=True)  # kunci basi
        try:
            fd = os.open(LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
        except FileExistsError:
            raise BusyError("Proses ABSROLL lain sedang berjalan (web/batch). Coba lagi sebentar.")
        return self

    def __exit__(self, *exc):
        LOCK_FILE.unlink(missing_ok=True)


# ----------------------------------------------------------------------------
# client.ini  (pengaturan + target client)
# ----------------------------------------------------------------------------
@dataclass
class Target:
    id: str
    nama: str
    jenis: str            # "ABS+ROLL" atau "ABS"
    abs_path: str = ""
    roll_path: str = ""
    version_path: str = ""

    @property
    def types(self):
        out = set()
        for tok in re.split(r"[+,/ ]+", self.jenis):
            t = TIPE_DIKENAL.get(tok.strip().lower())
            if t:
                out.add(t)
        return out

    @staticmethod
    def _res(p):
        p = (p or "").strip()
        if not p:
            return None
        pp = Path(p)
        return pp if pp.is_absolute() or p.startswith("\\\\") else MODULE_DIR / pp

    @property
    def abs_dir(self):
        return self._res(self.abs_path)

    @property
    def roll_dir(self):
        return self._res(self.roll_path)

    @property
    def version_dir(self):
        return self._res(self.version_path) or self.abs_dir or self.roll_dir

    def dir_for(self, tipe):
        return self.abs_dir if tipe == "ABS" else self.roll_dir

    def as_tuple(self):
        return (self.nama, self.jenis_norm, self.abs_path.strip(), self.roll_path.strip(), self.version_path.strip())

    @property
    def jenis_norm(self):
        order = [t for t in ("ABS", "Roll") if t in self.types]
        return "+".join("ROLL" if t == "Roll" else t for t in order)


DEFAULT_INI = """\
; ============================================================
;  ABSROLL - client.ini
;  File ini = MASTER konfigurasi target client.
;  Isinya otomatis disamakan ke database setiap kali aplikasi/batch dijalankan.
;
;  jenis        : ABS+ROLL (client butuh ABS dan Roller)  atau  ABS (hanya ABS)
;  abs_path     : folder tujuan file ABS.*.mdb
;  roll_path    : folder tujuan file Roll.*.mdb (kosongkan untuk jenis ABS)
;  version_path : folder tujuan version.txt (kosong = sama dengan abs_path)
;  Path boleh UNC (\\\\server\\folder) atau relatif terhadap folder ABSROLL.
; ============================================================

[pengaturan]
max_backup = 4
keep_processed = 10

[client1]
nama = Client ABS + Roller
jenis = ABS+ROLL
abs_path = data/client_demo/client1/ABS
roll_path = data/client_demo/client1/Roll
version_path = data/client_demo/client1

[client2]
nama = Client ABS saja
jenis = ABS
abs_path = data/client_demo/client2/ABS
roll_path =
version_path = data/client_demo/client2
"""


def ensure_ini():
    if not CLIENT_INI.exists():
        _general("absroll")                  # general.ini = master: salin dulu ke sini
    if not CLIENT_INI.exists():
        CLIENT_INI.write_text(DEFAULT_INI, encoding="utf-8")


def _parser():
    import configparser
    cp = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=None)
    cp.optionxform = str
    ensure_ini()
    cp.read(CLIENT_INI, encoding="utf-8")
    return cp


def read_settings():
    cp = _parser()
    sec = cp["pengaturan"] if cp.has_section("pengaturan") else {}

    def _int(name, default):
        try:
            return max(1, int(sec.get(name, default)))
        except (TypeError, ValueError):
            return default

    return {"max_backup": _int("max_backup", DEFAULT_MAX_BACKUP),
            "keep_processed": _int("keep_processed", DEFAULT_KEEP_PROCESSED)}


def read_targets():
    cp = _parser()
    out = []
    for sec in cp.sections():
        if sec == "pengaturan":
            continue
        g = cp[sec]
        out.append(Target(
            id=sec,
            nama=g.get("nama", sec).strip(),
            jenis=g.get("jenis", "ABS").strip(),
            abs_path=g.get("abs_path", "").strip(),
            roll_path=g.get("roll_path", "").strip(),
            version_path=g.get("version_path", "").strip(),
        ))
    return out


def write_targets(targets):
    """Tulis ulang client.ini (pengaturan dipertahankan)."""
    st = read_settings()
    lines = DEFAULT_INI.split("[pengaturan]")[0].rstrip() + "\n\n"
    lines += f"[pengaturan]\nmax_backup = {st['max_backup']}\nkeep_processed = {st['keep_processed']}\n"
    for t in targets:
        lines += (f"\n[{t.id}]\nnama = {t.nama}\njenis = {t.jenis_norm}\n"
                  f"abs_path = {t.abs_path}\nroll_path = {t.roll_path}\nversion_path = {t.version_path}\n")
    CLIENT_INI.write_text(lines, encoding="utf-8")
    _general("absroll", tarik=True)          # general.ini ikut diperbarui (master tetap sama dengan client.ini)


def validate_target(t):
    errs = []
    if not t.types:
        errs.append("jenis harus ABS atau ABS+ROLL")
    if "ABS" in t.types and not t.abs_path.strip():
        errs.append("abs_path wajib diisi")
    if "Roll" in t.types and not t.roll_path.strip():
        errs.append("roll_path wajib diisi untuk jenis ABS+ROLL")
    return errs


# ----------------------------------------------------------------------------
# version.txt
# ----------------------------------------------------------------------------
def render_version(versions, judul="ABSROLL", types=None):
    """versions: dict key -> versi. types: batasi tipe (mis. {'ABS'}) atau None = semua."""
    rows = []
    for key in sorted(versions):
        if types is not None and key.split(".")[0] not in types:
            continue
        rows.append(f"{key}={versions[key]}")
    head = f"# Zeno Lite - {judul}\n# Diperbarui: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
    return head + "\n".join(rows) + ("\n" if rows else "")


def read_version_file(path):
    out = {}
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def write_master_version(existing):
    VERSION_FILE.write_text(
        render_version({k: e.versi for k, e in existing.items()}, "ABSROLL (master)"),
        encoding="utf-8")


# ----------------------------------------------------------------------------
# existing / backup
# ----------------------------------------------------------------------------
@dataclass
class ExistingFile:
    key: str
    tipe: str
    kode: str
    versi: str
    path: Path
    mdb_name: str
    sha256: str

    @property
    def filename(self):
        return self.path.name


def list_existing():
    ensure_dirs()
    out = {}
    for p in sorted(EXISTING_DIR.glob("*.zip")):
        info = parse_name(p.name)
        if not info:
            continue
        try:
            mdb, sha = mdb_info(p)
        except ValueError:
            continue
        ef = ExistingFile(info["key"], info["tipe"], info["kode"], info["versi"], p, mdb, sha)
        cur = out.get(ef.key)
        if cur is None or vtuple(ef.versi) > vtuple(cur.versi):
            out[ef.key] = ef
    return out


@dataclass
class BackupFile:
    key: str
    versi: str
    ts: str
    n: int
    orig_name: str
    path: Path

    @property
    def filename(self):
        return self.path.name

    @property
    def waktu(self):
        return fmt_ts(self.ts)


def list_backups(key=None):
    ensure_dirs()
    out = []
    for p in BACKUP_DIR.glob("*.zip"):
        m = BACKUP_RE.match(p.name)
        if not m:
            continue
        info = parse_name(m.group("orig"))
        if not info or (key and info["key"] != key):
            continue
        out.append(BackupFile(info["key"], info["versi"], m.group("ts"),
                              int(m.group("n") or 0), m.group("orig"), p))
    out.sort(key=lambda b: (b.ts, b.n), reverse=True)  # terbaru dulu
    return out


def backup_keys():
    return sorted({b.key for b in list_backups()})


def _move_to_backup(ef_path):
    ts = _now_ts()
    # nomor urut = terbesar di detik yang sama + 1 (agar urutan tidak terbalik setelah prune)
    same = [int(m.group("n") or 0) for p in BACKUP_DIR.glob("*.zip")
            if (m := BACKUP_RE.match(p.name)) and m.group("ts") == ts]
    n = (max(same) + 1) if same else 0
    suffix = f"_{n}" if n else ""
    dest = BACKUP_DIR / f"{ts}{suffix}__{ef_path.name}"
    shutil.move(str(ef_path), str(dest))
    return dest


def prune_backups(key):
    limit = read_settings()["max_backup"]
    for b in list_backups(key)[limit:]:
        b.path.unlink(missing_ok=True)


def _atomic_copy(src, dest):
    tmp = Path(str(dest) + ".tmp")
    shutil.copyfile(src, tmp)
    os.replace(tmp, dest)


# ----------------------------------------------------------------------------
# Scan data/new  ->  rencana (plan)
# ----------------------------------------------------------------------------
@dataclass
class Candidate:
    key: str
    tipe: str
    kode: str
    versi: str
    filename: str
    path: Path
    source: str           # nama file di data/new tempat zip ini berasal
    mdb_name: str
    sha256: str
    status: str = "pending"   # pending | applied | sama | digantikan | ditolak


ACTION_LABEL = {
    "baru": "BARU",
    "update": "UPDATE (lebih baru)",
    "downgrade": "VERSI LEBIH LAMA (rollback)",
    "isi_beda": "VERSI SAMA, ISI BERBEDA",
    "sama": "SUDAH SAMA",
}


@dataclass
class PlanItem:
    cand: Candidate
    action: str
    existing_versi: str = ""
    skipped_versi: list = field(default_factory=list)

    @property
    def key(self):
        return self.cand.key

    @property
    def versi(self):
        return self.cand.versi

    @property
    def token(self):
        return f"{self.key}|{self.cand.sha256[:10]}"

    @property
    def label(self):
        return ACTION_LABEL[self.action]

    @property
    def needs_confirm(self):
        return self.action != "sama"


@dataclass
class Plan:
    items: list
    candidates: list
    warnings: list
    sources: list
    work_dir: Path

    def cleanup(self):
        shutil.rmtree(self.work_dir, ignore_errors=True)


def _clean_stale_work():
    if not WORK_DIR.exists():
        return
    for d in WORK_DIR.iterdir():
        try:
            if d.is_dir() and time.time() - d.stat().st_mtime > 3600:
                shutil.rmtree(d, ignore_errors=True)
        except OSError:
            pass


def new_files():
    ensure_dirs()
    return sorted(p for p in NEW_DIR.glob("*.zip") if not p.name.startswith("_"))


def build_plan():
    """Ekstrak semua zip di data/new (zip luar -> zip dalam), lalu bandingkan dengan existing."""
    ensure_dirs()
    _clean_stale_work()
    work = Path(tempfile.mkdtemp(prefix="plan_", dir=WORK_DIR))
    warnings, cands, sources = [], [], []

    def add_candidate(path, source):
        info = parse_name(path.name)
        try:
            mdb, sha = mdb_info(path)
        except ValueError as e:
            warnings.append(f"{path.name} ({source}): dilewati, {e}")
            return
        cands.append(Candidate(info["key"], info["tipe"], info["kode"], info["versi"],
                               path.name, path, source, mdb, sha))

    for f in new_files():
        sources.append(f.name)
        if parse_name(f.name):                      # zip dalam diletakkan langsung
            add_candidate(f, f.name)
            continue
        found = 0
        try:
            with zipfile.ZipFile(f) as zf:
                sub = work / f"{len(sources):02d}_{f.stem}"
                sub.mkdir(exist_ok=True)
                for mem in zf.infolist():
                    if mem.is_dir():
                        continue
                    base = Path(mem.filename.replace("\\", "/")).name   # cegah zip-slip
                    if not parse_name(base):
                        continue
                    out = sub / base
                    with zf.open(mem) as s, open(out, "wb") as d:
                        shutil.copyfileobj(s, d, 1024 * 1024)
                    found += 1
                    add_candidate(out, f.name)
        except zipfile.BadZipFile:
            warnings.append(f"{f.name}: bukan file zip yang valid")
            continue
        if not found:
            warnings.append(f"{f.name}: tidak ditemukan zip berformat Tipe.Kode.Versi.zip (mis. Roll.W6.08.02.00.17.zip)")

    # Per key hanya ambil versi terbaru
    by_key = {}
    for c in cands:
        by_key.setdefault(c.key, []).append(c)
    existing = list_existing()
    items = []
    for key in sorted(by_key):
        group = sorted(by_key[key], key=lambda c: vtuple(c.versi), reverse=True)
        best = group[0]
        skipped = []
        for other in group[1:]:
            other.status = "digantikan"
            skipped.append(other.versi)
        ex = existing.get(key)
        if ex is None:
            action = "baru"
        else:
            cmp = (vtuple(best.versi) > vtuple(ex.versi)) - (vtuple(best.versi) < vtuple(ex.versi))
            if cmp > 0:
                action = "update"
            elif cmp < 0:
                action = "downgrade"
            else:
                action = "sama" if best.sha256 == ex.sha256 else "isi_beda"
        items.append(PlanItem(best, action, ex.versi if ex else "", sorted(set(skipped), key=vtuple, reverse=True)))
    return Plan(items, cands, warnings, sources, work)


def apply_item(item):
    """Terapkan satu item: existing lama -> backup, file baru -> existing. Return nama backup / None."""
    ensure_dirs()
    old = list_existing().get(item.key)
    backup = None
    if old:
        backup = _move_to_backup(old.path)
    dest = EXISTING_DIR / item.cand.filename
    try:
        _atomic_copy(item.cand.path, dest)
    except Exception:
        if backup and not old.path.exists():
            shutil.move(str(backup), str(old.path))   # kembalikan
        raise
    prune_backups(item.key)
    return backup.name if backup else None


def do_rollback(key, backup_filename):
    """Tukar existing <-> backup terpilih. Existing saat ini ikut disimpan ke backup."""
    ensure_dirs()
    bk = next((b for b in list_backups(key) if b.filename == backup_filename), None)
    if not bk:
        raise ValueError("File backup tidak ditemukan")
    old = list_existing().get(key)
    if old:
        _move_to_backup(old.path)
    dest = EXISTING_DIR / bk.orig_name
    shutil.move(str(bk.path), str(dest))
    prune_backups(key)
    return bk


def archive_sources(plan):
    """Pindahkan file di data/new yang seluruh isinya sudah selesai ke data/processed."""
    moved = []
    for src in plan.sources:
        mine = [c for c in plan.candidates if c.source == src]
        if not mine or any(c.status in ("pending", "ditolak") for c in mine):
            continue
        p = NEW_DIR / src
        if p.exists():
            shutil.move(str(p), str(PROCESSED_DIR / f"{_now_ts()}__{src}"))
            moved.append(src)
    keep = read_settings()["keep_processed"]
    files = sorted(PROCESSED_DIR.glob("*__*"), key=lambda x: x.name, reverse=True)
    for old in files[keep:]:
        old.unlink(missing_ok=True)
    return moved


# ----------------------------------------------------------------------------
# Kirim ke client
# ----------------------------------------------------------------------------
@dataclass
class DeployResult:
    target_id: str
    key: str
    versi: str
    ok: bool
    message: str


def deploy_to_target(target, existing, keys=None):
    """Salin mdb (dan version.txt) ke satu target client."""
    results = []
    sent_ok = {}
    for key, ef in sorted(existing.items()):
        if ef.tipe not in target.types or (keys is not None and key not in keys):
            continue
        folder = target.dir_for(ef.tipe)
        if folder is None:
            results.append(DeployResult(target.id, key, ef.versi, False,
                                        f"path {'abs_path' if ef.tipe == 'ABS' else 'roll_path'} belum diisi di client.ini"))
            continue
        try:
            extract_mdb(ef.path, folder, ef.mdb_name)
            sent_ok[key] = ef.versi
            results.append(DeployResult(target.id, key, ef.versi, True, f"{ef.mdb_name} -> {folder}"))
        except PermissionError:
            results.append(DeployResult(target.id, key, ef.versi, False,
                                        f"{ef.mdb_name} sedang dipakai / akses ditolak di {folder}"))
        except Exception as e:  # jaringan putus, path salah, dll.
            results.append(DeployResult(target.id, key, ef.versi, False, f"{type(e).__name__}: {e}"))

    # version.txt di client = versi yang BENAR-BENAR terpasang di client
    vdir = target.version_dir
    if vdir is not None:
        try:
            vdir.mkdir(parents=True, exist_ok=True)
            vfile = vdir / "version.txt"
            prior = {k: v for k, v in read_version_file(vfile).items() if k.split(".")[0] in target.types}
            prior.update(sent_ok)
            for k in list(prior):                       # buang key yang sudah tidak ada di existing
                if k not in existing:
                    prior.pop(k)
            tmp = vdir / ".version.txt.zeno.tmp"
            tmp.write_text(render_version(prior, target.nama, target.types), encoding="utf-8")
            os.replace(tmp, vfile)
        except Exception as e:
            results.append(DeployResult(target.id, "version.txt", "", False, f"{type(e).__name__}: {e}"))
    return results
