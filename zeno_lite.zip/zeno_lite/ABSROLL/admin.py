from django.contrib import admin

from .models import ActionLog, ClientTarget, CurrentVersion, Deployment


@admin.register(CurrentVersion)
class CurrentVersionAdmin(admin.ModelAdmin):
    list_display = ("key", "versi", "filename", "updated_at")


@admin.register(ClientTarget)
class ClientTargetAdmin(admin.ModelAdmin):
    list_display = ("tid", "nama", "jenis", "abs_path", "roll_path")


@admin.register(Deployment)
class DeploymentAdmin(admin.ModelAdmin):
    list_display = ("target", "key", "versi_terkirim", "status", "waktu", "waktu_sukses")


@admin.register(ActionLog)
class ActionLogAdmin(admin.ModelAdmin):
    list_display = ("waktu", "aksi", "key", "dari_versi", "ke_versi", "oleh", "status")
    list_filter = ("aksi", "status")
