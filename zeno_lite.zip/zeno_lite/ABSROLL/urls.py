from django.urls import path

from . import views

app_name = "absroll"

urlpatterns = [
    path("", views.index, name="index"),
    path("upload/", views.upload, name="upload"),
    path("preview/", views.preview, name="preview"),
    path("rollback/", views.rollback, name="rollback"),
    path("kirim/", views.deploy_all, name="deploy"),
    path("samakan/", views.samakan, name="samakan"),
    path("target/", views.targets, name="targets"),
]
