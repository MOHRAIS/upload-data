@echo off
title ABSROLL - Sinkron
call "%~dp0_prep.bat"
if errorlevel 1 exit /b 1
venv\Scripts\python.exe manage.py absroll sync %*
echo.
pause
