@echo off
title ABSROLL
call "%~dp0_prep.bat"
if errorlevel 1 exit /b 1

:menu
cls
echo ==============================
echo        ABSROLL  (Zeno Lite)
echo ==============================
echo   [1] Sinkron file baru   (ABSROLL\data\new)
echo   [2] Rollback            (pilih file dari backup)
echo   [3] Kirim ulang ke semua client
echo   [4] Status versi dan client
echo   [5] Verifikasi dan samakan data
echo   [0] Keluar
echo.
choice /c 123450 /n /m "Pilih menu: "
if errorlevel 6 goto :eof
if errorlevel 5 (venv\Scripts\python.exe manage.py absroll verify & goto :done)
if errorlevel 4 (venv\Scripts\python.exe manage.py absroll status & goto :done)
if errorlevel 3 (venv\Scripts\python.exe manage.py absroll deploy & goto :done)
if errorlevel 2 (venv\Scripts\python.exe manage.py absroll rollback & goto :done)
if errorlevel 1 (venv\Scripts\python.exe manage.py absroll sync & goto :done)
goto :menu

:done
echo.
pause
goto :menu
