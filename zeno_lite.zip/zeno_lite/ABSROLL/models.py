from django.db import models


class CurrentVersion(models.Model):
    """Cermin versi file yang sedang berjalan (folder data/existing)."""
    key = models.CharField("Tipe.Kode", max_length=40, unique=True)
    tipe = models.CharField(max_length=10)
    kode = models.CharField(max_length=20)
    versi = models.CharField(max_length=30)
    filename = models.CharField(max_length=120)
    mdb_name = models.CharField(max_length=120, blank=True)
    sha256 = models.CharField("SHA256 isi mdb", max_length=64, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["key"]
        verbose_name = "Versi berjalan"
        verbose_name_plural = "Versi berjalan"

    def __str__(self):
        return f"{self.key} = {self.versi}"


class ClientTarget(models.Model):
    """Cermin client.ini (master tetap client.ini)."""
    tid = models.CharField("ID", max_length=40, unique=True)
    nama = models.CharField(max_length=100)
    jenis = models.CharField(max_length=20)
    abs_path = models.CharField(max_length=300, blank=True)
    roll_path = models.CharField(max_length=300, blank=True)
    version_path = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["tid"]
        verbose_name = "Target client"
        verbose_name_plural = "Target client"

    def __str__(self):
        return f"{self.tid} ({self.jenis})"


class Deployment(models.Model):
    """Tracking: versi apa yang terakhir berhasil dikirim ke tiap target."""
    target = models.CharField(max_length=40)
    key = models.CharField(max_length=40)
    versi_terkirim = models.CharField(max_length=30, blank=True)
    status = models.CharField(max_length=10)          # ok / gagal
    pesan = models.TextField(blank=True)
    waktu = models.DateTimeField(auto_now=True)       # percobaan terakhir
    waktu_sukses = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = ("target", "key")
        ordering = ["target", "key"]
        verbose_name = "Pengiriman"
        verbose_name_plural = "Pengiriman"


class ActionLog(models.Model):
    """Riwayat semua aksi (sinkron, rollback, kirim, perbaikan data)."""
    waktu = models.DateTimeField(auto_now_add=True)
    aksi = models.CharField(max_length=20)
    key = models.CharField(max_length=40, blank=True)
    dari_versi = models.CharField(max_length=30, blank=True)
    ke_versi = models.CharField(max_length=30, blank=True)
    oleh = models.CharField(max_length=60, blank=True)
    status = models.CharField(max_length=10, default="ok")
    pesan = models.TextField(blank=True)

    class Meta:
        ordering = ["-waktu", "-id"]
        verbose_name = "Log aksi"
        verbose_name_plural = "Log aksi"
