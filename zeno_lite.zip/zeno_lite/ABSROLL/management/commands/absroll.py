"""
Dipanggil dari batch:  python manage.py absroll <aksi>
  sync      baca data/new, bandingkan, konfirmasi, terapkan, kirim ke client
  rollback  pilih file yang akan dikembalikan dari data/backup
  deploy    kirim ulang semua mdb + version.txt ke semua client
  status    lihat versi berjalan & status tiap client
  verify    cek kesesuaian folder / database / version.txt / client.ini
"""
from django.core.management.base import BaseCommand, CommandError

from ABSROLL import core, services

OLEH = "BATCH"


def ask(prompt, default=False):
    hint = "[Y/n]" if default else "[y/N]"
    try:
        ans = input(f"{prompt} {hint} ").strip().lower()
    except EOFError:
        return False
    if not ans:
        return default
    return ans in ("y", "ya", "yes")


class Command(BaseCommand):
    help = "ABSROLL: sinkron, rollback, kirim, status"

    def add_arguments(self, parser):
        parser.add_argument("aksi", nargs="?", default="status",
                            choices=["sync", "rollback", "deploy", "status", "verify"])
        parser.add_argument("-y", "--yes", action="store_true",
                            help="setujui otomatis semua item (kecuali versi lebih lama)")
        parser.add_argument("--allow-downgrade", action="store_true",
                            help="setujui juga versi yang lebih lama dari yang berjalan")

    # ------------------------------------------------------------------
    def handle(self, *args, **o):
        core.ensure_dirs()
        core.ensure_ini()
        try:
            issues = services.auto_heal(OLEH)
            if issues:
                self.stdout.write(self.style.WARNING(
                    "Data tidak sinkron ditemukan dan sudah disamakan:\n  " + "\n  ".join(issues)))
            getattr(self, "do_" + o["aksi"])(o)
        except core.BusyError as e:
            raise CommandError(str(e))

    # ------------------------------------------------------------------
    def out(self, text="", style=None):
        self.stdout.write(getattr(self.style, style)(text) if style else text)

    def print_report(self, rep):
        self.out()
        self.out(f"== {rep.judul} ==", "MIGRATE_HEADING")
        style = {"ok": "SUCCESS", "warn": "WARNING", "err": "ERROR", "info": None}
        for level, text in rep.rows:
            self.out(f"  [{level.upper():4}] {text}", style[level])
        if rep.deploy:
            self.out("  Pengiriman ke client:")
            for d in rep.deploy:
                self.out(f"    {'OK   ' if d['ok'] else 'GAGAL'} {d['target']:24} {d['key']:12} {d['versi']:12} {d['message']}",
                         "SUCCESS" if d["ok"] else "ERROR")

    # ------------------------------------------------------------------
    def do_status(self, o):
        existing = core.list_existing()
        self.out("VERSI BERJALAN (data/existing)", "MIGRATE_HEADING")
        for k, e in sorted(existing.items()):
            self.out(f"  {k:12} {e.versi:14} {e.mdb_name}  backup: {len(core.list_backups(k))}")
        if not existing:
            self.out("  (belum ada)")
        self.out()
        self.out("STATUS CLIENT", "MIGRATE_HEADING")
        for blok in services.target_matrix():
            t = blok["t"]
            self.out(f"  {t.nama} [{t.jenis_norm}]")
            for e in blok["errors"]:
                self.out(f"     ! {e}", "ERROR")
            for r in blok["rows"]:
                self.out(f"     {r['key']:12} berjalan={r['versi']:12} terkirim={r['sent']:12} {r['state'].upper()}")
        pend = core.new_files()
        self.out()
        self.out(f"File menunggu di data/new: {len(pend)}" + ("".join(f"\n  - {p.name}" for p in pend)))

    def do_verify(self, o):
        issues = services.consistency()
        if issues:
            self.out("Masih ada ketidaksesuaian:\n  " + "\n  ".join(issues), "WARNING")
        else:
            self.out("Semua sinkron: folder = database = version.txt, client.ini = database.", "SUCCESS")

    def do_deploy(self, o):
        if not (o["yes"] or ask("Kirim ulang SEMUA file ke SEMUA client?")):
            return self.out("Dibatalkan.")
        self.print_report(services.deploy_all(OLEH))

    def do_sync(self, o):
        plan = core.build_plan()
        try:
            items, warns, sources = list(plan.items), list(plan.warnings), list(plan.sources)
        finally:
            plan.cleanup()
        if not sources:
            return self.out("Tidak ada file di ABSROLL\\data\\new. Taruh ABS.zip / Roller.zip di sana lalu jalankan lagi.", "WARNING")
        self.out("File ditemukan: " + ", ".join(sources))
        for w in warns:
            self.out(f"  ! {w}", "WARNING")
        if not items:
            return self.out("Tidak ada zip berformat Tipe.Kode.Versi.zip yang bisa diproses.", "WARNING")

        self.out()
        self.out("RENCANA", "MIGRATE_HEADING")
        for it in items:
            extra = f"   (versi lain di paket dilewati: {', '.join(it.skipped_versi)})" if it.skipped_versi else ""
            self.out(f"  {it.key:12} {it.existing_versi or '-':12} -> {it.versi:12} {it.label}{extra}")
        self.out()

        selected, downgrade_ok = set(), set()
        todo = [i for i in items if i.needs_confirm]
        for n, it in enumerate(todo, 1):
            head = f"[{n}/{len(todo)}] {it.key}: {it.existing_versi or '(baru)'} -> {it.versi}"
            if it.action == "downgrade":
                self.out(f"{head}", "ERROR")
                self.out("   PERHATIAN: versi ini LEBIH LAMA dari yang sedang berjalan (ini berarti rollback).", "ERROR")
                self.out("   Versi yang berjalan sekarang akan dipindah ke backup.")
                if o["allow_downgrade"] or ask("   Tetap lanjut dengan versi lama ini?"):
                    selected.add(it.token)
                    downgrade_ok.add(it.token)
            else:
                msg = "Terapkan (versi lama dipindah ke backup, lalu kirim ke client)?" if it.existing_versi \
                    else "Tambahkan file baru ini dan kirim ke client?"
                if o["yes"] or ask(f"{head}\n   {msg}", default=True):
                    selected.add(it.token)
        if not selected and all(i.action != "sama" for i in items):
            return self.out("Tidak ada yang diterapkan.")
        self.print_report(services.run_plan(selected, downgrade_ok, OLEH))

    def do_rollback(self, o):
        keys = core.backup_keys()
        if not keys:
            return self.out("Belum ada file backup untuk di-rollback.", "WARNING")
        existing = core.list_existing()
        self.out("PILIH FILE YANG AKAN DI-ROLLBACK", "MIGRATE_HEADING")
        for i, k in enumerate(keys, 1):
            cur = existing.get(k)
            self.out(f"  [{i}] {k}  (berjalan: {cur.versi if cur else '-'}, backup: {len(core.list_backups(k))})")
        key = self._pick(keys, "Nomor file (kosong = batal): ")
        if not key:
            return self.out("Dibatalkan.")
        bks = core.list_backups(key)
        self.out(f"\nBackup {key} (terbaru di atas):", "MIGRATE_HEADING")
        for i, b in enumerate(bks, 1):
            self.out(f"  [{i}] versi {b.versi}   disimpan {b.waktu}")
        bk = self._pick(bks, "Nomor versi tujuan (kosong = batal): ")
        if not bk:
            return self.out("Dibatalkan.")
        cur = existing.get(key)
        if not ask(f"Rollback {key}: {cur.versi if cur else '-'} -> {bk.versi} dan kirim ke client?"):
            return self.out("Dibatalkan.")
        self.print_report(services.rollback(key, bk.filename, OLEH))

    def _pick(self, seq, prompt):
        try:
            raw = input(prompt).strip()
        except EOFError:
            return None
        if raw.isdigit() and 1 <= int(raw) <= len(seq):
            return seq[int(raw) - 1]
        return None
