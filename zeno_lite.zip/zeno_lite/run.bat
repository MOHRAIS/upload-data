@echo off
setlocal
cd /d "%~dp0"
title Zeno Lite
set HOST=127.0.0.1
set PORT=8182

echo ==============================
echo        ZENO LITE
echo ==============================

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python belum terpasang atau belum masuk PATH.
    pause
    exit /b 1
)

if not exist venv (
    echo [1/5] Membuat virtual environment...
    python -m venv venv
)
call venv\Scripts\activate.bat

if not exist venv\.deps_ok (
    echo [2/5] Memasang dependensi...
    pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Gagal memasang dependensi. Cek koneksi internet.
        pause
        exit /b 1
    )
    echo ok> venv\.deps_ok
)

echo [3/5] Menyamakan general.ini ke semua modul...
python general_sync.py
rem Port dan akses jaringan dari general.ini, bagian [aplikasi]
for /f "delims=" %%i in ('python general_sync.py --get aplikasi port 8182') do set PORT=%%i
set RUNOPT=
for /f "delims=" %%i in ('python general_sync.py --get aplikasi akses_jaringan false') do set NET=%%i
if /i "%NET%"=="true" (
    set HOST=0.0.0.0
    set RUNOPT=--insecure
)
echo [4/5] Menyiapkan database...
python manage.py makemigrations accounts absroll vehicleid dombtrv
python manage.py migrate
python manage.py ensure_admin
echo Memeriksa file terbaru Vehicle Identification...
python manage.py vehicleid sync --quiet

echo [5/5] Menjalankan server
echo       Komputer ini : http://127.0.0.1:%PORT%
if /i "%NET%"=="true" (
    for /f "delims=" %%i in ('python general_sync.py --lan') do echo       HP / jaringan: http://%%i:%PORT%
    echo       Akses jaringan AKTIF ^(general.ini^). Pastikan password admin sudah diganti.
)
rem Buka browser setelah server siap (Edge dulu, lalu Chrome, lalu default)
start "" /b cmd /c "timeout /t 3 >nul & (start msedge http://127.0.0.1:%PORT% || start chrome http://127.0.0.1:%PORT% || start http://127.0.0.1:%PORT%)"

echo.
echo Tutup jendela ini atau tekan CTRL+C untuk menghentikan aplikasi.
python manage.py runserver %HOST%:%PORT% --noreload %RUNOPT%

pause
