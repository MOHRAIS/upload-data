@echo off
rem Batch ini HANYA membaca database hasil scan terakhir (tidak men-scan folder).
title DOM/BTRV
call "%~dp0_prep.bat"
if errorlevel 1 exit /b 1
cls
venv\Scripts\python.exe manage.py dombtrv status

:menu
echo.
echo ==============================
echo           DOM / BTRV
echo ==============================
echo   [1] Cari (VIN, PartNo, SerialNo, nama part, hostname...)
echo   [2] Cari dengan filter (part, hostname, model, tanggal)
echo   [3] Lihat pilihan filter yang tersedia
echo   [4] Status dan waktu scan terakhir
echo   [0] Keluar
echo.
choice /c 12340 /n /m "Pilih menu: "
if errorlevel 5 goto :eof
if errorlevel 4 (venv\Scripts\python.exe manage.py dombtrv status & goto :menu)
if errorlevel 3 goto :pilihan
if errorlevel 2 goto :filter
if errorlevel 1 goto :cari
goto :menu

:cari
echo.
set "Q="
set /p "Q=Cari (kosong = semua): "
venv\Scripts\python.exe manage.py dombtrv cari %Q%
goto :menu

:pilihan
echo.
set "Q="
set /p "Q=Kata pencarian untuk menyempitkan pilihan (boleh kosong): "
venv\Scripts\python.exe manage.py dombtrv pilihan %Q%
goto :menu

:filter
echo.
echo Kosongkan bagian yang tidak dipakai (tekan Enter).
set "Q=" & set "P=" & set "H=" & set "M=" & set "D1=" & set "D2="
set /p "Q=Kata pencarian         : "
set /p "P=Part (nama persis)     : "
set /p "H=Hostname (persis)      : "
set /p "M=Model (mis. G70)       : "
set /p "D1=Dari tanggal YYYY-MM-DD : "
set /p "D2=Sampai tanggal YYYY-MM-DD: "
set "ARGS="
if defined P set ARGS=%ARGS% --part "%P%"
if defined H set ARGS=%ARGS% --hostname "%H%"
if defined M set ARGS=%ARGS% --model "%M%"
if defined D1 set ARGS=%ARGS% --dari %D1%
if defined D2 set ARGS=%ARGS% --sampai %D2%
venv\Scripts\python.exe manage.py dombtrv cari %Q% %ARGS%
goto :menu
