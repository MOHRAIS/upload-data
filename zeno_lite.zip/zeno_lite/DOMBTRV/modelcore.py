"""
DOMBTRV - update file model xml (Part List) ke server. Logika inti TANPA Django.

Aturan:
  * Model + versi dibaca dari baris pertama file, 3 pola komentar:
        <!-- F74 Part List v007.4 -->       model di depan
        <!-- Part List G45 v011.3 -->       model di tengah
        <!-- G2X Part List v008.5 -->       X = satu angka 0-9 (G20 ... G29)
  * Sumber kebenaran = versi TERTINGGI di antara: upload (data baru), salinan aplikasi, dan file di server.
      - server lebih tinggi  -> server -> aplikasi (server selalu benar)
      - server lebih rendah  -> aplikasi/upload -> server
      - versi sama tetapi isi beda -> KONFLIK, harus dipilih manual
  * File yang diganti tidak pernah ditimpa: di aplikasi -> modeldata\\backup, di server -> <model>\\Archive.
"""
import difflib
import hashlib
import os
import re
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path

from . import core

DATA_DIR = core.MODULE_DIR / "modeldata"
NEW_DIR = DATA_DIR / "new"
EXISTING_DIR = DATA_DIR / "existing"
BACKUP_DIR = DATA_DIR / "backup"
PROCESSED_DIR = DATA_DIR / "processed"
VERSIONS_TXT = DATA_DIR / "versions.txt"
LOCK_FILE = core.MODULE_DIR / ".modellock"
KEEP_PROCESSED = 10
MAX_FILE_BYTES = 20 * 1024 * 1024

HEADER_RE = re.compile(
    r"<!--\s*(?:(?P<m1>[A-Za-z0-9]{2,8})\s+)?Part\s+List\s+(?:(?P<m2>[A-Za-z0-9]{2,8})\s+)?"
    r"v(?P<ver>\d+(?:\.\d+)*)\s*-->", re.I)
BACKUP_RE = re.compile(r"^(?P<ts>\d{8}-\d{6})(?:_(?P<n>\d+))?__(?P<ver>[^_]+)__(?P<name>.+)$")

SpecAPP, SpecUPLOAD = "app", "upload"


class lock:
    """Kunci agar update model dari web / batch tidak bersamaan."""

    def __enter__(self):
        ensure_dirs()
        if LOCK_FILE.exists() and time.time() - LOCK_FILE.stat().st_mtime > 15 * 60:
            LOCK_FILE.unlink(missing_ok=True)
        try:
            fd = os.open(LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
        except FileExistsError:
            raise core.BusyError("Update model XML lain sedang berjalan (web/batch). Tunggu sampai selesai.")
        return self

    def __exit__(self, *exc):
        LOCK_FILE.unlink(missing_ok=True)


def ensure_dirs():
    for d in (NEW_DIR, EXISTING_DIR, BACKUP_DIR, PROCESSED_DIR):
        d.mkdir(parents=True, exist_ok=True)


def _ts():
    return time.strftime("%Y%m%d-%H%M%S")


def fmt_ts(ts):
    try:
        return time.strftime("%Y-%m-%d %H:%M:%S", time.strptime(ts, "%Y%m%d-%H%M%S"))
    except ValueError:
        return ts


# ------------------------------------------------------------------ baca file + header
def parse_header(text):
    """Return (key, version_raw, version_tuple) atau None. key = 'F74' / 'G45' / 'G2X'."""
    m = HEADER_RE.search(text[:2000])
    if not m:
        return None
    key = (m.group("m1") or m.group("m2") or "").upper()
    if not key or key in ("PART", "LIST"):
        return None
    ver = m.group("ver")
    return key, "v" + ver, tuple(int(x) for x in ver.split("."))


def _decode(raw):
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace")


def norm_lines(text):
    """Baris tanpa spasi di ujung & tanpa baris kosong di akhir (beda CRLF/LF diabaikan)."""
    lines = [ln.rstrip() for ln in text.splitlines()]
    while lines and not lines[-1]:
        lines.pop()
    return lines


@dataclass
class FileInfo:
    path: Path
    exists: bool = False
    size: int = 0
    mtime: float = 0.0
    key: str = ""
    version_raw: str = ""
    version: tuple = None
    norm: str = ""             # hash isi yang sudah dinormalkan (dipakai untuk 'sama / beda')
    error: str = ""

    @property
    def readable(self):
        return self.exists and self.version is not None and not self.error


def inspect(path):
    path = Path(path)
    fi = FileInfo(path)
    try:
        st = path.stat()
    except OSError:
        return fi
    if not path.is_file():
        return fi
    fi.exists, fi.size, fi.mtime = True, st.st_size, st.st_mtime
    if st.st_size > MAX_FILE_BYTES:
        fi.error = "file terlalu besar"
        return fi
    try:
        raw = path.read_bytes()
    except OSError as e:
        fi.error = f"tidak bisa dibaca: {e}"
        return fi
    text = _decode(raw)
    fi.norm = hashlib.sha256("\n".join(norm_lines(text)).encode("utf-8")).hexdigest()
    h = parse_header(text)
    if h:
        fi.key, fi.version_raw, fi.version = h
    else:
        fi.error = "header versi tidak dikenali (baris pertama harus berisi '<!-- ... Part List ... vNNN.N -->')"
    return fi


def vtext(fi):
    return fi.version_raw if fi and fi.version else "?"


# ------------------------------------------------------------------ folder server
class ServerError(Exception):
    pass


def list_server(root, nama_file):
    """{nama_folder: FileInfo file model di folder itu}. ServerError bila root tak terjangkau."""
    root = Path(root)
    try:
        if not root.is_dir():
            raise ServerError(f"Folder server tidak ditemukan / tidak bisa diakses: {root}")
        names = sorted(d.name for d in root.iterdir() if d.is_dir() and d.name.lower() != "archive"
                       and not d.name.startswith("."))
    except OSError as e:
        raise ServerError(f"Folder server tidak bisa dibaca: {root} ({e})")
    return {n: inspect(root / n / nama_file) for n in names}


def wildcard_regex(key):
    return re.compile("^" + "".join(r"\d" if c == "X" else re.escape(c) for c in key.upper()) + "$")


def resolve_folders(key, folder_names):
    """Folder server yang dituju sebuah key. Pas -> folder itu; mengandung X -> semua folder G20..G29 yang ada."""
    exact = [f for f in folder_names if f.upper() == key.upper()]
    if exact:
        return exact
    if "X" in key.upper():
        rx = wildcard_regex(key)
        return [f for f in folder_names if rx.match(f.upper())]
    return []


# ------------------------------------------------------------------ rencana
@dataclass
class Source:
    spec: str          # app | upload | server:<folder> | backup:<file>
    label: str
    info: FileInfo

    @property
    def vtext(self):
        return vtext(self.info)


@dataclass
class KeyPlan:
    key: str
    wildcard: bool
    sources: list = field(default_factory=list)
    targets: list = field(default_factory=list)          # folder server yang ada & akan menerima file
    missing: list = field(default_factory=list)          # folder server yang belum ada
    notes: list = field(default_factory=list)
    upload_files: list = field(default_factory=list)     # FileInfo semua upload untuk key ini
    recommended: str = None
    conflict: bool = False
    reason: str = ""

    def source(self, spec):
        return next((s for s in self.sources if s.spec == spec), None)

    @property
    def token(self):
        raw = "|".join(f"{s.spec}={s.info.norm[:12]}" for s in self.sources) + "|" + ",".join(self.targets)
        return hashlib.sha1(raw.encode()).hexdigest()[:12]

    def actions(self, spec):
        """Apa yang akan terjadi bila sumber `spec` dipilih."""
        src = self.source(spec)
        if src is None:
            return None
        app = self.source(SpecAPP)
        out = {"app": False, "push": [], "create": list(self.missing), "from": src}
        if spec != SpecAPP and (app is None or app.info.norm != src.info.norm):
            out["app"] = True
        for f in self.targets:
            srv = self.source(f"server:{f}")
            cur_norm = srv.info.norm if srv else ""
            if not (srv and cur_norm == src.info.norm):
                out["push"].append(f)
        return out

    @property
    def in_sync(self):
        if self.recommended is None:
            return False
        a = self.actions(self.recommended)
        return not a["app"] and not a["push"]

    @property
    def status(self):
        if self.conflict:
            return "konflik"
        if self.recommended is None:
            return "error"
        return "sama" if self.in_sync and not self.upload_pending else "tindakan"

    @property
    def upload_pending(self):
        """Ada upload yang isinya beda dari pilihan rekomendasi (perlu keputusan / dilewati)."""
        up = self.source(SpecUPLOAD)
        if not up or self.recommended is None:
            return False
        rec = self.source(self.recommended)
        return rec.info.norm != up.info.norm


@dataclass
class ModelPlan:
    items: list
    warnings: list
    server_ok: bool
    server: dict
    cfg: dict

    def item(self, key):
        return next((i for i in self.items if i.key == key), None)


def new_files():
    ensure_dirs()
    return sorted(p for p in NEW_DIR.rglob("*.xml") if not p.name.startswith("_"))


def app_copy_path(key, cfg):
    return EXISTING_DIR / key / cfg["model_file"]


def list_app_copies(cfg):
    ensure_dirs()
    out = {}
    for d in sorted(EXISTING_DIR.iterdir()):
        if d.is_dir():
            fi = inspect(d / cfg["model_file"])
            if fi.exists:
                out[d.name] = fi
    return out


def build_plan(cfg=None):
    cfg = cfg or core.read_config()
    ensure_dirs()
    warnings = []
    try:
        server = list_server(cfg["model_server"], cfg["model_file"])
        server_ok = True
    except ServerError as e:
        return ModelPlan([], [str(e)], False, {}, cfg)

    # --- upload (data\\baru): per key hanya versi tertinggi yang dipakai
    uploads = {}
    for p in new_files():
        fi = inspect(p)
        if not fi.readable:
            warnings.append(f"Upload {p.name}: {fi.error or 'tidak terbaca'} - dilewati")
            continue
        uploads.setdefault(fi.key, []).append(fi)

    app = list_app_copies(cfg)
    srv_by_key = {}
    for f, fi in server.items():
        if fi.exists and fi.key:
            srv_by_key.setdefault(fi.key, []).append(f)
        elif fi.exists:
            warnings.append(f"Server {f}\\{cfg['model_file']}: {fi.error}")

    keys = sorted(set(uploads) | set(app) | set(srv_by_key))
    items = []
    for key in keys:
        kp = KeyPlan(key=key, wildcard="X" in key)
        folders = resolve_folders(key, list(server))
        for f in folders:
            fi = server[f]
            if fi.exists and fi.key and fi.key != key:
                kp.notes.append(f"Folder {f} berisi file dengan header {fi.key} (bukan {key}) - tidak diubah.")
                continue
            kp.targets.append(f)
        if not folders:
            if kp.wildcard:
                kp.notes.append(f"Tidak ada folder server yang cocok dengan {key} (mis. G20-G29).")
            else:
                kp.missing.append(key)
                kp.notes.append(f"Folder {key} belum ada di server.")
        # sumber
        ups = sorted(uploads.get(key, []), key=lambda x: x.version, reverse=True)
        kp.upload_files = ups
        if ups:
            kp.sources.append(Source(SpecUPLOAD, "Upload", ups[0]))
            for other in ups[1:]:
                if other.norm != ups[0].norm:
                    kp.notes.append(f"Upload {other.path.name} ({vtext(other)}) lebih lama dari upload lain - diabaikan.")
        if key in app:
            kp.sources.append(Source(SpecAPP, "Aplikasi", app[key]))
        for f in kp.targets:
            fi = server[f]
            if fi.exists:
                kp.sources.append(Source(f"server:{f}", f"Server {f}", fi))
        _recommend(kp)
        items.append(kp)
    return ModelPlan(items, warnings, server_ok, server, cfg)


def _recommend(kp):
    cands = [s for s in kp.sources if s.info.readable]
    if not cands:
        kp.reason = "Tidak ada sumber yang bisa dibaca."
        return
    top = max(s.info.version for s in cands)
    tops = [s for s in cands if s.info.version == top]
    if len({s.info.norm for s in tops}) > 1:
        kp.conflict = True
        kp.reason = (f"KONFLIK: versi tertinggi ({tops[0].vtext}) ada di beberapa sumber tetapi isinya berbeda: "
                     + ", ".join(s.label for s in tops) + ". Pilih sumber yang benar.")
        return
    prio = {"server": 0, SpecAPP: 1, SpecUPLOAD: 2}
    tops.sort(key=lambda s: prio.get(s.spec.split(":")[0], 3))
    best = tops[0]
    kp.recommended = best.spec
    others = [s for s in cands if s is not best and s.info.norm != best.info.norm]
    act = kp.actions(best.spec)
    if not others and (act["app"] or act["push"]):
        todo = []
        if act["app"]:
            todo.append("aplikasi")
        if act["push"]:
            todo.append("server " + ", ".join(act["push"]))
        kp.reason = f"Hanya {best.label} yang punya file ini ({best.vtext}): pasang ke {' dan '.join(todo)}."
    elif not others:
        kp.reason = f"Semua sama ({best.vtext})."
    elif best.spec.startswith("server:"):
        kp.reason = f"Versi server ({best.vtext}) paling tinggi -> server selalu benar: tarik ke aplikasi."
    elif best.spec == SpecUPLOAD:
        kp.reason = f"Upload ({best.vtext}) paling tinggi -> update aplikasi lalu dorong ke server."
    else:
        kp.reason = f"Aplikasi ({best.vtext}) lebih tinggi dari server -> dorong ke server."


# ------------------------------------------------------------------ perbandingan baris
def _read_norm(path):
    return norm_lines(_decode(Path(path).read_bytes()))


def _ranges(nums):
    out, start, prev = [], None, None
    for n in nums:
        if start is None:
            start = prev = n
        elif n == prev + 1:
            prev = n
        else:
            out.append((start, prev))
            start = prev = n
    if start is not None:
        out.append((start, prev))
    return [str(a) if a == b else f"{a}-{b}" for a, b in out]


def diff_summary(path_a, path_b):
    """Ringkasan: jumlah baris beda + nomor baris (sisi kiri/a)."""
    a, b = _read_norm(path_a), _read_norm(path_b)
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    added = removed = changed = 0
    lines_a = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        m, n = i2 - i1, j2 - j1
        if tag == "replace":
            changed += min(m, n)
            removed += max(0, m - n)
            added += max(0, n - m)
        elif tag == "delete":
            removed += m
        else:
            added += n
        lines_a.extend(range(i1 + 1, i2 + 1) if m else [i1 + 1])
    total = added + removed + changed
    only_first = bool(total) and set(lines_a) <= {1} and not added and not removed
    rng = _ranges(sorted(set(lines_a)))
    shown = ", ".join(rng[:10]) + (f", ... (+{len(rng) - 10} lainnya)" if len(rng) > 10 else "")
    return {"total": total, "added": added, "removed": removed, "changed": changed, "lines": shown,
            "same": total == 0, "only_version_line": only_first, "lines_a": len(a), "lines_b": len(b)}


def diff_summary_text(s):
    if s["same"]:
        return "isi sama"
    if s["only_version_line"]:
        return "hanya baris 1 (komentar versi) yang beda"
    return f"{s['total']} baris beda (+{s['added']} / -{s['removed']} / ubah {s['changed']}) di baris {s['lines']}"


def diff_hunks(path_a, path_b, context=2, max_rows=2000):
    """Rincian untuk tampilan: daftar blok, tiap baris {t: eq|chg|del|add, a, b, ta, tb}."""
    a, b = _read_norm(path_a), _read_norm(path_b)
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    hunks, rows_total, truncated = [], 0, False
    for group in sm.get_grouped_opcodes(context):
        rows = []
        for tag, i1, i2, j1, j2 in group:
            if tag == "equal":
                for k in range(i2 - i1):
                    rows.append({"t": "eq", "a": i1 + k + 1, "b": j1 + k + 1, "ta": a[i1 + k], "tb": b[j1 + k]})
                continue
            m, n = i2 - i1, j2 - j1
            for k in range(max(m, n)):
                if k < m and k < n:
                    rows.append({"t": "chg", "a": i1 + k + 1, "b": j1 + k + 1, "ta": a[i1 + k], "tb": b[j1 + k]})
                elif k < m:
                    rows.append({"t": "del", "a": i1 + k + 1, "b": None, "ta": a[i1 + k], "tb": ""})
                else:
                    rows.append({"t": "add", "a": None, "b": j1 + k + 1, "ta": "", "tb": b[j1 + k]})
        rows_total += len(rows)
        if rows_total > max_rows:
            truncated = True
            break
        hunks.append(rows)
    return {"hunks": hunks, "truncated": truncated, "summary": diff_summary(path_a, path_b)}


# ------------------------------------------------------------------ backup aplikasi
@dataclass
class Backup:
    key: str
    ts: str
    n: int
    version: str
    name: str
    path: Path

    @property
    def filename(self):
        return self.path.name

    @property
    def waktu(self):
        return fmt_ts(self.ts)


def list_backups(key=None):
    ensure_dirs()
    out = []
    for d in BACKUP_DIR.iterdir():
        if not d.is_dir() or (key and d.name != key):
            continue
        for p in d.glob("*"):
            m = BACKUP_RE.match(p.name)
            if m and p.is_file():
                out.append(Backup(d.name, m.group("ts"), int(m.group("n") or 0), m.group("ver"), m.group("name"), p))
    out.sort(key=lambda b: (b.ts, b.n), reverse=True)
    return out


def backup_keys():
    return sorted({b.key for b in list_backups()})


def _backup_app_copy(key, cfg):
    cur = app_copy_path(key, cfg)
    if not cur.exists():
        return None
    fi = inspect(cur)
    d = BACKUP_DIR / key
    d.mkdir(parents=True, exist_ok=True)
    ts = _ts()
    same = [int(m.group("n") or 0) for p in d.glob("*") if (m := BACKUP_RE.match(p.name)) and m.group("ts") == ts]
    n = (max(same) + 1) if same else 0
    dest = d / f"{ts}{'_' + str(n) if n else ''}__{fi.version_raw or 'v0'}__{cfg['model_file']}"
    shutil.move(str(cur), str(dest))
    return dest


def _prune_backups(key, cfg):
    for b in list_backups(key)[cfg["model_max_backup"]:]:
        b.path.unlink(missing_ok=True)


def _copy_atomic(src, dest):
    """Salin dengan waktu modifikasi dipertahankan; tulis ke file sementara lalu replace."""
    dest = Path(dest)
    tmp = dest.with_name("." + dest.name + ".zeno.tmp")
    try:
        shutil.copy2(src, tmp)
        os.replace(tmp, dest)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def write_versions(cfg):
    ensure_dirs()
    rows = [f"{k}={vtext(fi)}" for k, fi in sorted(list_app_copies(cfg).items())]
    VERSIONS_TXT.write_text("# Zeno Lite - DOM/BTRV model xml (versi di aplikasi)\n" + "\n".join(rows) + "\n", encoding="utf-8")


# ------------------------------------------------------------------ terapkan
@dataclass
class ApplyResult:
    key: str
    rows: list = field(default_factory=list)        # (level, teks)
    pushed: list = field(default_factory=list)
    failed: list = field(default_factory=list)
    app_changed: bool = False
    from_version: str = ""
    to_version: str = ""
    backup_name: str = ""

    def add(self, level, text):
        self.rows.append((level, text))


def spec_path(key, spec, cfg):
    """Path file untuk sebuah sumber: app | upload | server:<folder> | backup:<file atau nomor>. None bila tidak ada."""
    if spec == SpecAPP:
        p = app_copy_path(key, cfg)
        return p if p.exists() else None
    if spec == SpecUPLOAD:
        ups = [fi for fi in (inspect(p) for p in new_files()) if fi.readable and fi.key == key]
        ups.sort(key=lambda x: x.version, reverse=True)
        return ups[0].path if ups else None
    if spec.startswith("server:"):
        f = spec.split(":", 1)[1]
        if not re.fullmatch(r"[A-Za-z0-9_-]+", f):
            return None
        p = Path(cfg["model_server"]) / f / cfg["model_file"]
        return p if p.exists() else None
    if spec.startswith("backup:"):
        ref = spec.split(":", 1)[1]
        bks = list_backups(key)
        if ref.isdigit() and 1 <= int(ref) <= len(bks):
            return bks[int(ref) - 1].path
        return next((b.path for b in bks if b.filename == ref), None)
    return None


def source_for(kp, spec, cfg):
    """Cari sumber di rencana; spec 'backup:<file>' dibuat dari folder backup."""
    s = kp.source(spec)
    if s is not None:
        return s
    if spec.startswith("backup:"):
        fn = spec.split(":", 1)[1]
        b = next((b for b in list_backups(kp.key) if b.filename == fn), None)
        if b:
            return Source(spec, f"Backup {b.version}", inspect(b.path))
    return None


def apply_key(kp, spec, cfg, create=(), source=None):
    """
    Jadikan sumber `spec` sebagai sumber kebenaran: aplikasi = sumber, semua folder server yang beda = sumber.
    create: nama folder server yang boleh dibuat bila belum ada.
    """
    res = ApplyResult(kp.key)
    src = source or source_for(kp, spec, cfg)
    if src is None or not src.info.readable:
        res.add("err", f"{kp.key}: sumber '{spec}' tidak ditemukan / tidak terbaca.")
        return res
    ensure_dirs()
    app = kp.source(SpecAPP)
    res.from_version = vtext(app.info) if app else "(belum ada)"
    res.to_version = src.vtext
    src_path = src.info.path
    chosen_backup = Path(src_path) if spec.startswith("backup:") else None

    # 1) aplikasi
    if spec != SpecAPP and (app is None or app.info.norm != src.info.norm):
        try:
            bk = _backup_app_copy(kp.key, cfg) if app else None
            (EXISTING_DIR / kp.key).mkdir(parents=True, exist_ok=True)
            _copy_atomic(src_path, app_copy_path(kp.key, cfg))
            res.app_changed = True
            res.backup_name = bk.name if bk else ""
            res.add("ok", f"Aplikasi {kp.key}: {res.from_version} -> {res.to_version}"
                          + (" (versi lama disimpan ke backup)" if bk else ""))
        except Exception as e:
            res.add("err", f"Aplikasi {kp.key}: gagal memperbarui - {type(e).__name__}: {e}. Server tidak disentuh.")
            return res
    if chosen_backup is not None:                      # tukar: backup terpilih sudah jadi salinan aplikasi
        chosen_backup.unlink(missing_ok=True)
    _prune_backups(kp.key, cfg)

    # 2) server
    root = Path(cfg["model_server"])
    app_now = app_copy_path(kp.key, cfg)
    send_from = app_now if app_now.exists() else src_path
    dest_names = list(kp.targets) + [f for f in kp.missing if f in set(create)]
    for f in kp.missing:
        if f not in set(create):
            res.add("warn", f"Folder server {f} belum ada - dilewati (centang 'buat folder' bila memang baru).")
    for f in dest_names:
        d = root / f
        cur = d / cfg["model_file"]
        try:
            d.mkdir(parents=True, exist_ok=True)
            if cur.exists():
                cur_info = inspect(cur)
                if cur_info.norm == src.info.norm:
                    continue
                arc = d / "Archive"
                arc.mkdir(exist_ok=True)
                stem, suf = os.path.splitext(cfg["model_file"])
                dest_arc = arc / f"{stem}_{cur_info.version_raw or 'vX'}_{_ts()}{suf}"
                n = 1
                while dest_arc.exists():
                    dest_arc = arc / f"{stem}_{cur_info.version_raw or 'vX'}_{_ts()}_{n}{suf}"
                    n += 1
                shutil.move(str(cur), str(dest_arc))
                archived = dest_arc
            else:
                archived = None
            try:
                _copy_atomic(send_from, cur)
            except Exception:
                if archived is not None and not cur.exists():
                    shutil.move(str(archived), str(cur))       # kembalikan file lama
                raise
            res.pushed.append(f)
            res.add("ok", f"Server {f}: {src.vtext} terpasang" + (f" (file lama -> {f}\\Archive\\{archived.name})" if archived else " (file baru)"))
        except PermissionError:
            res.failed.append((f, "akses ditolak / file sedang dipakai"))
            res.add("err", f"Server {f}: akses ditolak atau file sedang dipakai - tidak diubah.")
        except Exception as e:
            res.failed.append((f, str(e)))
            res.add("err", f"Server {f}: gagal - {type(e).__name__}: {e}")
    if not res.pushed and not res.failed and not res.app_changed:
        res.add("info", f"{kp.key}: tidak ada yang perlu diubah.")
    write_versions(cfg)
    return res


def finish_uploads(kp, chosen_norm, applied_from_upload):
    """Pindahkan upload yang sudah terpakai (atau identik dengan hasil akhir) ke processed."""
    ensure_dirs()
    moved = []
    for fi in kp.upload_files:
        if applied_from_upload or fi.norm == chosen_norm:
            if fi.path.exists():
                dest, n = PROCESSED_DIR / f"{_ts()}__{fi.path.name}", 1
                while dest.exists():
                    dest = PROCESSED_DIR / f"{_ts()}_{n}__{fi.path.name}"
                    n += 1
                shutil.move(str(fi.path), str(dest))
                moved.append(fi.path.name)
    files = sorted(PROCESSED_DIR.glob("*__*"), key=lambda x: x.name, reverse=True)
    for old in files[KEEP_PROCESSED:]:
        old.unlink(missing_ok=True)
    return moved
