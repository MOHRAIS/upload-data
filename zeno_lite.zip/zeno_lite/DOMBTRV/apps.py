from django.apps import AppConfig


class DombtrvConfig(AppConfig):
    name = "DOMBTRV"
    label = "dombtrv"
    verbose_name = "DOM/BTRV"
    default_auto_field = "django.db.models.BigAutoField"
