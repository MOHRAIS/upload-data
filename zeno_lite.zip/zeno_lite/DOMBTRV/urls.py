from django.urls import path

from . import emergencyviews, modelviews, views

app_name = "dombtrv"

urlpatterns = [
    path("", views.index, name="index"),
    path("data/", views.data, name="data"),
    path("detail/<int:pk>/", views.detail, name="detail"),
    path("scan/", views.scan, name="scan"),
    path("status/", views.status, name="status"),
    path("model/", modelviews.model_index, name="model"),
    path("model/upload/", modelviews.model_upload, name="model_upload"),
    path("model/rencana/", modelviews.model_plan, name="model_plan"),
    path("model/rollback/", modelviews.model_rollback, name="model_rollback"),
    path("model/diff/", modelviews.model_diff, name="model_diff"),
    path("emergency/", emergencyviews.emergency_page, name="emergency"),
    path("emergency/buat/", emergencyviews.emergency_buat, name="emergency_buat"),
    path("emergency/gambar/", emergencyviews.emergency_gambar, name="emergency_gambar"),
    path("emergency/lihat/", emergencyviews.emergency_lihat, name="emergency_lihat"),
    path("emergency/riwayat/", emergencyviews.emergency_riwayat, name="emergency_riwayat"),
]
