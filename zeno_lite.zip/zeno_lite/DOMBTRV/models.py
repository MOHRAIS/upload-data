from django.db import models


class AddOnPart(models.Model):
    """Satu file xml <AddOnPart> di folder sumber (cermin dari hasil scan)."""
    path = models.CharField("Path relatif", max_length=700, unique=True)
    file_name = models.CharField(max_length=250, db_index=True)
    file_size = models.BigIntegerField(default=0)
    file_mtime_ns = models.BigIntegerField(default=0)
    file_mtime = models.DateTimeField(null=True, blank=True)

    vin = models.CharField(max_length=30, blank=True, db_index=True)
    vehicle_no = models.CharField(max_length=30, blank=True, db_index=True)
    model_code = models.CharField(max_length=20, blank=True, db_index=True)
    part_name = models.CharField(max_length=120, blank=True, db_index=True)
    part_class = models.CharField(max_length=20, blank=True, db_index=True)
    hostname = models.CharField(max_length=120, blank=True, db_index=True)
    part_no = models.CharField(max_length=80, blank=True, db_index=True)
    serial_no = models.CharField(max_length=80, blank=True, db_index=True)
    ts = models.DateTimeField("Timestamp", null=True, blank=True, db_index=True)
    descriptors = models.TextField(blank=True, default="[]")      # JSON: [{type,value,scannedValue,code}]

    parse_ver = models.IntegerField(default=0)                  # versi aturan baca XML saat file ini dibaca
    ok = models.BooleanField(default=True, db_index=True)
    error = models.CharField(max_length=300, blank=True)
    search_text = models.TextField(blank=True, editable=False)
    first_seen = models.DateTimeField(auto_now_add=True)
    scanned_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-ts"]
        verbose_name = "File AddOnPart"
        verbose_name_plural = "File AddOnPart"

    def __str__(self):
        return self.path


class ScanState(models.Model):
    """Keadaan scan terakhir / yang sedang berjalan (satu baris, key='scan')."""
    key = models.CharField(max_length=20, unique=True, default="scan")
    status = models.CharField(max_length=20, blank=True)      # berjalan | ok | gagal | ditahan
    folder = models.CharField(max_length=300, blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    oleh = models.CharField(max_length=60, blank=True)
    files_total = models.IntegerField(default=0)
    files_new = models.IntegerField(default=0)
    files_changed = models.IntegerField(default=0)
    files_removed = models.IntegerField(default=0)
    files_error = models.IntegerField(default=0)
    progress_done = models.IntegerField(default=0)
    message = models.TextField(blank=True)


class ScanLog(models.Model):
    waktu = models.DateTimeField(auto_now_add=True)
    oleh = models.CharField(max_length=60, blank=True)
    status = models.CharField(max_length=20)
    durasi = models.FloatField(default=0)
    total = models.IntegerField(default=0)
    baru = models.IntegerField(default=0)
    diubah = models.IntegerField(default=0)
    dihapus = models.IntegerField(default=0)
    error = models.IntegerField(default=0)
    pesan = models.TextField(blank=True)

    class Meta:
        ordering = ["-waktu", "-id"]


# ------------------------------------------------------------------ update model xml ke server
class ModelCopy(models.Model):
    """Salinan model xml yang dipegang aplikasi (satu per model, mis. G05 / G2X)."""
    key = models.CharField("Model", max_length=20, unique=True)
    version = models.CharField(max_length=20, blank=True)
    filename = models.CharField(max_length=120, blank=True)
    norm_hash = models.CharField(max_length=64, blank=True)
    size = models.BigIntegerField(default=0)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["key"]
        verbose_name = "Model di aplikasi"
        verbose_name_plural = "Model di aplikasi"


class ModelServer(models.Model):
    """Keadaan file model di tiap folder server pada pengecekan terakhir."""
    folder = models.CharField(max_length=40, unique=True)
    key = models.CharField(max_length=20, blank=True)
    version = models.CharField(max_length=20, blank=True)
    norm_hash = models.CharField(max_length=64, blank=True)
    file_exists = models.BooleanField(default=False)
    status = models.CharField(max_length=40, blank=True)
    note = models.CharField(max_length=300, blank=True)
    checked_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["folder"]
        verbose_name = "Model di server"
        verbose_name_plural = "Model di server"


class ModelLog(models.Model):
    waktu = models.DateTimeField(auto_now_add=True)
    oleh = models.CharField(max_length=60, blank=True)
    aksi = models.CharField(max_length=20)          # UPLOAD | TARIK | DORONG | ROLLBACK
    key = models.CharField(max_length=20, blank=True)
    dari_versi = models.CharField(max_length=20, blank=True)
    ke_versi = models.CharField(max_length=20, blank=True)
    folders = models.CharField(max_length=200, blank=True)
    status = models.CharField(max_length=10, default="ok")
    pesan = models.TextField(blank=True)

    class Meta:
        ordering = ["-waktu", "-id"]


# ------------------------------------------------------------------ Emergency Barcode
class EmergencyLog(models.Model):
    """Riwayat pembuatan barcode Emergency (web dan batch)."""
    waktu = models.DateTimeField("Dibuat", auto_now_add=True, db_index=True)
    oleh = models.CharField(max_length=60, blank=True)
    sumber = models.CharField(max_length=10, default="WEB")        # WEB | BATCH
    kode = models.CharField("Kode 11 karakter", max_length=11, db_index=True)
    identifier = models.CharField(max_length=2, blank=True)
    jenis = models.CharField(max_length=200, blank=True)
    pola = models.CharField("Panjang", max_length=12)               # mis. "23 (12)"
    nilai = models.CharField("Nilai DMC", max_length=120, db_index=True)
    waktu_dipakai = models.CharField(max_length=20, blank=True)    # waktu yang tertanam di nilai DMC
    mode = models.CharField(max_length=10, blank=True)             # sekarang | manual
    search_text = models.TextField(blank=True, editable=False)

    class Meta:
        ordering = ["-waktu", "-id"]
        verbose_name = "Riwayat Emergency Barcode"
        verbose_name_plural = "Riwayat Emergency Barcode"

    def __str__(self):
        return f"{self.kode} {self.pola}"
