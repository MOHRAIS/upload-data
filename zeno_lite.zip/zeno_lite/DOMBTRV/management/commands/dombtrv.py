"""
python manage.py dombtrv cari [kata...] [--part X --hostname X --model X --kelas X --dari YYYY-MM-DD --sampai YYYY-MM-DD --limit N]
python manage.py dombtrv pilihan [kata...] [filter...]   (daftar pilihan filter yang masih tersisa)
python manage.py dombtrv status
python manage.py dombtrv scan [--quiet] [--force] [--allow-mass-delete]

Update model XML ke server:
python manage.py dombtrv model [--yes]            (cek server + upload, tampilkan perbedaan, konfirmasi, terapkan)
python manage.py dombtrv modelstatus              (keadaan aplikasi vs server)
python manage.py dombtrv modelrollback            (pilih model + versi backup)
python manage.py dombtrv modeldiff G05 server:G05 upload [--semua]   (spec: app | upload | server:<folder> | backup:<no>)

Emergency Barcode (nilai DMC dummy + Data Matrix):
python manage.py dombtrv emergency 22ABC1234XY [--pola "23 (12)"] [--tanggal 2026-11-15 --jam 08:30:00] [--teks] [--tanpa-html]
python manage.py dombtrv emergencyriwayat [kata] [--limit 20]        (riwayat pembuatan barcode: kapan, siapa, kode, nilai)   (untuk Task Scheduler / manual)

cari / pilihan / status HANYA membaca database hasil scan terakhir (tidak scan ulang).
"""
from django.core.management.base import BaseCommand

from DOMBTRV import core, datamatrix, emergency as em, emergencysvc, modelcore as mc, modelsvc, services

OLEH = "BATCH"


class Command(BaseCommand):
    help = "DOM/BTRV: cari data hasil scan, scan folder xml"

    def add_arguments(self, parser):
        parser.add_argument("aksi", choices=["cari", "pilihan", "status", "scan", "model", "modelstatus", "modelrollback", "modeldiff", "emergency", "emergencyriwayat"])
        parser.add_argument("kata", nargs="*")
        parser.add_argument("--part", default="")
        parser.add_argument("--hostname", default="")
        parser.add_argument("--model", default="")
        parser.add_argument("--kelas", default="")
        parser.add_argument("--dari", default="", help="tanggal awal YYYY-MM-DD")
        parser.add_argument("--sampai", default="", help="tanggal akhir YYYY-MM-DD")
        parser.add_argument("--limit", type=int, default=30)
        parser.add_argument("--quiet", action="store_true")
        parser.add_argument("--allow-mass-delete", action="store_true")
        parser.add_argument("--force", action="store_true", help="baca ulang SEMUA file xml")
        parser.add_argument("--yes", "-y", action="store_true", help="model: terapkan rekomendasi tanpa bertanya (konflik tetap ditanya)")
        parser.add_argument("--semua", action="store_true", help="modeldiff: tampilkan semua perbedaan")
        parser.add_argument("--tanggal", default="", help="emergency: tanggal YYYY-MM-DD (kosong = sekarang)")
        parser.add_argument("--jam", default="", help="emergency: jam HH:MM:SS (kosong = sekarang)")
        parser.add_argument("--pola", default="", help="emergency: panjang yang dipilih, mis. '23 (12)', 23, atau nomor urut 1-9 (kosong = ditanya)")
        parser.add_argument("--teks", action="store_true", help="emergency: gambar barcode sebagai teks di layar")
        parser.add_argument("--tanpa-html", action="store_true", help="emergency: jangan simpan file barcode (html)")

    def handle(self, *a, **o):
        core.ensure_ini()
        getattr(self, "do_" + o["aksi"])(o)

    def say(self, text="", style=None):
        self.stdout.write(getattr(self.style, style)(text) if style else text)

    def params(self, o):
        return {"q": " ".join(o["kata"]), "part_name": o["part"], "hostname": o["hostname"],
                "model_code": o["model"], "part_class": o["kelas"],
                "dari": o["dari"], "sampai": o["sampai"]}

    def header(self):
        """Selalu beri tahu kapan terakhir scan (batch tidak men-scan, hanya membaca database)."""
        i = services.status_info()
        if i["state"].status == "berjalan":
            self.say(f"[Scan sedang berjalan] {i['state'].message}", "WARNING")
        if i["last_scan"]:
            txt = f"Data dari scan terakhir: {i['last_scan']} ({i['age_text']}) - {i['total']} file XML valid di database"
            self.say(txt, "WARNING" if i["stale"] else "SUCCESS")
            if i["stale"]:
                self.say(f"  Sudah lewat jadwal {i['cfg']['interval_jam']:g} jam. Scan ulang lewat aplikasi atau scan_terjadwal.bat.", "WARNING")
        else:
            self.say("Belum pernah scan. Scan dulu lewat aplikasi (tombol Scan) atau scan_terjadwal.bat.", "WARNING")

    # ------------------------------------------------------------------
    def do_status(self, o):
        i = services.status_info()
        c, st = i["cfg"], i["state"]
        self.say(f"Folder sumber : {c['folder']}  (pola {c['pola']}, subfolder: {str(c['rekursif']).lower()}, hapus_hilang: {str(c['hapus_hilang']).lower()})")
        self.say(f"Jadwal scan   : setiap {c['interval_jam']:g} jam (Task Scheduler, atau tombol di aplikasi)")
        self.header()
        self.say(f"XML rusak/tidak valid (tidak ditampilkan di pencarian): {i['errors']}")
        if st.message:
            self.say(f"Hasil scan terakhir : {st.message}")

    def do_scan(self, o):
        res = services.start_scan(OLEH, background=False, allow_mass_delete=o["allow_mass_delete"], force=o["force"])
        style = {"success": "SUCCESS", "info": None, "warning": "WARNING", "error": "ERROR"}[res.level]
        self.say(("[DOM/BTRV] " if o["quiet"] else "") + res.message, style)
        if res.status == "ditahan":
            self.say("Untuk menyetujui: manage.bat dombtrv scan --allow-mass-delete", "WARNING")

    def do_cari(self, o):
        self.header()
        qs = services.search(self.params(o))
        total = qs.count()
        desc = " ".join(o["kata"]) or "(semua)"
        self.say(f"\nCari '{desc}': {total} hasil" + (f" (ditampilkan {o['limit']} teratas)" if total > o["limit"] else ""), "MIGRATE_HEADING")
        if not total:
            return
        self.say(f"{'Timestamp':20}{'VIN':19}{'Mdl':5}{'Part':22}{'PartNo':14}{'SerialNo':14}{'Hostname'}")
        for r in qs[:o["limit"]]:
            self.say(f"{services.fmt_dt(r.ts):20}{r.vin:19}{r.model_code:5}{r.part_name[:21]:22}{r.part_no:14}{r.serial_no:14}{r.hostname}")

    def do_pilihan(self, o):
        self.header()
        fc = services.facets(self.params(o))
        names = {"part_name": "Part (--part)", "hostname": "Hostname (--hostname)", "model_code": "Model (--model)",
                 "part_class": "Kelas (--kelas)"}
        self.say("\nPilihan filter yang masih tersisa" + (f" untuk '{' '.join(o['kata'])}'" if o["kata"] else "") + ":", "MIGRATE_HEADING")
        for k, items in fc.items():
            self.say(f"\n  {names[k]}")
            for v, n in items:
                self.say(f"    {v:32} {n}")


    # ================================================================== update model XML
    def _ask(self, prompt):
        try:
            return input(prompt).strip()
        except EOFError:
            return ""

    def do_modelstatus(self, o):
        cfg = core.read_config()
        plan = modelsvc.check()
        self.say(f"Server  : {cfg['model_server']}   (file: {cfg['model_file']})", None)
        for w in plan.warnings:
            self.say(f"  ! {w}", "WARNING")
        copies = mc.list_app_copies(cfg)
        self.say("\nMODEL DI APLIKASI", "MIGRATE_HEADING")
        for k, fi in copies.items():
            self.say(f"  {k:8} {mc.vtext(fi)}")
        if not copies:
            self.say("  (belum ada)")
        if plan.server_ok:
            self.say("\nKEADAAN DI SERVER", "MIGRATE_HEADING")
            self.say(f"  {'Folder':8}{'Header':8}{'Versi':10}Status")
            for f, fi in plan.server.items():
                st = modelsvc.server_status(fi, copies)
                self.say(f"  {f:8}{fi.key or '-':8}{mc.vtext(fi) if fi.exists else '-':10}{st}",
                         None if st in ("sama", "tidak ada file") else "WARNING")
        pend = mc.new_files()
        self.say(f"\nFile menunggu di modeldata\\new: {len(pend)}" + "".join(f"\n  - {p.name}" for p in pend))
        self.say(f"Backup aplikasi: {len(mc.list_backups())}")

    def do_model(self, o):
        cfg = core.read_config()
        plan = modelsvc.check()
        for w in plan.warnings:
            self.say(f"  ! {w}", "WARNING")
        if not plan.server_ok:
            return self.say("Rencana tidak dibuat: server tidak terjangkau. Tidak ada yang diubah.", "ERROR")
        rows = modelsvc.plan_rows(plan, cfg)
        if not rows:
            return self.say("Tidak ada model yang ditemukan (belum ada upload, salinan aplikasi, atau file di server).")
        sels, label = [], {"tindakan": "PERLU TINDAKAN", "konflik": "KONFLIK", "error": "TIDAK TERBACA", "sama": "sudah sama"}
        todo = [r for r in rows if r["selectable"]]
        self.say(f"\n{len(rows)} model diperiksa, {len(todo)} perlu keputusan.", "MIGRATE_HEADING")
        for r in rows:
            if not r["selectable"]:
                vers = ", ".join(f"{s['label']} {s['version']}" for s in r["sources"])
                self.say(f"  {r['key']:8} {label[r['status']]:16} {vers}")
        for n, r in enumerate(todo, 1):
            kp = r["kp"]
            self.say(f"\n[{n}/{len(todo)}] {r['key']}  -  {label[r['status']]}", "ERROR" if r["status"] == "konflik" else "WARNING")
            self.say(f"   {r['reason']}")
            for note in r["notes"]:
                self.say(f"   ! {note}", "WARNING")
            for i, s in enumerate(r["sources"], 1):
                tag = "  <- rekomendasi" if s["rec"] else ""
                extra = "" if not s["sum"] else ("   (isi sama dengan rekomendasi)" if s["sum"]["same"] else f"   [{s['sum']['text']}]")
                self.say(f"   [{i}] {s['label']:14} {s['version']:9}{tag}{extra}")
            self.say("   [0] Lewati")
            rec_idx = next((i for i, s in enumerate(r["sources"], 1) if s["rec"]), None)
            if rec_idx and r["what"]:
                self.say("   Bila memilih rekomendasi: " + "; ".join(r["what"]))
            self.say(f"   (perbedaan lengkap: manage.bat dombtrv modeldiff {r['key']} <a> <b>)")
            if o["yes"] and rec_idx:
                choice = rec_idx
            elif o["yes"]:
                self.say("   Konflik: harus dipilih manual, dilewati karena --yes.", "WARNING")
                choice = 0
            else:
                prompt = f"   Pilih [Enter = {rec_idx}]: " if rec_idx else "   Pilih nomor: "
                raw = self._ask(prompt)
                choice = rec_idx if (raw == "" and rec_idx) else (int(raw) if raw.isdigit() else 0)
            if choice < 1 or choice > len(r["sources"]):
                sels.append({"key": r["key"], "spec": "lewati", "token": r["token"]})
                continue
            src = r["sources"][choice - 1]
            yakin = True
            if r["recommended"] and src["spec"] != r["recommended"]:
                self.say(f"   PERHATIAN: '{src['label']} {src['version']}' MENYIMPANG dari aturan versi.", "ERROR")
                yakin = self._ask("   Ketik YA untuk melanjutkan: ").upper() == "YA"
                if not yakin:
                    sels.append({"key": r["key"], "spec": "lewati", "token": r["token"]})
                    continue
            create = set()
            for f in r["missing"]:
                if not o["yes"] and self._ask(f"   Folder server '{f}' belum ada. Buat? [y/N] ").lower() in ("y", "ya"):
                    create.add(f)
            sels.append({"key": r["key"], "spec": src["spec"], "token": r["token"], "yakin": yakin, "create": create})
        if not any(s["spec"] != "lewati" for s in sels):
            return self.say("\nTidak ada yang diterapkan.")
        rep = modelsvc.apply(sels, OLEH)
        self.say("\n== Hasil ==", "MIGRATE_HEADING")
        style = {"ok": "SUCCESS", "warn": "WARNING", "err": "ERROR", "info": None}
        for level, text in rep.rows:
            self.say(f"  [{level.upper():4}] {text}", style[level])

    def do_modelrollback(self, o):
        cfg = core.read_config()
        keys = mc.backup_keys()
        if not keys:
            return self.say("Belum ada backup untuk di-rollback.", "WARNING")
        apps = mc.list_app_copies(cfg)
        self.say("PILIH MODEL YANG AKAN DI-ROLLBACK", "MIGRATE_HEADING")
        for i, k in enumerate(keys, 1):
            self.say(f"  [{i}] {k}  (di aplikasi: {mc.vtext(apps.get(k)) if k in apps else '-'}, backup: {len(mc.list_backups(k))})")
        raw = self._ask("Nomor model (kosong = batal): ")
        if not (raw.isdigit() and 1 <= int(raw) <= len(keys)):
            return self.say("Dibatalkan.")
        key = keys[int(raw) - 1]
        bks = mc.list_backups(key)
        self.say(f"\nBackup {key} (terbaru di atas):", "MIGRATE_HEADING")
        for i, b in enumerate(bks, 1):
            self.say(f"  [{i}] versi {b.version}   disimpan {b.waktu}")
        raw = self._ask("Nomor versi tujuan (kosong = batal): ")
        if not (raw.isdigit() and 1 <= int(raw) <= len(bks)):
            return self.say("Dibatalkan.")
        b = bks[int(raw) - 1]
        self.say("Rollback akan MENDORONG versi ini ke server (file server sekarang dipindah ke Archive).", "WARNING")
        if self._ask(f"Rollback {key} ke {b.version}? Ketik YA: ").upper() != "YA":
            return self.say("Dibatalkan.")
        rep = modelsvc.rollback(key, b.filename, set(), OLEH)
        for level, text in rep.rows:
            self.say(f"  [{level.upper():4}] {text}")

    def do_modeldiff(self, o):
        if len(o["kata"]) < 3:
            return self.say("Pemakaian: modeldiff <model> <a> <b>   (a/b: app | upload | server:<folder> | backup:<no>)", "WARNING")
        cfg = core.read_config()
        key, a, b = o["kata"][:3]
        pa, pb = mc.spec_path(key, a, cfg), mc.spec_path(key, b, cfg)
        if not pa or not pb:
            return self.say(f"File tidak ditemukan: {'a' if not pa else 'b'} ({a if not pa else b})", "ERROR")
        d = mc.diff_hunks(pa, pb, max_rows=100000 if o["semua"] else 400)
        self.say(f"KIRI  ({a}) : {mc.vtext(mc.inspect(pa))}  {pa}")
        self.say(f"KANAN ({b}) : {mc.vtext(mc.inspect(pb))}  {pb}")
        self.say(mc.diff_summary_text(d["summary"]) + "\n", "WARNING" if d["summary"]["total"] else "SUCCESS")
        shown = 0
        for h in d["hunks"]:
            self.say("   ...")
            for r in h:
                if r["t"] == "eq":
                    self.say(f"   {r['a']:>5}   {r['ta'][:110]}")
                else:
                    if r["ta"] or r["t"] in ("del", "chg"):
                        self.say(f"  -{r['a'] if r['a'] else '':>5}   {r['ta'][:110]}", "ERROR")
                    if r["tb"] or r["t"] in ("add", "chg"):
                        self.say(f"  +{r['b'] if r['b'] else '':>5}   {r['tb'][:110]}", "SUCCESS")
                shown += 1
        if d["truncated"] or (not o["semua"] and shown >= 400):
            self.say("\n(dipotong; tambahkan --semua untuk semua perbedaan)", "WARNING")


    # ================================================================== Emergency Barcode
    def _pilih_pola(self, o):
        """--pola, atau tanya dari daftar nomor 1-9."""
        if o["pola"]:
            return em.resolve_pattern(o["pola"])
        self.say("\nPILIH PANJANG NILAI DMC", "MIGRATE_HEADING")
        for p in em.patterns_info():
            self.say(f"  [{p['no']}] {p['label']:9} {p['format']}")
        raw = self._ask("Nomor panjang (1-9): ")
        if not raw:
            raise em.InputError("Panjang belum dipilih. Pakai --pola \"23 (12)\" atau pilih nomor 1-9.")
        return em.resolve_pattern(raw)

    def do_emergency(self, o):
        raw = o["kata"][0] if o["kata"] else ""
        try:
            code = em.normalize_code(raw)
            when, auto = em.parse_when(o["tanggal"], o["jam"])
            pola = self._pilih_pola(o)
            item = em.generate_one(code, when, pola)
        except em.InputError as e:
            return self.say(f"ERROR: {e}", "ERROR")
        ident, name = em.identifier_info(code)
        mode = "sekarang" if auto else "manual"
        self.say("\nEMERGENCY BARCODE", "MIGRATE_HEADING")
        self.say(f"Kode            : {code}   (Identifier {code[:2]} + Partnumber {code[2:9]} + Change index {code[9:]})")
        if name:
            self.say(f"Jenis part      : {name}")
        else:
            self.say(f"Jenis part      : Identifier {ident} TIDAK ADA di emergency\\identifiers.csv (nilai tetap dibuat)", "WARNING")
        self.say(f"Panjang         : {item['label']}  ({len(item['value'])} karakter)")
        self.say(f"Waktu dalam nilai: {when.strftime('%d.%m.%Y %H:%M:%S')}  ({'sekarang' if auto else 'diatur sendiri'})\n")
        self.say(f"  NILAI DMC  :  {item['value']}\n", "SUCCESS")
        if o["teks"]:
            m, _ = datamatrix.encode(item["value"])
            self.say(datamatrix.to_text(m) + f"\n(Data Matrix {len(m)}x{len(m)})\n")
        try:
            import getpass
            try:
                who = getpass.getuser()
            except Exception:
                who = OLEH
            emergencysvc.catat(who, "BATCH", code, item, when, mode)
            self.say("Dicatat di riwayat.")
        except Exception as e:                      # nilai tetap tampil walau riwayat gagal tersimpan
            self.say(f"Riwayat tidak tersimpan: {type(e).__name__}: {e}", "WARNING")
        self.say(f"\nPENTING: tulis alasan pemakaian nilai dummy di kolom komentar ({em.REASON}).", "WARNING")
        self.say("Untuk mengisi komentar, nilai DMC harus dimasukkan dua kali.", "WARNING")
        if not o["tanpa_html"]:
            path = em.save_html(code, when, [item], "sekarang" if auto else "diatur sendiri")
            self.say(f"\nBarcode Data Matrix disimpan: {path}", "SUCCESS")
            self.say(f"(juga di {em.OUT_DIR / 'terakhir.html'} - buka dengan browser, bisa dicetak)")

    def do_emergencyriwayat(self, o):
        q = " ".join(o["kata"])
        d = emergencysvc.riwayat(q, 1, max(1, o["limit"]))
        self.say(f"RIWAYAT EMERGENCY BARCODE" + (f" - cari '{q}'" if q else "") + f"  ({d['total']} data, terbaru di atas)", "MIGRATE_HEADING")
        if not d["rows"]:
            return self.say("Belum ada barcode yang dibuat." if not q else "Tidak ada yang cocok.")
        self.say(f"{'Dibuat':20}{'Oleh':10}{'Kode':13}{'Panjang':9}{'Waktu dalam nilai':21}Nilai DMC")
        for r in d["rows"]:
            who = r["oleh"] + ("*" if r["sumber"] == "BATCH" else "")
            self.say(f"{r['waktu']:20}{who:10}{r['kode']:13}{r['pola']:9}{r['waktu_dipakai'] + ('^' if r['mode'] == 'manual' else ''):21}{r['nilai']}")
        self.say("\n(* = dibuat dari batch, ^ = tanggal/jam diatur sendiri)")
        if d["total"] > len(d["rows"]):
            self.say(f"Menampilkan {len(d['rows'])} terbaru; tambahkan --limit N atau kata pencarian.", "WARNING")
