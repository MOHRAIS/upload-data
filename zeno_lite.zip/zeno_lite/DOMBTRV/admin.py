from django.contrib import admin

from .models import AddOnPart, EmergencyLog, ModelCopy, ModelLog, ModelServer, ScanLog, ScanState


@admin.register(AddOnPart)
class AddOnPartAdmin(admin.ModelAdmin):
    list_display = ("vin", "part_name", "part_no", "serial_no", "hostname", "ts", "ok")
    search_fields = ("vin", "part_no", "serial_no", "file_name")
    list_filter = ("part_name", "hostname", "ok")
    readonly_fields = [f.name for f in AddOnPart._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


admin.site.register(ScanState)
admin.site.register(ScanLog)


admin.site.register(ModelCopy)
admin.site.register(ModelServer)
admin.site.register(ModelLog)


@admin.register(EmergencyLog)
class EmergencyLogAdmin(admin.ModelAdmin):
    list_display = ("waktu", "oleh", "sumber", "kode", "pola", "nilai")
    list_filter = ("sumber", "pola")
    search_fields = ("kode", "nilai", "oleh")
