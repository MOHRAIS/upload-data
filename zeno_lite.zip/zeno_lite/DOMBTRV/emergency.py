"""
DOM/BTRV - Emergency Barcode: nilai DMC dummy + barcode Data Matrix. Logika inti TANPA Django.

Sumber aturan: file "BTRV Dummy DMC 2026" (sheet "How to create DMC value" dan "DMC value generator").

Input : 11 karakter KAPITAL = Identifier (2) + Partnumber (7) + Change index (2)
Output: 9 pola nilai DMC dummy (panjang 18 sampai 63 karakter) berisi tahun, hari, jam, menit, detik.

Legenda: YY tahun 2 digit (2026 -> 26) | Y tahun 1 digit (2026 -> 6) | DDD hari ke-n dalam tahun
         HH jam 24 jam | MM menit | SS detik | S digit pertama detik | ! tanda nilai dummy
"""
import csv
import html
import re
import shutil
import time
from datetime import datetime
from pathlib import Path

from . import core, datamatrix

EMERGENCY_DIR = core.MODULE_DIR / "emergency"
IDENT_CSV = EMERGENCY_DIR / "identifiers.csv"
OUT_DIR = EMERGENCY_DIR / "hasil"
CODE_RE = re.compile(r"^[A-Z0-9]{11}$")
VALUE_RE = re.compile(r"^[A-Z0-9!]{1,170}$")
KEEP_OUTPUT = 30

REASON = "MISSING DMC / NOT READABLE DMC / DUPLICATED DMC"

# (label panjang total (panjang serial), jenis serial, jumlah nol di belakang)
#   S7  : ID PARTNUM CI + (Y ! HH MM SS) dipotong 7 karakter  -> Y!HHMMS
#   S9A : ID + 0000000 (pengganti PARTNUM/order number) + Y !! HH MM SS
#   S9B : ID PARTNUM CI + Y !! HH MM SS
#   S12 : ID PARTNUM CI + YY ! DDD HH MM SS
PATTERNS = [
    ("18 (7)", "S7", 0),
    ("18 (9)", "S9A", 0),
    ("20 (9)", "S9B", 0),
    ("23 (12)", "S12", 0),
    ("31 (12)", "S12", 8),
    ("57 (9)", "S9A", 39),
    ("59 (9)", "S9B", 39),
    ("60 (12)", "S12", 37),
    ("63 (9)", "S9B", 43),
]


# Keterangan singkat tiap pola (untuk pilihan panjang di web dan batch)
PATTERN_FORMATS = {
    "18 (7)": "ID PARTNUM CI + Y!HHMMS",
    "18 (9)": "ID + 0000000 + Y!!HHMMSS",
    "20 (9)": "ID PARTNUM CI + Y!!HHMMSS",
    "23 (12)": "ID PARTNUM CI + YY!DDDHHMMSS",
    "31 (12)": "pola 23 (12) + 8 nol",
    "57 (9)": "pola 18 (9) + 39 nol",
    "59 (9)": "pola 20 (9) + 39 nol",
    "60 (12)": "pola 23 (12) + 37 nol",
    "63 (9)": "pola 20 (9) + 43 nol",
}


class InputError(ValueError):
    pass


def patterns_info():
    return [{"no": n, "label": p[0], "total": int(p[0].split()[0]), "serial": int(p[0].split("(")[1].rstrip(")")),
             "format": PATTERN_FORMATS[p[0]]} for n, p in enumerate(PATTERNS, 1)]


def resolve_pattern(spec):
    """Label pola dari: label persis ('23 (12)' / '23(12)'), nomor urut 1-9, atau awalan yang tidak ambigu ('23')."""
    s = (spec or "").strip().replace(" ", "")
    if not s:
        raise InputError("Pilih panjang dulu (mis. 23 (12)).")
    labels = [p[0] for p in PATTERNS]
    for l in labels:
        if l.replace(" ", "") == s:
            return l
    if s.isdigit() and len(s) == 1 and 1 <= int(s) <= len(labels):
        return labels[int(s) - 1]
    hits = [l for l in labels if l.replace(" ", "").startswith(s)]
    if len(hits) == 1:
        return hits[0]
    if len(hits) > 1:
        raise InputError(f"'{spec}' ambigu: {', '.join(hits)}. Tulis lengkap, mis. {hits[0]}.")
    raise InputError(f"Panjang '{spec}' tidak dikenal. Pilihan: {', '.join(labels)}.")


# ------------------------------------------------------------------ input
def normalize_code(raw):
    code = (raw or "").strip().upper()
    if len(code) != 11:
        raise InputError(f"Harus tepat 11 karakter (sekarang {len(code)}): Identifier 2 + Partnumber 7 + Change index 2.")
    if not CODE_RE.match(code):
        raise InputError("Hanya huruf A-Z dan angka 0-9 yang boleh dipakai (tanpa spasi atau simbol).")
    return code


def parse_when(tgl="", jam=""):
    """Tanggal (YYYY-MM-DD atau DD.MM.YYYY) + jam (HH:MM[:SS]). Kosong semua = sekarang."""
    tgl, jam = (tgl or "").strip(), (jam or "").strip()
    if not tgl and not jam:
        return datetime.now().replace(microsecond=0), True
    now = datetime.now()
    try:
        if tgl:
            d = None
            for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d-%m-%Y", "%d/%m/%Y"):
                try:
                    d = datetime.strptime(tgl, fmt).date()
                    break
                except ValueError:
                    pass
            if d is None:
                raise ValueError
        else:
            d = now.date()
    except ValueError:
        raise InputError("Tanggal tidak valid. Pakai format YYYY-MM-DD (mis. 2026-11-15).")
    try:
        if jam:
            for fmt in ("%H:%M:%S", "%H:%M"):
                try:
                    t = datetime.strptime(jam, fmt).time()
                    break
                except ValueError:
                    t = None
            if t is None:
                raise ValueError
        else:
            t = now.time().replace(microsecond=0)
    except ValueError:
        raise InputError("Jam tidak valid. Pakai format HH:MM:SS (24 jam).")
    return datetime.combine(d, t), False


# ------------------------------------------------------------------ nilai DMC
def build_values(code, when):
    """Daftar pola: [{label, total, serial, value}] untuk kode 11 karakter dan waktu tertentu."""
    code = normalize_code(code)
    ident = code[:2]
    yy = f"{when.year % 100:02d}"
    y = yy[-1]
    ddd = f"{when.timetuple().tm_yday:03d}"
    hms = f"{when.hour:02d}{when.minute:02d}{when.second:02d}"
    out = []
    for label, kind, zeros in PATTERNS:
        if kind == "S7":
            v = code + (y + "!" + hms)[:7]
        elif kind == "S9A":
            v = ident + "0000000" + y + "!!" + hms
        elif kind == "S9B":
            v = code + y + "!!" + hms
        else:
            v = code + yy + "!" + ddd + hms
        v += "0" * zeros
        total = int(label.split()[0])
        serial = int(label.split("(")[1].rstrip(")"))
        assert len(v) == total, (label, len(v))
        out.append({"label": label, "total": total, "serial": serial, "value": v})
    return out


# ------------------------------------------------------------------ tabel identifier
DEFAULT_IDENT_HEADER = "Identifier;Attribute name\r\n"
_ident_cache = {"mtime": None, "data": {}}


def load_identifiers():
    """{IDENTIFIER_KAPITAL: nama atribut} dari emergency\\identifiers.csv (bisa diedit/ditambah)."""
    try:
        mt = IDENT_CSV.stat().st_mtime
    except OSError:
        return {}
    if _ident_cache["mtime"] == mt:
        return _ident_cache["data"]
    data = {}
    try:
        with open(IDENT_CSV, encoding="utf-8-sig", newline="") as fh:
            for i, row in enumerate(csv.reader(fh, delimiter=";")):
                if i == 0 or len(row) < 2 or not row[0].strip():
                    continue
                data.setdefault(row[0].strip().upper(), row[1].strip())
    except OSError:
        return {}
    _ident_cache.update(mtime=mt, data=data)
    return data


def identifier_info(code):
    """(identifier, nama atribut atau None)."""
    ident = code[:2].upper()
    return ident, load_identifiers().get(ident)


# ------------------------------------------------------------------ barcode
def barcode_for(value, scale=4):
    """{svg, size, codewords} untuk satu nilai DMC."""
    if not VALUE_RE.match(value or ""):
        raise InputError("Nilai hanya boleh huruf kapital, angka, dan '!'.")
    matrix, info = datamatrix.encode(value)
    return {"svg": datamatrix.to_svg(matrix, scale=scale, title="Data Matrix " + value),
            "size": info["size"], "matrix": matrix}


def generate_one(code, when, pola):
    """Satu pola yang dipilih, lengkap dengan barcode Data Matrix."""
    label = resolve_pattern(pola)
    item = next(i for i in build_values(code, when) if i["label"] == label)
    b = barcode_for(item["value"])
    item["svg"], item["size"] = b["svg"], b["size"]
    return item


def generate(code, when):
    """Semua pola lengkap dengan barcode Data Matrix."""
    items = build_values(code, when)
    for it in items:
        b = barcode_for(it["value"])
        it["svg"], it["size"] = b["svg"], b["size"]
    return items


# ------------------------------------------------------------------ file html (untuk batch)
_HTML = """<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8"><title>Emergency Barcode {code}</title>
<style>
  body {{ font-family: "Segoe UI", Arial, sans-serif; margin: 1.2rem; color:#111; }}
  h1 {{ font-size:1.3rem; margin:0 0 .3rem; }} .m {{ color:#555; font-size:.9rem; margin:.15rem 0; }}
  .warn {{ background:#fff4d6; border:1px solid #e5b400; padding:.5rem .8rem; border-radius:8px; margin:.8rem 0; font-size:.9rem; }}
  .grid {{ display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:.8rem; }}
  .c {{ border:1px solid #bbb; border-radius:10px; padding:.7rem; text-align:center; break-inside:avoid; }}
  .c b {{ display:block; font-size:1rem; }} .v {{ font-family:Consolas,monospace; font-size:.78rem; word-break:break-all; margin-top:.4rem; }}
  svg {{ width:170px; height:170px; }}
  @media print {{ body {{ margin:.4cm; }} .noprint {{ display:none; }} }}
</style></head><body>
<h1>Emergency Barcode &ndash; {code}</h1>
<div class="m">{ident_line}</div>
<div class="m">Waktu yang dipakai: <b>{when}</b> ({mode})</div>
<div class="warn"><b>Wajib:</b> alasan pemakaian nilai dummy harus ditulis di kolom komentar ({reason}). Untuk mengisi komentar, nilai DMC harus dimasukkan dua kali.</div>
<button class="noprint" onclick="window.print()">Cetak</button>
<div class="grid">
{cards}
</div></body></html>
"""


def build_html(code, when, items, mode):
    ident, name = identifier_info(code)
    ident_line = (f"Identifier <b>{html.escape(ident)}</b> &rarr; {html.escape(name)}" if name
                  else f"Identifier <b>{html.escape(ident)}</b>: <span style='color:#b00'>tidak ada di tabel identifiers.csv</span>")
    cards = "\n".join(
        f'<div class="c"><b>{html.escape(i["label"])}</b>{i["svg"]}<div class="v">{html.escape(i["value"])}</div>'
        f'<div class="m">{len(i["value"])} karakter &middot; Data Matrix {i["size"]}x{i["size"]}</div></div>' for i in items)
    return _HTML.format(code=html.escape(code), ident_line=ident_line, when=when.strftime("%d.%m.%Y %H:%M:%S"),
                        mode=mode, reason=REASON, cards=cards)


def save_html(code, when, items, mode):
    """Simpan ke emergency\\hasil (dan salin ke terakhir.html). Return path file."""
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    path = OUT_DIR / f"emergency_{code}_{time.strftime('%Y%m%d-%H%M%S')}.html"
    path.write_text(build_html(code, when, items, mode), encoding="utf-8")
    shutil.copyfile(path, OUT_DIR / "terakhir.html")
    olds = sorted(OUT_DIR.glob("emergency_*.html"), key=lambda p: p.name, reverse=True)
    for p in olds[KEEP_OUTPUT:]:
        p.unlink(missing_ok=True)
    return path
