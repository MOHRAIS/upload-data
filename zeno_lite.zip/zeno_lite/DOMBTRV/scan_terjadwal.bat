@echo off
rem Untuk Windows Task Scheduler (setiap 2 jam). Tidak interaktif.
rem Contoh membuat jadwal (jalankan sekali di Command Prompt):
rem   schtasks /create /tn "ZenoLite DOMBTRV scan" /sc hourly /mo 2 /tr "\"%~f0\""
cd /d "%~dp0.."
if not exist venv\Scripts\python.exe exit /b 1
venv\Scripts\python.exe general_sync.py --quiet >nul 2>&1
venv\Scripts\python.exe manage.py migrate >nul 2>&1
echo %date% %time% >> DOMBTRV\scan_terjadwal.log
venv\Scripts\python.exe manage.py dombtrv scan --quiet >> DOMBTRV\scan_terjadwal.log 2>&1
exit /b %errorlevel%
