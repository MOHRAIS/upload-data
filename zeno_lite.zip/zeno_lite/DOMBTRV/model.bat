@echo off
title DOM/BTRV - Update model XML
call "%~dp0_prep.bat"
if errorlevel 1 exit /b 1

:menu
cls
echo ==========================================
echo    DOM/BTRV - UPDATE MODEL XML KE SERVER
echo ==========================================
echo   Taruh file baru di DOMBTRV\modeldata\new
echo   (atau unggah lewat aplikasi), lalu pilih 1.
echo.
echo   [1] Cek server dan update (tampilkan perbedaan, minta konfirmasi)
echo   [2] Rollback (pilih model dan versi backup)
echo   [3] Bandingkan dua file (lihat perbedaan per baris)
echo   [4] Status aplikasi vs server
echo   [0] Keluar
echo.
choice /c 12340 /n /m "Pilih menu: "
if errorlevel 5 goto :eof
if errorlevel 4 (venv\Scripts\python.exe manage.py dombtrv modelstatus & goto :done)
if errorlevel 3 goto :diff
if errorlevel 2 (venv\Scripts\python.exe manage.py dombtrv modelrollback & goto :done)
if errorlevel 1 (venv\Scripts\python.exe manage.py dombtrv model & goto :done)
goto :menu

:diff
echo.
echo Pilihan sumber: app ^| upload ^| server:G05 ^| backup:1
set "K=" & set "A=" & set "B="
set /p "K=Model (mis. G05)      : "
set /p "A=Sumber kiri (a)       : "
set /p "B=Sumber kanan (b)      : "
if not defined K goto :menu
venv\Scripts\python.exe manage.py dombtrv modeldiff %K% %A% %B%
goto :done

:done
echo.
pause
goto :menu
