from pathlib import Path

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from . import core, modelcore as mc, modelsvc
from .models import ModelCopy, ModelLog, ModelServer


def _oleh(request):
    return getattr(request.user, "npk", "-")


def _busy(request, e):
    messages.error(request, str(e))
    return redirect("dombtrv:model")


@login_required
def model_index(request):
    core.ensure_ini()
    mc.ensure_dirs()
    servers = list(ModelServer.objects.all())
    checked = max((s.checked_at for s in servers if s.checked_at), default=None)
    pending = [dict(name=str(p.relative_to(mc.NEW_DIR)), size=p.stat().st_size) for p in mc.new_files()]
    return render(request, "dombtrv/model.html", {
        "cfg": core.read_config(), "copies": ModelCopy.objects.all(), "servers": servers,
        "checked": checked, "pending": pending, "logs": ModelLog.objects.all()[:15],
        "backups": len(mc.list_backups()), "active": "model"})


@login_required
@require_POST
def model_upload(request):
    mc.ensure_dirs()
    saved = 0
    for i, f in enumerate(request.FILES.getlist("files")):
        name = Path(f.name).name
        if not name.lower().endswith(".xml"):
            messages.error(request, f"{name}: hanya file .xml yang diterima.")
            continue
        # nama file model selalu sama -> beri awalan unik supaya upload tidak saling menimpa
        dest = mc.NEW_DIR / f"{mc._ts()}_{i}__{name}"
        with open(dest, "wb") as out:
            for chunk in f.chunks():
                out.write(chunk)
        saved += 1
    if not saved:
        messages.error(request, "Tidak ada file yang diunggah.")
        return redirect("dombtrv:model")
    messages.success(request, f"{saved} file disimpan. Periksa rencana di bawah lalu konfirmasi.")
    return redirect("dombtrv:model_plan")


@login_required
def model_plan(request):
    cfg = core.read_config()
    if request.method == "POST":
        sels = []
        for i in range(int(request.POST.get("n", 0) or 0)):
            key = request.POST.get(f"key_{i}", "")
            if not key:
                continue
            sels.append({"key": key, "spec": request.POST.get(f"pilih_{i}", "lewati"),
                         "token": request.POST.get(f"tok_{i}", ""), "yakin": request.POST.get(f"yakin_{i}") == "1",
                         "create": set(request.POST.getlist(f"buat_{i}"))})
        try:
            rep = modelsvc.apply(sels, _oleh(request))
        except core.BusyError as e:
            return _busy(request, e)
        return render(request, "dombtrv/model_hasil.html", {"rep": rep, "active": "model"})

    plan = modelsvc.check()
    return render(request, "dombtrv/model_plan.html", {
        "plan": plan, "rows": modelsvc.plan_rows(plan, cfg), "cfg": cfg, "active": "model"})


@login_required
def model_rollback(request):
    cfg = core.read_config()
    if request.method == "POST":
        key, fn = request.POST.get("key", ""), request.POST.get("backup", "")
        if not key or not fn:
            messages.error(request, "Pilih model dan versi backup.")
            return redirect("dombtrv:model_rollback")
        try:
            rep = modelsvc.rollback(key, fn, set(request.POST.getlist("buat")), _oleh(request))
        except core.BusyError as e:
            return _busy(request, e)
        return render(request, "dombtrv/model_hasil.html", {"rep": rep, "active": "model"})

    plan = mc.build_plan(cfg)
    groups = []
    for key in mc.backup_keys():
        kp = plan.item(key)
        app = mc.list_app_copies(cfg).get(key)
        groups.append({"key": key, "current": mc.vtext(app) if app else "-",
                       "backups": mc.list_backups(key),
                       "folder": (kp.targets[0] if kp and kp.targets else "")})
    return render(request, "dombtrv/model_rollback.html", {"groups": groups, "plan": plan, "active": "model"})


@login_required
def model_diff(request):
    cfg = core.read_config()
    key = request.GET.get("key", "")
    a, b = request.GET.get("a", ""), request.GET.get("b", "")
    pa, pb = mc.spec_path(key, a, cfg), mc.spec_path(key, b, cfg)
    if not pa or not pb:
        return JsonResponse({"error": "Salah satu file tidak ditemukan."}, status=404)
    d = mc.diff_hunks(pa, pb)
    d["a_name"], d["b_name"] = str(pa), str(pb)
    d["a_ver"], d["b_ver"] = mc.vtext(mc.inspect(pa)), mc.vtext(mc.inspect(pb))
    d["summary_text"] = mc.diff_summary_text(d["summary"])
    return JsonResponse(d)
