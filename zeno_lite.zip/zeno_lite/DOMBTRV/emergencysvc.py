"""Riwayat Emergency Barcode (database). Dipakai web dan batch."""
import math

from django.utils import timezone

from . import emergency as em
from .models import EmergencyLog


def fmt_dt(dt):
    if not dt:
        return "-"
    return timezone.localtime(dt).strftime("%d.%m.%Y %H:%M:%S")


def catat(oleh, sumber, code, item, when, mode):
    """Catat satu pembuatan barcode."""
    ident, name = em.identifier_info(code)
    text = " ".join([code, item["label"], item["value"], oleh or "", sumber, name or ""]).lower()
    return EmergencyLog.objects.create(
        oleh=(oleh or "-")[:60], sumber=sumber, kode=code, identifier=ident, jenis=(name or "")[:200],
        pola=item["label"], nilai=item["value"], waktu_dipakai=when.strftime("%d.%m.%Y %H:%M:%S"),
        mode=mode, search_text=text)


def row(o):
    return {"id": o.pk, "waktu": fmt_dt(o.waktu), "oleh": o.oleh, "sumber": o.sumber, "kode": o.kode,
            "identifier": o.identifier, "jenis": o.jenis, "pola": o.pola, "nilai": o.nilai,
            "waktu_dipakai": o.waktu_dipakai, "mode": o.mode}


def riwayat(q="", page=1, size=20):
    """Riwayat terbaru dulu. q: kata dicari (kode, nilai, NPK, jenis part, panjang)."""
    qs = EmergencyLog.objects.all()
    for tok in (q or "").lower().split():
        qs = qs.filter(search_text__contains=tok)
    qs = qs.order_by("-waktu", "-id")
    total = qs.count()
    pages = max(1, math.ceil(total / size))
    page = min(max(page, 1), pages)
    rows = [row(o) for o in qs[(page - 1) * size: page * size]]
    return {"total": total, "page": page, "pages": pages, "rows": rows,
            "start": (page - 1) * size + 1 if total else 0, "end": min(page * size, total)}
