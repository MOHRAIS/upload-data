from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.http import Http404, JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from . import core, services
from .models import ScanLog


def _oleh(request):
    return getattr(request.user, "npk", "-")


@login_required
def index(request):
    core.ensure_ini()
    info = services.status_info()
    return render(request, "dombtrv/index.html", {
        "info": info, "cfg": info["cfg"], "state": info["state"],
        "logs": ScanLog.objects.all()[:10], "broken": services.broken_files(), "active": "index"})


@login_required
def status(request):
    i = services.status_info()
    st = i["state"]
    return JsonResponse({
        "running": i["running"], "status": st.status, "message": st.message, "done": st.progress_done,
        "last_scan": i["last_scan"], "age_text": i["age_text"], "stale": i["stale"],
        "total": i["total"], "errors": i["errors"], "interval_jam": i["cfg"]["interval_jam"]})


@login_required
def data(request):
    try:
        qs = services.search(request.GET)
        try:
            size = min(max(int(request.GET.get("size", 50)), 10), 200)
            page = max(int(request.GET.get("page", 1)), 1)
        except ValueError:
            size, page = 50, 1
        pg = Paginator(qs, size)
        pobj = pg.get_page(page)
        return JsonResponse({
            "total": pg.count, "page": pobj.number, "pages": pg.num_pages,
            "start": pobj.start_index() if pg.count else 0, "end": pobj.end_index() if pg.count else 0,
            "rows": [services.row_dict(o) for o in pobj], "facets": services.facets(request.GET)})
    except (ValueError, TypeError):
        return JsonResponse({"error": "Filter tidak valid"}, status=400)


@login_required
def detail(request, pk):
    d = services.detail(pk)
    if d is None:
        raise Http404
    return JsonResponse(d)


@login_required
@require_POST
def scan(request):
    out = services.start_scan(_oleh(request), background=True,
                              allow_mass_delete=request.POST.get("mass") == "1",
                              force=request.POST.get("force") == "1")
    level = {"success": messages.SUCCESS, "info": messages.INFO, "warning": messages.WARNING,
             "error": messages.ERROR}[out.level]
    messages.add_message(request, level, out.message)
    return redirect("dombtrv:index")
