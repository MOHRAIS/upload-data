"""
Data Matrix ECC 200 (ISO/IEC 16022) - encoder murni Python, tanpa dependensi.

Cakupan: simbol PERSEGI 10x10 sampai 48x48, pengkodean ASCII (pasangan angka dipadatkan), satu blok
Reed-Solomon. Cukup untuk teks sampai ~170 karakter angka / ~170 karakter campuran ASCII.
Ukuran simbol dipilih otomatis (terkecil yang muat).
"""
import html
import struct
import zlib

# (sisi simbol, sisi area data per region, jumlah region per sisi, codeword data, codeword koreksi)
SIZES = [
    (10, 8, 1, 3, 5), (12, 10, 1, 5, 7), (14, 12, 1, 8, 10), (16, 14, 1, 12, 12), (18, 16, 1, 18, 14),
    (20, 18, 1, 22, 18), (22, 20, 1, 30, 20), (24, 22, 1, 36, 24), (26, 24, 1, 44, 28),
    (32, 14, 2, 62, 36), (36, 16, 2, 86, 42), (40, 18, 2, 114, 48), (44, 20, 2, 144, 56), (48, 22, 2, 174, 68),
]
MAX_DATA_CODEWORDS = SIZES[-1][3]


class DataMatrixError(ValueError):
    pass


# ------------------------------------------------------------------ GF(256), polinomial 0x12D
_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x12D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _gmul(a, b):
    return 0 if a == 0 or b == 0 else _EXP[_LOG[a] + _LOG[b]]


_gen_cache = {}


def _generator(n):
    """g(x) = (x - a^1)(x - a^2)...(x - a^n), koefisien dari pangkat tertinggi."""
    if n not in _gen_cache:
        g = [1]
        for i in range(1, n + 1):
            nxt = [0] * (len(g) + 1)
            for j, c in enumerate(g):
                nxt[j] ^= c
                nxt[j + 1] ^= _gmul(c, _EXP[i])
            g = nxt
        _gen_cache[n] = g
    return _gen_cache[n]


def reed_solomon(data, n):
    """n codeword koreksi (sisa pembagian data(x) * x^n oleh g(x))."""
    g = _generator(n)
    rem = [0] * n
    for d in data:
        factor = d ^ rem[0]
        rem = rem[1:] + [0]
        if factor:
            for i in range(n):
                rem[i] ^= _gmul(g[i + 1], factor)
    return rem


# ------------------------------------------------------------------ pengkodean ASCII
def ascii_codewords(text):
    cw, i = [], 0
    while i < len(text):
        c = text[i]
        if "0" <= c <= "9" and i + 1 < len(text) and "0" <= text[i + 1] <= "9":
            cw.append(130 + int(text[i:i + 2]))
            i += 2
            continue
        o = ord(c)
        if o > 127:
            raise DataMatrixError(f"Karakter '{c}' tidak didukung (hanya ASCII).")
        cw.append(o + 1)
        i += 1
    return cw


def _pad(cw, capacity):
    cw = list(cw)
    if len(cw) < capacity:
        cw.append(129)
    while len(cw) < capacity:
        pos = len(cw) + 1
        v = 129 + (149 * pos) % 253 + 1
        cw.append(v if v <= 254 else v - 254)
    return cw


# ------------------------------------------------------------------ penempatan modul (Annex F)
def place(codewords, nrows, ncols):
    """Matriks area data nrows x ncols (True = gelap) dari deretan codeword."""
    bits = [[None] * ncols for _ in range(nrows)]

    def module(row, col, pos, bit):
        if row < 0:
            row += nrows
            col += 4 - ((nrows + 4) % 8)
        if col < 0:
            col += ncols
            row += 4 - ((ncols + 4) % 8)
        v = codewords[pos] if pos < len(codewords) else 0
        bits[row][col] = bool(v & (1 << (8 - bit)))

    def utah(row, col, pos):
        module(row - 2, col - 2, pos, 1)
        module(row - 2, col - 1, pos, 2)
        module(row - 1, col - 2, pos, 3)
        module(row - 1, col - 1, pos, 4)
        module(row - 1, col, pos, 5)
        module(row, col - 2, pos, 6)
        module(row, col - 1, pos, 7)
        module(row, col, pos, 8)

    def corner1(pos):
        module(nrows - 1, 0, pos, 1)
        module(nrows - 1, 1, pos, 2)
        module(nrows - 1, 2, pos, 3)
        module(0, ncols - 2, pos, 4)
        module(0, ncols - 1, pos, 5)
        module(1, ncols - 1, pos, 6)
        module(2, ncols - 1, pos, 7)
        module(3, ncols - 1, pos, 8)

    def corner2(pos):
        module(nrows - 3, 0, pos, 1)
        module(nrows - 2, 0, pos, 2)
        module(nrows - 1, 0, pos, 3)
        module(0, ncols - 4, pos, 4)
        module(0, ncols - 3, pos, 5)
        module(0, ncols - 2, pos, 6)
        module(0, ncols - 1, pos, 7)
        module(1, ncols - 1, pos, 8)

    def corner3(pos):
        module(nrows - 3, 0, pos, 1)
        module(nrows - 2, 0, pos, 2)
        module(nrows - 1, 0, pos, 3)
        module(0, ncols - 2, pos, 4)
        module(0, ncols - 1, pos, 5)
        module(1, ncols - 1, pos, 6)
        module(2, ncols - 1, pos, 7)
        module(3, ncols - 1, pos, 8)

    def corner4(pos):
        module(nrows - 1, 0, pos, 1)
        module(nrows - 1, ncols - 1, pos, 2)
        module(0, ncols - 3, pos, 3)
        module(0, ncols - 2, pos, 4)
        module(0, ncols - 1, pos, 5)
        module(1, ncols - 3, pos, 6)
        module(1, ncols - 2, pos, 7)
        module(1, ncols - 1, pos, 8)

    pos, row, col = 0, 4, 0
    while True:
        if row == nrows and col == 0:
            corner1(pos); pos += 1
        if row == nrows - 2 and col == 0 and ncols % 4 != 0:
            corner2(pos); pos += 1
        if row == nrows - 2 and col == 0 and ncols % 8 == 4:
            corner3(pos); pos += 1
        if row == nrows + 4 and col == 2 and ncols % 8 == 0:
            corner4(pos); pos += 1
        while True:                                   # naik diagonal
            if row < nrows and col >= 0 and bits[row][col] is None:
                utah(row, col, pos); pos += 1
            row -= 2
            col += 2
            if not (row >= 0 and col < ncols):
                break
        row += 1
        col += 3
        while True:                                   # turun diagonal
            if row >= 0 and col < ncols and bits[row][col] is None:
                utah(row, col, pos); pos += 1
            row += 2
            col -= 2
            if not (row < nrows and col >= 0):
                break
        row += 3
        col += 1
        if not (row < nrows or col < ncols):
            break
    if bits[nrows - 1][ncols - 1] is None:            # pola tetap di pojok kanan bawah
        bits[nrows - 1][ncols - 1] = True
        bits[nrows - 2][ncols - 2] = True
    return [[bool(c) for c in r] for r in bits], pos


def assemble(bits, size, region, regions):
    """Tambahkan finder (L solid kiri+bawah) dan clock (selang-seling atas+kanan) tiap region."""
    m = [[False] * size for _ in range(size)]
    step = region + 2
    for ry in range(regions):
        for rx in range(regions):
            top, left = ry * step, rx * step
            for k in range(step):
                m[top + k][left] = True                       # kiri: solid
                m[top + step - 1][left + k] = True            # bawah: solid
                m[top][left + k] = (k % 2 == 0)               # atas: gelap-terang-...
                m[top + k][left + step - 1] = (k % 2 == 1)    # kanan: terang-gelap-...
            for ly in range(region):
                for lx in range(region):
                    m[top + 1 + ly][left + 1 + lx] = bits[ry * region + ly][rx * region + lx]
    return m


def choose_size(n_codewords):
    for s in SIZES:
        if s[3] >= n_codewords:
            return s
    raise DataMatrixError(
        f"Data terlalu panjang untuk simbol yang didukung (maks {MAX_DATA_CODEWORDS} codeword).")


def encode(text):
    """Return (matriks bool [baris][kolom], info). Hanya ASCII."""
    if not text:
        raise DataMatrixError("Teks kosong.")
    data = ascii_codewords(text)
    size, region, regions, cap, ecc = choose_size(len(data))
    data = _pad(data, cap)
    full = data + reed_solomon(data, ecc)
    side = region * regions
    bits, used = place(full, side, side)
    matrix = assemble(bits, size, region, regions)
    return matrix, {"size": size, "data_codewords": cap, "used_codewords": len(ascii_codewords(text)),
                    "ecc_codewords": ecc, "codewords": full, "placed": used}


# ------------------------------------------------------------------ keluaran
def to_svg(matrix, scale=4, quiet=2, title=""):
    n = len(matrix)
    dim = n + 2 * quiet
    parts = []
    for y, row in enumerate(matrix):
        x = 0
        while x < n:
            if row[x]:
                x0 = x
                while x < n and row[x]:
                    x += 1
                parts.append(f"M{x0 + quiet} {y + quiet}h{x - x0}v1h-{x - x0}z")
            else:
                x += 1
    label = html.escape(title or "Data Matrix", quote=True)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {dim} {dim}" width="{dim * scale}" '
            f'height="{dim * scale}" shape-rendering="crispEdges" role="img" aria-label="{label}">'
            f'<rect width="{dim}" height="{dim}" fill="#fff"/><path d="{"".join(parts)}" fill="#000"/></svg>')


def to_png(matrix, scale=8, quiet=2):
    """PNG hitam-putih (grayscale 8 bit) tanpa pustaka tambahan."""
    n = len(matrix)
    dim = (n + 2 * quiet) * scale
    white = b"\xff" * dim
    rows = [b"\x00" + white] * (quiet * scale)
    for r in matrix:
        line = bytearray(b"\xff" * (quiet * scale))
        for v in r:
            line += (b"\x00" if v else b"\xff") * scale
        line += b"\xff" * (quiet * scale)
        rows += [b"\x00" + bytes(line)] * scale
    rows += [b"\x00" + white] * (quiet * scale)

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", dim, dim, 8, 0, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"".join(rows), 9)) + chunk(b"IEND", b""))


def to_text(matrix, quiet=1, dark="##", light="  "):
    """Gambar ASCII (untuk konsol). Satu modul = dua karakter agar mendekati persegi."""
    n = len(matrix)
    blank = light * (n + 2 * quiet)
    lines = [blank] * quiet
    for r in matrix:
        lines.append(light * quiet + "".join(dark if v else light for v in r) + light * quiet)
    return "\n".join(lines + [blank] * quiet)
