@echo off
title DOM/BTRV - Emergency Barcode
call "%~dp0_prep.bat"
if errorlevel 1 exit /b 1

:menu
cls
echo ==========================================
echo      EMERGENCY BARCODE (DMC dummy)
echo ==========================================
echo   [1] Buat barcode
echo   [2] Riwayat pembuatan (kapan, siapa, nilai)
echo   [0] Keluar
echo.
choice /c 120 /n /m "Pilih menu: "
if errorlevel 3 goto :eof
if errorlevel 2 goto :riwayat
goto :buat

:buat
cls
echo  Ketik 11 karakter KAPITAL:
echo    Identifier (2) + Partnumber (7) + Change index (2)
echo    contoh: 22ABC1234XY
echo.
set "K="
set /p "K=Kode 11 karakter (kosong = kembali): "
if not defined K goto :menu
set "T=" & set "J="
set /p "T=Tanggal YYYY-MM-DD (Enter = sekarang): "
if defined T set /p "J=Jam HH:MM:SS (Enter = sekarang): "
venv\Scripts\python.exe manage.py dombtrv emergency %K% --tanggal "%T%" --jam "%J%"
if exist "DOMBTRV\emergency\hasil\terakhir.html" (
    echo.
    choice /c YN /n /m "Buka barcode di browser? [Y/N] "
    if not errorlevel 2 start "" "DOMBTRV\emergency\hasil\terakhir.html"
)
echo.
pause
goto :menu

:riwayat
echo.
set "Q="
set /p "Q=Cari (kode / nilai / NPK, Enter = semua): "
venv\Scripts\python.exe manage.py dombtrv emergencyriwayat %Q% --limit 30
echo.
pause
goto :menu
