"""
DOMBTRV (DOM/BTRV) - scan file xml AddOnPart di folder sumber. Logika inti TANPA Django.
Hanya MEMBACA: file di folder sumber tidak pernah diubah, dipindah, atau dihapus.
"""
import configparser
import fnmatch
import json
import os
import re
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

MODULE_DIR = Path(__file__).resolve().parent
CONFIG_INI = MODULE_DIR / "dombtrv.ini"
LOCK_FILE = MODULE_DIR / ".lock"


def _general(module, tarik=False):
    """Hubungan ke general.ini di folder utama (master konfigurasi).
    tarik=False: salin general.ini -> ini modul; tarik=True: tulis ini modul -> general.ini."""
    try:
        import sys
        root = str(MODULE_DIR.parent)
        if root not in sys.path:
            sys.path.insert(0, root)
        import general_sync
        if tarik:
            general_sync.pull(module)
            return True
        general_sync.ensure_general()
        return general_sync.push_module(module)
    except Exception:
        return False

MAX_XML_BYTES = 5 * 1024 * 1024
BATCH_SIZE = 300
# Naikkan angka ini bila aturan baca XML berubah: scan berikutnya otomatis membaca ulang semua file satu kali.
PARSER_VERSION = 3

DEFAULT_INI = """\
; ============================================================
;  DOMBTRV - dombtrv.ini
;  folder       : folder sumber file xml (nanti boleh UNC, mis. \\\\server\\share\\Delete)
;  pola         : pola nama file
;  subfolder    : true = ikut scan semua subfolder, false = hanya folder itu saja
;  interval_jam : jadwal scan (jam). Dipakai untuk penanda "data sudah lama" dan Task Scheduler.
;  hapus_hilang : true = data file yang sudah tidak ada di folder ikut dihapus dari database,
;                 false = data lama dipertahankan
;  Nilai ya/tidak/yes/no/1/0 tetap dikenali, tetapi tulislah true / false.
; ============================================================

[sumber]
folder = D:\\Data\\Delete
pola = *.xml
subfolder = false

[jadwal]
interval_jam = 2

[pengaturan]
ini_versi = 2
hapus_hilang = false

; Update file model xml (Part List) ke server
[model]
folder_server = D:\\models
nama_file = model.xml
max_backup = 4
"""

MODEL_SECTION = """
; Update file model xml (Part List) ke server
; folder_server : folder induk di server (berisi G05, G20, ... masing-masing dengan Archive)
; nama_file     : nama file di tiap folder model (sama untuk semua model)
; max_backup    : jumlah versi lama yang disimpan di aplikasi untuk rollback (per model)
[model]
folder_server = D:\\models
nama_file = model.xml
max_backup = 4
"""

# 1794670445682_MHH16EH00TKA14184_G70_FRONT_LIGHT_LH.xml  ->  vin, model, nama part
FILENAME_RE = re.compile(r"^(?:\d+_)?(?P<vin>[A-Za-z0-9]{17})_(?P<model>[A-Za-z0-9]+)_(?P<name>.+)\.xml$", re.I)


class SourceError(Exception):
    """Folder sumber tidak bisa diakses."""


class BusyError(Exception):
    pass


class lock:
    """Kunci agar scan dari web, batch, dan scheduler tidak jalan bersamaan."""

    def __enter__(self):
        if LOCK_FILE.exists() and time.time() - LOCK_FILE.stat().st_mtime > 15 * 60:
            LOCK_FILE.unlink(missing_ok=True)          # kunci basi (proses mati)
        try:
            fd = os.open(LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
        except FileExistsError:
            raise BusyError("Scan DOM/BTRV sedang berjalan (web/batch/scheduler). Tunggu sampai selesai.")
        return self

    def touch(self):
        try:
            os.utime(LOCK_FILE)
        except OSError:
            pass

    def __exit__(self, *exc):
        LOCK_FILE.unlink(missing_ok=True)


def is_locked():
    return LOCK_FILE.exists() and time.time() - LOCK_FILE.stat().st_mtime <= 15 * 60


# ---------------------------------------------------------------- konfigurasi
def ensure_ini():
    if not CONFIG_INI.exists():
        _general("dombtrv")                  # general.ini = master: salin dulu ke sini
    if not CONFIG_INI.exists():
        CONFIG_INI.write_text(DEFAULT_INI, encoding="utf-8")
        return
    txt = CONFIG_INI.read_text(encoding="utf-8", errors="replace")
    if "[model]" not in txt:                       # ini lama (sebelum ada fitur model): tambahkan bagian baru
        txt = txt.rstrip() + "\n" + MODEL_SECTION
        CONFIG_INI.write_text(txt, encoding="utf-8")
    if "ini_versi" in txt:
        return
    # Peningkatan satu kali dari ini lama: nilai ya/tidak -> false (subfolder & hapus_hilang dimatikan), tambah penanda versi.
    for key in ("subfolder", "hapus_hilang"):
        txt = re.sub(rf"(?im)^(\s*{key}\s*=\s*)(ya|tidak|yes|no)\s*$", lambda m: m.group(1) + "false", txt)
    if "[pengaturan]" in txt:
        txt = txt.replace("[pengaturan]", "[pengaturan]\nini_versi = 2", 1)
    else:
        txt = txt.rstrip() + "\n\n[pengaturan]\nini_versi = 2\n"
    CONFIG_INI.write_text(txt, encoding="utf-8")


def read_config():
    ensure_ini()
    cp = configparser.ConfigParser(interpolation=None)
    cp.read(CONFIG_INI, encoding="utf-8")
    g = lambda s, k, d: (cp.get(s, k, fallback=d) or d).strip()
    yes = lambda v: v.strip().lower() in ("true", "ya", "yes", "1", "y")
    try:
        interval = max(0.1, float(g("jadwal", "interval_jam", "2").replace(",", ".")))
    except ValueError:
        interval = 2.0
    return {"folder": g("sumber", "folder", r"D:\Data\Delete"),
            "pola": g("sumber", "pola", "*.xml"),
            "rekursif": yes(g("sumber", "subfolder", "false")),
            "interval_jam": interval,
            "hapus_hilang": yes(g("pengaturan", "hapus_hilang", "false")),
            "model_server": g("model", "folder_server", r"D:\models"),
            "model_file": g("model", "nama_file", "model.xml"),
            "model_max_backup": max(1, int(g("model", "max_backup", "4")) if g("model", "max_backup", "4").isdigit() else 4)}


def humanize(seconds):
    seconds = max(0, int(seconds))
    if seconds < 60:
        return "baru saja"
    m = seconds // 60
    if m < 60:
        return f"{m} menit lalu"
    h, m = divmod(m, 60)
    if h < 48:
        return f"{h} jam {m} menit lalu" if m else f"{h} jam lalu"
    return f"{h // 24} hari lalu"


# ---------------------------------------------------------------- baca satu file xml
def _parse_ts(s):
    s = (s or "").strip()
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo:
        dt = dt.astimezone().replace(tzinfo=None)
    return dt


def parse_xml_file(abs_path, rel, size, mtime_ns):
    """Baca satu file. Tidak pernah melempar error: file rusak dicatat dengan ok=False + pesan."""
    name = os.path.basename(rel)
    fm = FILENAME_RE.match(name)
    rec = dict(
        path=rel, file_name=name, file_size=size, file_mtime_ns=mtime_ns,
        file_mtime=datetime.fromtimestamp(mtime_ns / 1e9),
        vin=fm.group("vin").upper() if fm else "", vehicle_no="",
        model_code=fm.group("model").upper() if fm else "",
        part_name=fm.group("name") if fm else "", part_class="", hostname="",
        part_no="", serial_no="", ts=None, descriptors="[]", ok=True, error="", parse_ver=PARSER_VERSION)
    descs = []
    try:
        if size > MAX_XML_BYTES:
            raise ValueError(f"file terlalu besar ({size} byte)")
        with open(abs_path, "rb") as f:
            raw = f.read()
        if b"<!ENTITY" in raw or b"<!DOCTYPE" in raw:
            raise ValueError("DOCTYPE/ENTITY tidak diizinkan")
        root = ET.fromstring(raw)
        tag = root.tag.split("}")[-1]
        if tag != "AddOnPart":
            raise ValueError(f"elemen utama <{tag}>, seharusnya <AddOnPart>")
        rec["part_name"] = root.get("name") or rec["part_name"]
        rec["part_class"] = root.get("addOnPartClass", "")
        rec["hostname"] = root.get("hostname", "")
        rec["vehicle_no"] = root.get("vehicleNo", "")
        rec["vin"] = (root.get("vinLong") or rec["vin"]).strip().upper()
        rec["ts"] = _parse_ts(root.get("timestamp"))
        for d in root.iter("Descriptor"):
            descs.append({"type": d.get("type", ""), "value": d.get("value", ""),
                          "scannedValue": d.get("scannedValue", ""), "code": d.get("code", "")})
        for d in descs:
            t = d["type"].lower()
            if t == "partno" and not rec["part_no"]:
                rec["part_no"] = d["value"]
            elif t == "serialno" and not rec["serial_no"]:
                rec["serial_no"] = d["value"]
        # Tidak ada PartNo & SerialNo tetapi ada descriptor lain: nilainya dipakai untuk keduanya
        if not rec["part_no"] and not rec["serial_no"]:
            first = next((d["value"] or d["scannedValue"] for d in descs if d["value"] or d["scannedValue"]), "")
            if first:
                rec["part_no"] = rec["serial_no"] = first
        # XML VehicleType: model = nilai descriptor (bukan dari nama file)
        # (descriptor bertipe VehicleType / VehicleTypeNo, atau nama part VehicleType -> descriptor pertama)
        has_val = lambda d: d["value"] or d["scannedValue"]
        vt = next((d for d in descs if d["type"].lower().startswith("vehicletype") and has_val(d)), None)
        if vt is None and rec["part_name"].lower().startswith("vehicletype"):
            vt = next((d for d in descs if has_val(d)), None)
        if vt:
            rec["model_code"] = (vt["value"] or vt["scannedValue"]).strip().upper()
    except Exception as e:                       # XML rusak / belum selesai ditulis / bukan AddOnPart
        rec["ok"] = False
        rec["error"] = f"{type(e).__name__}: {e}"[:300]
    rec["descriptors"] = json.dumps(descs, ensure_ascii=False)
    parts = [rec["vin"], rec["vehicle_no"], rec["model_code"], rec["part_name"], rec["part_class"],
             rec["hostname"], rec["part_no"], rec["serial_no"], name]
    for d in descs:
        parts += [d["type"], d["value"], d["scannedValue"]]
    rec["search_text"] = " ".join(p for p in parts if p).lower()
    return rec


# ---------------------------------------------------------------- scan folder
@dataclass
class ScanResult:
    seen: set = field(default_factory=set)
    total: int = 0            # semua file xml yang ditemukan
    unchanged: int = 0
    parsed: int = 0           # file baru / berubah yang dibaca
    parse_errors: int = 0
    skipped_fresh: int = 0
    dir_errors: list = field(default_factory=list)

    @property
    def complete(self):
        return not self.dir_errors


def check_folder(folder):
    d = Path(folder)
    try:
        if not d.is_dir():
            raise SourceError(f"Folder sumber tidak ditemukan / tidak bisa diakses: {folder}")
        with os.scandir(d):
            pass
    except OSError as e:
        raise SourceError(f"Folder sumber tidak bisa dibaca: {folder} ({e})")


def iter_files(folder, pola, rekursif, dir_errors):
    pat = pola.lower()
    stack = [str(folder)]
    while stack:
        d = stack.pop()
        try:
            with os.scandir(d) as it:
                entries = list(it)
        except OSError as e:
            dir_errors.append(f"{d}: {e}")
            continue
        for e in entries:
            try:
                if e.is_dir(follow_symlinks=False):
                    if rekursif:
                        stack.append(e.path)
                elif e.is_file() and fnmatch.fnmatch(e.name.lower(), pat):
                    yield e.path, e.stat()
            except OSError as ex:
                dir_errors.append(f"{e.path}: {ex}")


def scan_folder(cfg, existing, on_batch, on_progress=None, heartbeat=None):
    """
    existing : {path_relatif: (size, mtime_ns, parse_ver)} yang sudah ada di database
    on_batch : dipanggil dengan list record (file baru / berubah) tiap BATCH_SIZE file
    Hanya file baru atau berubah (ukuran / waktu modifikasi) yang dibaca ulang.
    """
    folder = cfg["folder"]
    res = ScanResult()
    batch = []
    now = time.time()
    for path, st in iter_files(folder, cfg["pola"], cfg["rekursif"], res.dir_errors):
        rel = os.path.relpath(path, folder)
        res.total += 1
        res.seen.add(rel)
        if rel in existing and existing[rel] == (st.st_size, st.st_mtime_ns, PARSER_VERSION):
            res.unchanged += 1
        elif now - st.st_mtime_ns / 1e9 < 2:         # masih ditulis -> lewati, dibaca di scan berikutnya
            res.skipped_fresh += 1
        else:
            rec = parse_xml_file(path, rel, st.st_size, st.st_mtime_ns)
            res.parsed += 1
            if not rec["ok"]:
                res.parse_errors += 1
            batch.append(rec)
            if len(batch) >= BATCH_SIZE:
                on_batch(batch)
                batch = []
        if res.total % 200 == 0:
            if on_progress:
                on_progress(res)
            if heartbeat:
                heartbeat()
    if batch:
        on_batch(batch)
    if on_progress:
        on_progress(res)
    return res
