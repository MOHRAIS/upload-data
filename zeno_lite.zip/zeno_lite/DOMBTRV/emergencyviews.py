from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

from . import datamatrix, emergency as em, emergencysvc


def _oleh(request):
    return getattr(request.user, "npk", "-")


@login_required
def emergency_page(request):
    return render(request, "dombtrv/emergency.html", {
        "reason": em.REASON, "active": "emergency", "idents": len(em.load_identifiers()),
        "patterns": em.patterns_info()})


@login_required
def emergency_buat(request):
    """JSON: SATU barcode untuk kode 11 karakter + panjang yang dipilih. catat=1 -> masuk riwayat."""
    try:
        code = em.normalize_code(request.GET.get("kode", ""))
        pola = em.resolve_pattern(request.GET.get("pola", ""))
        when, auto = em.parse_when(request.GET.get("tgl", ""), request.GET.get("jam", ""))
        item = em.generate_one(code, when, pola)
    except em.InputError as e:
        return JsonResponse({"ok": False, "error": str(e)}, status=400)
    except datamatrix.DataMatrixError as e:
        return JsonResponse({"ok": False, "error": f"Barcode gagal dibuat: {e}"}, status=400)
    mode = "sekarang" if auto else "manual"
    ident, name = em.identifier_info(code)
    out = {"ok": True, "kode": code, "identifier": ident, "jenis": name, "label": item["label"],
           "value": item["value"], "svg": item["svg"], "size": item["size"],
           "waktu_dipakai": when.strftime("%d.%m.%Y %H:%M:%S"), "mode": mode, "alasan": em.REASON,
           "dicatat": False}
    if request.GET.get("catat") == "1":
        log = emergencysvc.catat(_oleh(request), "WEB", code, item, when, mode)
        out.update(dicatat=True, dibuat=emergencysvc.fmt_dt(log.waktu), oleh=log.oleh)
    return JsonResponse(out)


@login_required
def emergency_lihat(request):
    """Tampilkan lagi barcode dari nilai yang sudah ada (untuk riwayat). Tidak mencatat riwayat."""
    value = (request.GET.get("v") or "").strip().upper()
    try:
        b = em.barcode_for(value)
    except (em.InputError, datamatrix.DataMatrixError) as e:
        return JsonResponse({"ok": False, "error": str(e)}, status=400)
    return JsonResponse({"ok": True, "value": value, "svg": b["svg"], "size": b["size"]})


@login_required
def emergency_riwayat(request):
    try:
        page = int(request.GET.get("page", 1))
    except ValueError:
        page = 1
    return JsonResponse(emergencysvc.riwayat(request.GET.get("q", ""), page, 15))


@login_required
def emergency_gambar(request):
    """Gambar satu nilai DMC: ?v=NILAI&fmt=png|svg&skala=8&dl=1 (unduh)."""
    value = (request.GET.get("v") or "").strip().upper()
    fmt = request.GET.get("fmt", "png")
    try:
        scale = min(max(int(request.GET.get("skala", 8)), 1), 40)
    except ValueError:
        scale = 8
    try:
        b = em.barcode_for(value, scale=scale)
    except (em.InputError, datamatrix.DataMatrixError) as e:
        return HttpResponse(str(e), status=400, content_type="text/plain; charset=utf-8")
    if fmt == "svg":
        resp = HttpResponse(b["svg"], content_type="image/svg+xml")
        name = f"DMC_{value[:20]}.svg"
    else:
        resp = HttpResponse(datamatrix.to_png(b["matrix"], scale=scale), content_type="image/png")
        name = f"DMC_{value[:20]}.png"
    if request.GET.get("dl"):
        resp["Content-Disposition"] = f'attachment; filename="{name}"'
    return resp
