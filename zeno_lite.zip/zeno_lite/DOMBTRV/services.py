"""Scan folder xml -> database. Dipakai bersama oleh web, batch, dan scheduler."""
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timedelta

from django.db import connection, transaction
from django.db.models import Count
from django.utils import timezone

from . import core
from .models import AddOnPart, ScanLog, ScanState

DB_FIELDS = ["file_name", "file_size", "file_mtime_ns", "file_mtime", "vin", "vehicle_no", "model_code",
             "part_name", "part_class", "hostname", "part_no", "serial_no", "ts", "descriptors",
             "ok", "error", "search_text", "parse_ver"]
MASS_DELETE_RATIO = 0.5
MASS_DELETE_MIN = 100


@dataclass
class ScanOutcome:
    status: str            # dimulai | ok | gagal | ditahan | sibuk
    message: str = ""

    @property
    def level(self):
        return {"ok": "success", "dimulai": "info"}.get(self.status, "error" if self.status == "gagal" else "warning")


def _aware(dt):
    if dt is None:
        return None
    try:
        return timezone.make_aware(dt)
    except Exception:
        return None


def _prep(rec):
    d = dict(rec)
    d["ts"] = _aware(d["ts"])
    d["file_mtime"] = _aware(d["file_mtime"])
    return d


def _chunks(seq, n=500):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


# ------------------------------------------------------------------ status
def get_state():
    st, _ = ScanState.objects.get_or_create(key="scan")
    # scan 'berjalan' tapi prosesnya sudah mati -> tandai terhenti
    if st.status == "berjalan" and not core.is_locked():
        st.status = "gagal"
        st.message = "Scan sebelumnya terhenti sebelum selesai (aplikasi ditutup?). Jalankan scan ulang."
        st.finished_at = timezone.now()
        st.save()
    return st


def status_info():
    """Ringkasan untuk web dan batch: kapan terakhir scan, apakah sudah lewat jadwal."""
    cfg = core.read_config()
    st = get_state()
    last = st.finished_at if st.status != "berjalan" else None
    age = (timezone.now() - last).total_seconds() if last else None
    return {
        "state": st, "cfg": cfg, "running": st.status == "berjalan",
        "last_scan": fmt_dt(last) if last else None,
        "age_text": core.humanize(age) if age is not None else None,
        "stale": age is None or age > cfg["interval_jam"] * 3600,
        "total": AddOnPart.objects.filter(ok=True).count(),      # hanya XML valid (yang tampil di tabel)
        "errors": AddOnPart.objects.filter(ok=False).count(),    # XML rusak: tidak ditampilkan di tabel
    }


# ------------------------------------------------------------------ scan
def start_scan(oleh="-", background=False, allow_mass_delete=False, force=False):
    """
    background=True : web (langsung kembali, progres dibaca lewat status)
    background=False: batch / scheduler (selesai dulu baru kembali)
    force=True      : baca ulang SEMUA file (bukan hanya yang baru/berubah)
    """
    lk = core.lock()
    try:
        lk.__enter__()
    except core.BusyError as e:
        return ScanOutcome("sibuk", str(e))
    cfg = core.read_config()
    st, _ = ScanState.objects.get_or_create(key="scan")
    st.status, st.folder, st.oleh = "berjalan", cfg["folder"], oleh
    st.started_at, st.finished_at, st.progress_done, st.files_total = timezone.now(), None, 0, 0
    st.message = "Memeriksa folder..."
    st.save()
    if background:
        threading.Thread(target=_run_thread, args=(lk, oleh, allow_mass_delete, force), daemon=True).start()
        return ScanOutcome("dimulai", f"Scan dimulai di {cfg['folder']}. Pantau progresnya di halaman ini.")
    try:
        return _scan(lk, oleh, allow_mass_delete, force)
    finally:
        lk.__exit__(None, None, None)


def _run_thread(lk, oleh, mass, force=False):
    try:
        _scan(lk, oleh, mass, force)
    except Exception as e:                       # jangan biarkan thread mati tanpa jejak
        st = ScanState.objects.get(key="scan")
        st.status, st.message, st.finished_at = "gagal", f"Scan error: {type(e).__name__}: {e}", timezone.now()
        st.save()
    finally:
        lk.__exit__(None, None, None)
        connection.close()


def _finish(st, status, msg, t0, oleh, new=0, changed=0, removed=0, errors=0, total=0):
    st.status, st.message, st.finished_at = status, msg, timezone.now()
    st.files_total, st.files_new, st.files_changed, st.files_removed, st.files_error = total, new, changed, removed, errors
    st.save()
    ScanLog.objects.create(oleh=oleh, status=status, durasi=round(time.time() - t0, 1), total=total,
                           baru=new, diubah=changed, dihapus=removed, error=errors, pesan=msg[:1000])
    return ScanOutcome(status, msg)


def _scan(lk, oleh, allow_mass_delete, force=False):
    t0 = time.time()
    cfg = core.read_config()
    st = ScanState.objects.get(key="scan")
    try:
        core.check_folder(cfg["folder"])
    except core.SourceError as e:
        return _finish(st, "gagal", str(e), t0, oleh)

    existing = {p: (s, m, v) for p, s, m, v in
                AddOnPart.objects.values_list("path", "file_size", "file_mtime_ns", "parse_ver")}
    cnt = {"new": 0, "changed": 0}

    def on_batch(recs):
        new = [r for r in recs if r["path"] not in existing]
        upd = [r for r in recs if r["path"] in existing]
        with transaction.atomic():
            if new:
                AddOnPart.objects.bulk_create([AddOnPart(**_prep(r)) for r in new], batch_size=300)
            if upd:
                objs = AddOnPart.objects.in_bulk([r["path"] for r in upd], field_name="path")
                for r in upd:
                    o = objs.get(r["path"])
                    if o:
                        for k, v in _prep(r).items():
                            setattr(o, k, v)
                AddOnPart.objects.bulk_update(list(objs.values()), DB_FIELDS, batch_size=100)
        cnt["new"] += len(new)
        cnt["changed"] += len(upd)

    def on_progress(res):
        st.progress_done, st.files_total = res.total, res.total
        st.message = f"Memeriksa... {res.total} file ditemukan, {res.parsed} dibaca (baru/berubah)"
        st.save()

    # force: anggap semua file belum pernah dibaca (data lama tetap diperbarui, bukan digandakan)
    res = core.scan_folder(cfg, {} if force else existing, on_batch, on_progress, lk.touch)

    removed = 0
    gone = [p for p in existing if p not in res.seen]
    note = ""
    status = "ok"
    if not res.complete:
        note = f" | {len(res.dir_errors)} folder tidak terbaca, penghapusan data dilewati ({res.dir_errors[0][:120]})"
    elif gone and not cfg["hapus_hilang"]:
        note = f" | {len(gone)} data sudah tidak ada di folder (dipertahankan, hapus_hilang = false)"
    elif gone:
        if len(existing) >= MASS_DELETE_MIN and len(gone) > len(existing) * MASS_DELETE_RATIO and not allow_mass_delete:
            status = "ditahan"
            note = (f" | {len(gone)} dari {len(existing)} file sudah tidak ada di folder - penghapusan data ditahan "
                    f"demi keamanan. Periksa folder sumber; bila memang benar, setujui.")
        else:
            for chunk in _chunks(gone):
                AddOnPart.objects.filter(path__in=chunk).delete()
            removed = len(gone)
    err_total = AddOnPart.objects.filter(ok=False).count()          # total file rusak saat ini (bukan hanya yang baru dibaca)
    msg = ("[baca ulang semua] " if force else "") + (f"{res.total} file xml di folder: +{cnt['new']} baru, {cnt['changed']} berubah, -{removed} dihapus, "
           f"{res.unchanged} tidak berubah, {err_total} rusak/tidak valid")
    if res.skipped_fresh:
        msg += f", {res.skipped_fresh} masih ditulis (dibaca di scan berikutnya)"
    return _finish(st, status, msg + note, t0, oleh, cnt["new"], cnt["changed"], removed, err_total, res.total)


# ------------------------------------------------------------------ pencarian
SORTABLE = {"ts", "vin", "vehicle_no", "model_code", "part_name", "part_no", "serial_no", "hostname",
            "file_name", "part_class", "file_mtime"}
FILTERS = {"part_name": "part_name", "hostname": "hostname", "model_code": "model_code",
           "part_class": "part_class"}


def _day(s):
    try:
        return datetime.strptime((s or "").strip(), "%Y-%m-%d")
    except ValueError:
        return None


def _filtered(params, skip=None):
    qs = AddOnPart.objects.filter(ok=True)          # XML rusak tidak pernah ditampilkan
    for tok in (params.get("q") or "").lower().split():
        qs = qs.filter(search_text__contains=tok)
    for p, f in FILTERS.items():
        if p == skip:
            continue
        v = (params.get(p) or "").strip()
        if v != "":
            qs = qs.filter(**{f: v})
    d1, d2 = _day(params.get("dari")), _day(params.get("sampai"))
    if d1:
        qs = qs.filter(ts__gte=_aware(d1))
    if d2:
        qs = qs.filter(ts__lt=_aware(d2 + timedelta(days=1)))
    return qs


def search(params):
    sort = params.get("sort") or "ts"
    if sort not in SORTABLE:
        sort = "ts"
    desc = (params.get("dir") or "desc") != "asc"
    return _filtered(params).order_by(("-" if desc else "") + sort, "path")


def facets(params):
    """Pilihan tiap filter = nilai yang masih ada setelah kata pencarian dan filter LAIN diterapkan."""
    out = {}
    for p, f in FILTERS.items():
        rows = _filtered(params, skip=p).order_by().values(f).annotate(n=Count("pk")).order_by(f)
        items = []
        for r in rows:
            val = r[f]
            if val is None or val == "":
                continue
            items.append([str(val), r["n"]])
        out[p] = items
    return out


def fmt_dt(dt):
    if not dt:
        return "-"
    return timezone.localtime(dt).strftime("%d.%m.%Y %H:%M:%S")


def row_dict(o):
    return dict(id=o.pk, ts=fmt_dt(o.ts), vin=o.vin, vehicle_no=o.vehicle_no, model=o.model_code,
                part=o.part_name, part_no=o.part_no, serial_no=o.serial_no, hostname=o.hostname,
                file=o.file_name)


def broken_files(limit=200):
    """Daftar XML rusak (hanya info; tidak masuk tabel pencarian)."""
    return [dict(path=o.path, error=o.error) for o in AddOnPart.objects.filter(ok=False).order_by("path")[:limit]]


def detail(pk):
    import json
    o = AddOnPart.objects.filter(pk=pk, ok=True).first()
    if not o:
        return None
    cfg = core.read_config()
    try:
        descs = json.loads(o.descriptors or "[]")
    except ValueError:
        descs = []
    fields = [["VIN", o.vin], ["VehicleNo", o.vehicle_no], ["Model (dari nama file)", o.model_code],
              ["Part (name)", o.part_name], ["Kelas (addOnPartClass)", o.part_class], ["Hostname", o.hostname],
              ["Timestamp", fmt_dt(o.ts)], ["PartNo", o.part_no], ["SerialNo", o.serial_no],
              ["Nama file", o.file_name], ["Lokasi", f"{cfg['folder']}\\{o.path}"],
              ["Ukuran file", f"{o.file_size} byte"], ["Waktu modifikasi file", fmt_dt(o.file_mtime)],
              ["Terakhir discan", fmt_dt(o.scanned_at)]]
    return {"fields": [[a, b if b else "-"] for a, b in fields], "descriptors": descs,
            "ok": o.ok, "error": o.error, "title": f"{o.vin or o.file_name}  -  {o.part_name}"}
