"""Update model xml ke server: penghubung modelcore <-> database. Dipakai web dan batch."""
from dataclasses import dataclass, field

from django.utils import timezone

from . import core, modelcore as mc
from .models import ModelCopy, ModelLog, ModelServer

ACTION_BY_SPEC = {"upload": "UPLOAD", "app": "DORONG", "server": "TARIK", "backup": "ROLLBACK"}


@dataclass
class Report:
    judul: str = ""
    rows: list = field(default_factory=list)     # (level, teks): ok | warn | err | info

    def add(self, level, text):
        self.rows.append((level, text))

    @property
    def ada_gagal(self):
        return any(l == "err" for l, _ in self.rows)


def log(aksi, key="", dari="", ke="", folders="", oleh="-", status="ok", pesan=""):
    ModelLog.objects.create(aksi=aksi, key=key, dari_versi=dari, ke_versi=ke, folders=folders[:200],
                            oleh=oleh, status=status, pesan=pesan[:1000])


def server_status(fi, copies):
    """Status satu folder server dibanding salinan aplikasi."""
    if not fi.exists:
        return "tidak ada file"
    if not fi.readable:
        return "header tidak terbaca"
    app = copies.get(fi.key)
    if app is None:
        return "belum ada di aplikasi"
    if app.norm == fi.norm:
        return "sama"
    if fi.version > app.version:
        return "server lebih baru"
    if fi.version < app.version:
        return "aplikasi lebih baru"
    return "versi sama, isi beda"


def refresh_state(plan=None):
    """Catat ke database: salinan aplikasi, keadaan server (hasil pengecekan), dan versions.txt."""
    cfg = core.read_config()
    plan = plan or mc.build_plan(cfg)
    copies = mc.list_app_copies(cfg)
    for key, fi in copies.items():
        ModelCopy.objects.update_or_create(key=key, defaults=dict(
            version=fi.version_raw, filename=cfg["model_file"], norm_hash=fi.norm, size=fi.size))
    ModelCopy.objects.exclude(key__in=list(copies)).delete()
    if plan.server_ok:
        now = timezone.now()
        for f, fi in plan.server.items():
            ModelServer.objects.update_or_create(folder=f, defaults=dict(
                key=fi.key, version=fi.version_raw, norm_hash=fi.norm, file_exists=fi.exists,
                status=server_status(fi, copies), note=fi.error[:300], checked_at=now))
        ModelServer.objects.exclude(folder__in=list(plan.server)).delete()
    mc.write_versions(cfg)
    return plan


def check():
    """Cek server + upload -> rencana. Hasil pengecekan dicatat bila tidak sedang ada proses lain."""
    plan = mc.build_plan()
    try:
        with mc.lock():
            refresh_state(plan)
    except core.BusyError:
        pass
    return plan


def apply(selections, oleh="-"):
    """
    selections: list dict {key, spec, token, yakin(bool), create(set)}; spec 'lewati' = tidak diapa-apa.
    Rencana dibangun ulang di dalam kunci; token memastikan keadaan belum berubah sejak rencana ditampilkan.
    """
    rep = Report("Hasil update model XML")
    cfg = core.read_config()
    with mc.lock():
        plan = mc.build_plan(cfg)
        if not plan.server_ok:
            rep.add("err", plan.warnings[0] if plan.warnings else "Server tidak terjangkau.")
            return rep
        for sel in selections:
            key, spec = sel["key"], sel["spec"]
            kp = plan.item(key)
            if kp is None:
                rep.add("warn", f"{key}: tidak ditemukan lagi di rencana - dilewati.")
                continue
            if spec == "lewati":
                rep.add("info", f"{key}: dilewati (tidak ada perubahan).")
                continue
            if kp.token != sel.get("token"):
                rep.add("warn", f"{key}: isi file berubah sejak rencana dibuat - dilewati. Buka rencana ulang.")
                continue
            src = mc.source_for(kp, spec, cfg)
            if src is None or not src.info.readable:
                rep.add("err", f"{key}: sumber '{spec}' tidak ditemukan / tidak terbaca.")
                continue
            if kp.recommended and spec != kp.recommended and not sel.get("yakin"):
                rep.add("warn", f"{key}: pilihan menyimpang dari aturan versi dan belum dikonfirmasi - dilewati.")
                continue
            res = mc.apply_key(kp, spec, cfg, create=sel.get("create") or ())
            for level, text in res.rows:
                rep.add(level, text)
            gagal = bool(res.failed) or any(l == "err" for l, _ in res.rows)
            aksi = ACTION_BY_SPEC.get(spec.split(":")[0], "DORONG")
            log(aksi, key, res.from_version, res.to_version, ", ".join(res.pushed), oleh,
                "gagal" if gagal else "ok",
                "; ".join(t for l, t in res.rows if l in ("ok", "err", "warn")))
            if not gagal:
                for name in mc.finish_uploads(kp, src.info.norm, spec == "upload"):
                    rep.add("info", f"Upload {name} dipindah ke modeldata\\processed.")
        refresh_state(mc.build_plan(cfg))
    return rep


def rollback(key, backup_filename, create=(), oleh="-"):
    rep = Report(f"Rollback model {key}")
    cfg = core.read_config()
    with mc.lock():
        plan = mc.build_plan(cfg)
        if not plan.server_ok:
            rep.add("err", plan.warnings[0])
            return rep
        kp = plan.item(key)
        if kp is None:
            rep.add("err", f"{key}: model tidak ditemukan.")
            return rep
        spec = "backup:" + backup_filename
        if mc.source_for(kp, spec, cfg) is None:
            rep.add("err", "File backup tidak ditemukan.")
            return rep
        res = mc.apply_key(kp, spec, cfg, create=create)
        for level, text in res.rows:
            rep.add(level, text)
        gagal = bool(res.failed) or any(l == "err" for l, _ in res.rows)
        log("ROLLBACK", key, res.from_version, res.to_version, ", ".join(res.pushed), oleh,
            "gagal" if gagal else "ok", "; ".join(t for l, t in res.rows))
        refresh_state(mc.build_plan(cfg))
    return rep


def summaries(kp, cfg):
    """Ringkasan perbedaan tiap sumber vs rekomendasi (atau vs aplikasi bila konflik) untuk keputusan cepat."""
    base = kp.source(kp.recommended) if kp.recommended else (kp.source("app") or (kp.sources[0] if kp.sources else None))
    out = {}
    if base is None:
        return out
    for s in kp.sources:
        if s is base:
            continue
        if s.info.norm == base.info.norm:
            out[s.spec] = {"same": True, "text": "isi sama", "base": base.spec}
        else:
            d = mc.diff_summary(base.info.path, s.info.path)
            out[s.spec] = {"same": False, "text": mc.diff_summary_text(d), "base": base.spec}
    return out


def plan_rows(plan, cfg):
    """Data siap tampil untuk halaman rencana."""
    rows = []
    for i, kp in enumerate(plan.items):
        sums = summaries(kp, cfg)
        rec = kp.recommended
        acts = kp.actions(rec) if rec else None
        what = []
        if acts:
            if acts["app"]:
                what.append(f"Aplikasi diganti dengan {acts['from'].label} ({acts['from'].vtext})")
            if acts["push"]:
                what.append("Dorong ke server: " + ", ".join(acts["push"]) + " (file lama dipindah ke Archive)")
            if not what:
                what.append("Tidak ada perubahan")
        rows.append({
            "i": i, "kp": kp, "key": kp.key, "status": kp.status, "reason": kp.reason, "notes": kp.notes,
            "token": kp.token, "recommended": rec, "what": what, "missing": kp.missing,
            "sources": [{"spec": s.spec, "label": s.label, "version": s.vtext, "rec": s.spec == rec,
                         "sum": sums.get(s.spec), "invalid": not s.info.readable, "error": s.info.error}
                        for s in kp.sources],
            "base": (kp.source(rec) if rec else None),
            "selectable": kp.status in ("tindakan", "konflik"),
        })
    return rows
